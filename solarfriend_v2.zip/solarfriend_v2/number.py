"""SolarFriend V2 number platform."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from homeassistant.components.number import NumberEntity, NumberEntityDescription, NumberMode, RestoreNumber
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import PERCENTAGE, UnitOfPower
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .config import entry_value, update_entry_options
from .const import DOMAIN

UNIT_DKK_KWH = "kr/kWh"


@dataclass(frozen=True)
class SolarFriendV2NumberDescription(NumberEntityDescription):
    config_key: str = ""


NUMBER_DESCRIPTIONS: tuple[SolarFriendV2NumberDescription, ...] = (
    SolarFriendV2NumberDescription(
        key="charge_rate_kw",
        name="Charge Rate",
        config_key="charge_rate_kw",
        native_min_value=0.5,
        native_max_value=20.0,
        native_step=0.5,
        native_unit_of_measurement=UnitOfPower.KILO_WATT,
        mode=NumberMode.BOX,
        icon="mdi:lightning-bolt",
    ),
    SolarFriendV2NumberDescription(
        key="battery_min_soc",
        name="Battery Min SOC",
        config_key="battery_min_soc",
        native_min_value=0,
        native_max_value=50,
        native_step=5,
        native_unit_of_measurement=PERCENTAGE,
        mode=NumberMode.SLIDER,
        icon="mdi:battery-low",
    ),
    SolarFriendV2NumberDescription(
        key="battery_max_soc",
        name="Battery Max SOC",
        config_key="battery_max_soc",
        native_min_value=50,
        native_max_value=100,
        native_step=5,
        native_unit_of_measurement=PERCENTAGE,
        mode=NumberMode.SLIDER,
        icon="mdi:battery-high",
    ),
    SolarFriendV2NumberDescription(
        key="min_charge_saving",
        name="Min Charge Saving",
        config_key="min_charge_saving",
        native_min_value=0.05,
        native_max_value=1.00,
        native_step=0.05,
        native_unit_of_measurement=UNIT_DKK_KWH,
        mode=NumberMode.SLIDER,
        icon="mdi:cash-check",
    ),
    SolarFriendV2NumberDescription(
        key="cheap_grid_threshold",
        name="Cheap Grid Threshold",
        config_key="cheap_grid_threshold",
        native_min_value=0.0,
        native_max_value=1.00,
        native_step=0.05,
        native_unit_of_measurement=UNIT_DKK_KWH,
        mode=NumberMode.SLIDER,
        icon="mdi:transmission-tower-import",
    ),
    SolarFriendV2NumberDescription(
        key="deye_default_battery_discharge_current",
        name="Default Battery Discharge Current",
        config_key="deye_default_battery_discharge_current",
        native_min_value=0,
        native_max_value=300,
        native_step=1,
        native_unit_of_measurement="A",
        mode=NumberMode.BOX,
        icon="mdi:current-dc",
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    entities = [SolarFriendV2Number(coordinator, entry, description) for description in NUMBER_DESCRIPTIONS]
    entities.extend([SolarFriendV2EVTargetSOCNumber(coordinator), SolarFriendV2EVMinRangeNumber(coordinator)])
    async_add_entities(entities)


class SolarFriendV2Number(RestoreNumber):
    _attr_has_entity_name = True

    def __init__(self, coordinator: Any, entry: ConfigEntry, description: SolarFriendV2NumberDescription) -> None:
        self._coordinator = coordinator
        self._entry = entry
        self.entity_description = description
        self._attr_unique_id = f"{entry.entry_id}_{description.key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry_value(entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )
        defaults = {
            "charge_rate_kw": 6.0,
            "battery_min_soc": 10.0,
            "battery_max_soc": 90.0,
            "min_charge_saving": 0.20,
            "cheap_grid_threshold": 0.10,
            "deye_default_battery_discharge_current": 0.0,
        }
        self._attr_native_value = float(entry_value(entry, description.config_key, defaults.get(description.config_key, 0.0)))

    async def async_set_native_value(self, value: float) -> None:
        self._attr_native_value = value
        update_entry_options(self.hass, self._entry, **{self.entity_description.config_key: value})
        self.async_write_ha_state()
        callback = getattr(self._coordinator, "async_on_runtime_setting_changed", None)
        if callable(callback):
            await callback(reason=f"number-{self.entity_description.config_key}-updated")


class SolarFriendV2EVTargetSOCNumber(RestoreNumber):
    _attr_has_entity_name = True
    _attr_name = "EV Target SOC"
    _attr_icon = "mdi:battery-charging-80"
    _attr_native_min_value = 0
    _attr_native_max_value = 100
    _attr_native_step = 5
    _attr_native_unit_of_measurement = PERCENTAGE
    _attr_mode = NumberMode.SLIDER

    def __init__(self, coordinator: Any) -> None:
        self._coordinator = coordinator
        self._attr_unique_id = f"{coordinator.config_entry.entry_id}_ev_target_soc"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, coordinator.config_entry.entry_id)},
            name=entry_value(coordinator.config_entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )
        self._attr_native_value = float(getattr(coordinator, "ev_target_soc_override", 80.0) or 80.0)

    async def async_set_native_value(self, value: float) -> None:
        self._attr_native_value = value
        self._coordinator.ev_target_soc_override = value
        update_entry_options(self.hass, self._coordinator.config_entry, ev_target_soc_override=value)
        self.async_write_ha_state()
        callback = getattr(self._coordinator, "async_on_runtime_setting_changed", None)
        if callable(callback):
            await callback(reason="number-ev_target_soc-updated")


class SolarFriendV2EVMinRangeNumber(RestoreNumber):
    _attr_has_entity_name = True
    _attr_name = "EV Min Range"
    _attr_icon = "mdi:map-marker-distance"
    _attr_native_min_value = 0
    _attr_native_max_value = 500
    _attr_native_step = 5
    _attr_native_unit_of_measurement = "km"
    _attr_mode = NumberMode.BOX

    def __init__(self, coordinator: Any) -> None:
        self._coordinator = coordinator
        self._attr_unique_id = f"{coordinator.config_entry.entry_id}_ev_min_range_km"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, coordinator.config_entry.entry_id)},
            name=entry_value(coordinator.config_entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )
        self._attr_native_value = float(getattr(coordinator, "ev_min_range_km", 0.0) or 0.0)

    async def async_set_native_value(self, value: float) -> None:
        self._attr_native_value = value
        self._coordinator.ev_min_range_km = value
        update_entry_options(self.hass, self._coordinator.config_entry, ev_min_range_km=value)
        self.async_write_ha_state()
        callback = getattr(self._coordinator, "async_on_runtime_setting_changed", None)
        if callable(callback):
            await callback(reason="number-ev_min_range_km-updated")
