"""Config entry helpers for SolarFriend V2."""
from __future__ import annotations

from typing import Any


def entry_value(entry: Any, key: str, default: Any = None) -> Any:
    """Read a setting with options taking precedence over data."""
    options = getattr(entry, "options", None) or {}
    if key in options:
        return options[key]
    data = getattr(entry, "data", None) or {}
    return data.get(key, default)


def merged_entry_config(entry: Any) -> dict[str, Any]:
    """Return a merged config dict suitable for read-only consumers."""
    data = dict(getattr(entry, "data", None) or {})
    options = dict(getattr(entry, "options", None) or {})
    return {**data, **options}


def update_entry_options(hass: Any, entry: Any, **updates: Any) -> bool:
    """Persist mutable settings in config entry options."""
    options = dict(getattr(entry, "options", None) or {})
    options.update(updates)
    return hass.config_entries.async_update_entry(entry, options=options)
