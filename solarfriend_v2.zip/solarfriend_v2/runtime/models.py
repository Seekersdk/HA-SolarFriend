"""Shared runtime state models."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class BatteryRuntimeState:
    active_strategy: str | None = None
    active_since: datetime | None = None
    active_reference_pv_w: float = 0.0
    pending_strategy: str | None = None
    pending_count: int = 0
    last_plan_deviation_key: str | None = None
    previous_observed_at: datetime | None = None
    sell_exported_kwh: float = 0.0
    sell_budget_kwh: float = 0.0
    sell_target_soc_pct: float | None = None


@dataclass
class EVRuntimeState:
    currently_charging: bool = False
    charging_started_at: datetime | None = None
    last_action_at: datetime | None = None
    last_power_command: tuple[float, int] | None = None
    last_power_command_at: datetime | None = None
    last_phase_switch_at: datetime | None = None
    solar_start_candidate_since: datetime | None = None
    solar_stop_candidate_since: datetime | None = None


@dataclass(frozen=True)
class RuntimeApplyResult:
    applied: bool
    changed: bool
    reason: str
