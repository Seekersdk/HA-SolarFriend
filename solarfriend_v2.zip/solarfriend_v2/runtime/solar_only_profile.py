"""Runtime wrapper for shared solar-only EV profiles."""
from __future__ import annotations

from ..core.solar_only_profile import SolarOnlyProfile, select_solar_only_profile as _select
from ..planning.world_snapshot import WorldSnapshot

SolarOnlyRuntimeProfile = SolarOnlyProfile


def select_solar_only_profile(snapshot: WorldSnapshot) -> SolarOnlyRuntimeProfile:
    return _select(snapshot.cloud_coverage_pct)
