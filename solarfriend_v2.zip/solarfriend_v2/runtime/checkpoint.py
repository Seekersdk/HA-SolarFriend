"""Fælles persistenslag via HA Store — overlever restart og geninstallation.

Lag: runtime
Afhænger af: homeassistant.helpers.storage
Må IKKE importere: planning/, learning/, decision/

Centrale klasser:
  Checkpoint: async load/save/delete pr. modul-nøgle via HA Store

Nøgler (CHECKPOINT_KEYS — skal holdes konsistente med masterplan):
  "battery_tracker"         → solarfriend_v2.battery_tracker
  "consumption_simple"      → solarfriend_v2.consumption_simple
  "consumption_advanced"    → solarfriend_v2.consumption_advanced
  "consumption_observations"→ solarfriend_v2.consumption_observations
  "forecast_correction"     → solarfriend_v2.forecast_correction
  "solar_profile"           → solarfriend_v2.solar_profile
  "flex_queue"              → solarfriend_v2.flex_queue

Vigtige invarianter:
  - Gemmer i .storage/ → inkluderet i HA backups
  - Overlever geninstallation — ingen entry_id i nøgler
  - Ukendt nøgle ved load returnerer None — aldrig exception
  - version=1 i Store — bump version + skriv migration ved format-ændringer
  - flex_queue ryddes ved solnedgang (koordineret af coordinator, ikke her)
  - migration.py læser v1 rå JSON-filer og skriver hertil via save() — kør én gang
"""
from __future__ import annotations

from typing import Any
import logging

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

_LOGGER = logging.getLogger(__name__)

CHECKPOINT_VERSION = 1
CHECKPOINT_KEYS = (
    "battery_tracker",
    "battery_runtime",
    "consumption_simple",
    "consumption_advanced",
    "consumption_observations",
    "ev_runtime",
    "forecast_correction",
    "solar_profile",
    "flex_queue",
)


class Checkpoint:

    def __init__(self, hass: HomeAssistant) -> None:
        self._stores: dict[str, Store] = {
            key: Store(hass, version=CHECKPOINT_VERSION, key=f"solarfriend_v2.{key}")
            for key in CHECKPOINT_KEYS
        }

    async def save(self, key: str, state: dict[str, Any]) -> None:
        """Gem state for et givet modul-nøgle."""
        store = self._require_store(key)
        await store.async_save(state)

    async def load(self, key: str) -> dict[str, Any] | None:
        """Indlæs state. Returnerer None hvis ikke fundet eller ukendt nøgle."""
        store = self._stores.get(key)
        if store is None:
            return None
        try:
            data = await store.async_load()
        except Exception as exc:  # noqa: BLE001
            _LOGGER.warning("Checkpoint load failed for key=%s: %s", key, exc)
            return None
        return data if isinstance(data, dict) else None

    async def delete(self, key: str) -> None:
        """Slet state for et givet nøgle (fx flex_queue ved solnedgang)."""
        store = self._require_store(key)
        await store.async_remove()

    def _require_store(self, key: str) -> Store:
        store = self._stores.get(key)
        if store is None:
            raise KeyError(f"Unknown checkpoint key: {key}")
        return store
