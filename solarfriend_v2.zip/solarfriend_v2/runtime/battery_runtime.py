"""Battery runtime with hysteresis and plan deviation detection."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta

from ..control.inverter_interface import InverterController
from ..planning.base import BatteryPlan
from ..planning.world_snapshot import WorldSnapshot
from .models import BatteryRuntimeState, RuntimeApplyResult


class BatteryRuntime:
    def __init__(
        self,
        inverter: InverterController,
        *,
        soft_cooldown: timedelta = timedelta(minutes=5),
        confirmation_required: int = 2,
        soc_override_margin_pct: float = 2.0,
        pv_drop_override_min_w: float = 500.0,
        pv_drop_override_fraction: float = 0.30,
        plan_deviation_min_w: float = 400.0,
        plan_deviation_fraction: float = 0.40,
        soc_replan_over_target_pct: float = 5.0,
        soc_replan_under_target_pct: float = 3.0,
    ) -> None:
        self._inverter = inverter
        self._state = BatteryRuntimeState()
        self._soft_cooldown = soft_cooldown
        self._confirmation_required = confirmation_required
        self._soc_override_margin_pct = soc_override_margin_pct
        self._pv_drop_override_min_w = pv_drop_override_min_w
        self._pv_drop_override_fraction = pv_drop_override_fraction
        self._plan_deviation_min_w = plan_deviation_min_w
        self._plan_deviation_fraction = plan_deviation_fraction
        self._soc_replan_over_target_pct = soc_replan_over_target_pct
        self._soc_replan_under_target_pct = soc_replan_under_target_pct
        self._last_plan: BatteryPlan | None = None

    @property
    def state(self) -> BatteryRuntimeState:
        return self._state

    async def apply(self, plan: BatteryPlan, snapshot: WorldSnapshot) -> RuntimeApplyResult:
        forced_reason = self._sell_stop_reason(plan, snapshot)
        desired = plan
        if forced_reason is not None:
            desired = replace(
                plan,
                strategy="IDLE",
                reason=forced_reason,
            )
        selected, changed = self._select_plan(desired, snapshot)
        self._last_plan = desired

        if not changed and self._state.active_strategy == selected.strategy:
            return RuntimeApplyResult(
                applied=False,
                changed=False,
                reason=f"Hold aktiv strategi {selected.strategy}",
            )

        await self._inverter.apply_plan(selected)
        self._mark_applied(selected, snapshot.now, snapshot.power.pv_w)
        return RuntimeApplyResult(
            applied=True,
            changed=changed,
            reason=f"Anvendt {selected.strategy}",
        )

    def should_replan(self, snapshot: WorldSnapshot) -> bool:
        plan = self._last_plan
        if plan is None:
            self._state.last_plan_deviation_key = None
            return False

        current_hour = snapshot.now.replace(minute=0, second=0, microsecond=0)
        current_slot = next(
            (slot for slot in plan.hourly_plan if slot.start == current_hour),
            None,
        )
        if current_slot is None:
            self._state.last_plan_deviation_key = None
            return False

        planned_discharge_w = current_slot.forecast_load_w - current_slot.forecast_solar_w
        actual_battery_discharge_w = max(0.0, snapshot.power.battery_w)
        actual_battery_charge_w = max(0.0, -snapshot.power.battery_w)
        soc_delta_pct = snapshot.battery.soc_pct - current_slot.planned_soc_pct

        deviation_kind: str | None = None
        if soc_delta_pct >= self._soc_replan_over_target_pct:
            deviation_kind = "soc_above_plan"
        elif soc_delta_pct <= -self._soc_replan_under_target_pct:
            deviation_kind = "soc_below_plan"
        if current_slot.strategy in {"USE_BATTERY", "SELL_BATTERY"}:
            expected = max(0.0, planned_discharge_w)
            if expected >= self._plan_deviation_min_w and actual_battery_discharge_w < max(
                self._plan_deviation_min_w,
                expected * self._plan_deviation_fraction,
            ):
                deviation_kind = "missed_discharge"
        elif current_slot.strategy in {"SAVE_SOLAR", "CHARGE_GRID", "CHARGE_NIGHT"}:
            expected = max(0.0, current_slot.forecast_solar_w - current_slot.forecast_load_w)
            if current_slot.strategy in {"CHARGE_GRID", "CHARGE_NIGHT"}:
                expected = max(expected, 1000.0)
            if expected >= self._plan_deviation_min_w and actual_battery_charge_w < max(
                self._plan_deviation_min_w,
                expected * self._plan_deviation_fraction,
            ):
                deviation_kind = "missed_charge"

        if deviation_kind is None:
            self._state.last_plan_deviation_key = None
            return False

        deviation_key = f"{current_hour.isoformat()}|{deviation_kind}"
        if deviation_key == self._state.last_plan_deviation_key:
            return False

        self._state.last_plan_deviation_key = deviation_key
        return True

    def _select_plan(self, desired: BatteryPlan, snapshot: WorldSnapshot) -> tuple[BatteryPlan, bool]:
        state = self._state
        now = snapshot.now
        current_soc = snapshot.battery.soc_pct
        pv_w = max(0.0, snapshot.power.pv_w)

        if state.active_strategy is None:
            return desired, True

        active_strategy = state.active_strategy
        if desired.strategy == active_strategy:
            state.pending_strategy = None
            state.pending_count = 0
            return desired, False

        if self._override_allowed(active_strategy, desired.strategy, now, current_soc, pv_w, snapshot):
            return desired, True

        if state.pending_strategy == desired.strategy:
            state.pending_count += 1
        else:
            state.pending_strategy = desired.strategy
            state.pending_count = 1

        hold_elapsed = (
            state.active_since is None
            or (now - state.active_since) >= self._soft_cooldown
        )
        if hold_elapsed and state.pending_count >= self._confirmation_required:
            return desired, True

        held = replace(desired, strategy=active_strategy, reason=f"Hold {active_strategy}: {desired.reason}")
        return held, False

    def _override_allowed(
        self,
        active_strategy: str,
        desired_strategy: str,
        now: datetime,
        current_soc: float,
        pv_w: float,
        snapshot: WorldSnapshot,
    ) -> bool:
        if desired_strategy == "ANTI_EXPORT":
            return True
        if active_strategy == "SELL_BATTERY" and desired_strategy != "SELL_BATTERY":
            return True

        min_soc = snapshot.battery.min_soc_pct
        max_soc = snapshot.battery.max_soc_pct
        if current_soc <= min_soc + self._soc_override_margin_pct:
            return True
        if current_soc >= max_soc - self._soc_override_margin_pct:
            return True

        reference_pv = max(0.0, self._state.active_reference_pv_w)
        pv_drop_w = max(0.0, reference_pv - pv_w)
        if reference_pv > 0:
            pv_drop_fraction = pv_drop_w / reference_pv
            if (
                pv_drop_w >= self._pv_drop_override_min_w
                and pv_drop_fraction >= self._pv_drop_override_fraction
            ):
                return True

        return False

    def _mark_applied(self, plan: BatteryPlan, now: datetime, pv_w: float) -> None:
        self._state.active_strategy = plan.strategy
        self._state.active_since = now
        self._state.active_reference_pv_w = max(0.0, pv_w)
        self._state.pending_strategy = None
        self._state.pending_count = 0
        self._state.previous_observed_at = now
        if plan.strategy == "SELL_BATTERY":
            self._state.sell_target_soc_pct = plan.export_stop_soc_pct
        else:
            self._state.sell_target_soc_pct = None

    def _sell_stop_reason(self, plan: BatteryPlan, snapshot: WorldSnapshot) -> str | None:
        if self._state.active_strategy != "SELL_BATTERY":
            return None
        target_soc_pct = self._state.sell_target_soc_pct
        if target_soc_pct is not None and snapshot.battery.soc_pct <= target_soc_pct + 0.2:
            return f"Reserve-SOC naaet ({target_soc_pct:.1f}%) - stopper eksport"
        return None
