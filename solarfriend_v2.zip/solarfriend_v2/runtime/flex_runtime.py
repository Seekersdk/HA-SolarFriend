"""Runtime sanitation for one-way flex signals."""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from typing import Any

from ..planning.base import FlexPlan

_INACTIVE_STATES = {"off", "idle", "standby", "unknown", "unavailable", ""}
_ACTIVE_STATES = {"on", "heat", "cool", "auto", "fan_only", "opening", "open", "playing", "running"}


@dataclass(frozen=True)
class FlexRuntimeResult:
    plan: FlexPlan
    notes: list[str]


class FlexRuntime:
    def __init__(self, hass: Any, *, start_grace: timedelta | None = None) -> None:
        self._hass = hass
        self._start_grace = start_grace or timedelta(minutes=5)

    async def sanitize(self, plan: FlexPlan, now: datetime) -> FlexRuntimeResult:
        decisions = []
        notes: list[str] = []
        for decision in plan.decisions:
            if decision.status != "GO_NOW":
                decisions.append(decision)
                continue

            state = self._hass.states.get(decision.entity_id)
            if state is None or str(state.state).lower() in {"unknown", "unavailable"}:
                decisions.append(
                    replace(
                        decision,
                        status="BLOCKED",
                        reason="Flex GO_NOW blokeret - enhed ikke tilgaengelig",
                    )
                )
                notes.append(f"Flex {decision.entity_id} blokeret: utilgaengelig")
                continue

            state_value = str(state.state).lower()
            if self._is_active(state_value):
                decisions.append(decision)
                continue

            if decision.window_start is not None and now >= decision.window_start + self._start_grace:
                decisions.append(
                    replace(
                        decision,
                        status="BLOCKED",
                        reason="Flex GO_NOW udloeber - enhed blev ikke aktiv",
                    )
                )
                notes.append(f"Flex {decision.entity_id} blokeret: ikke startet")
                continue

            decisions.append(decision)

        return FlexRuntimeResult(
            plan=FlexPlan(
                decisions=decisions,
                reserved_solar_today_kwh=plan.reserved_solar_today_kwh,
                reserved_solar_tomorrow_kwh=plan.reserved_solar_tomorrow_kwh,
            ),
            notes=notes,
        )

    @staticmethod
    def _is_active(state_value: str) -> bool:
        if state_value in _ACTIVE_STATES:
            return True
        if state_value in _INACTIVE_STATES:
            return False
        return state_value not in {"not_home", "closed", "locked"}
