"""Startup/readiness gate for safe control activation."""
from __future__ import annotations

from typing import Any

from homeassistant.core import HomeAssistant

from ..config import entry_value
from ..planning.world_snapshot import WorldSnapshot
from ..ingest.market_data_reader import has_usable_state

_SOLCAST_TODAY = "sensor.solcast_pv_forecast_forecast_today"
_SOLCAST_TOMORROW = "sensor.solcast_pv_forecast_forecast_tomorrow"


async def required_input_issues(
    hass: HomeAssistant,
    config_entry: Any,
    snapshot: WorldSnapshot,
    *,
    control_enabled: bool,
    inverter: Any = None,
    charger: Any = None,
    vehicle: Any = None,
) -> list[str]:
    issues: list[str] = []

    for key in (
        "pv_power_sensor",
        "grid_power_sensor",
        "battery_power_sensor",
        "load_power_sensor",
        "battery_soc_sensor",
    ):
        entity_id = entry_value(config_entry, key)
        if entity_id and not has_usable_state(hass, entity_id):
            issues.append(key)

    buy_price_entity = entry_value(config_entry, "buy_price_sensor") or entry_value(config_entry, "price_sensor")
    if buy_price_entity and not has_usable_state(hass, buy_price_entity):
        issues.append("buy_price_sensor")

    sell_price_entity = entry_value(config_entry, "sell_price_sensor")
    if sell_price_entity and not has_usable_state(hass, sell_price_entity):
        issues.append("sell_price_sensor")

    forecast_type = entry_value(config_entry, "forecast_type", "solcast")
    if forecast_type == "solcast":
        if not snapshot.forecast and not (
            has_usable_state(hass, _SOLCAST_TODAY) or has_usable_state(hass, _SOLCAST_TOMORROW)
        ):
            issues.append("forecast")
    else:
        forecast_entity = entry_value(config_entry, "forecast_sensor")
        if forecast_entity and not has_usable_state(hass, forecast_entity):
            issues.append("forecast")

    if control_enabled:
        issues.extend(await _control_input_issues(hass, config_entry, inverter=inverter, charger=charger, vehicle=vehicle))

    return sorted(set(issues))


async def _control_input_issues(
    hass: HomeAssistant,
    config_entry: Any,
    *,
    inverter: Any = None,
    charger: Any = None,
    vehicle: Any = None,
) -> list[str]:
    issues: list[str] = []

    inverter_type = entry_value(config_entry, "inverter_type", "none")
    if inverter_type in {"deye", "deye_klatremis"}:
        for key in (
            "deye_grid_charge_switch",
            "deye_time_of_use_switch",
            "deye_time_point_1_enable",
            "deye_time_point_1_start",
            "deye_time_point_1_capacity",
            "deye_grid_charge_current",
            "deye_max_battery_discharge_current",
            "deye_energy_priority",
            "deye_limit_control_mode",
        ):
            entity_id = entry_value(config_entry, key)
            if entity_id and not has_usable_state(hass, entity_id):
                issues.append(key)
        solar_sell_entity = entry_value(config_entry, "solar_sell_entity")
        if solar_sell_entity and not has_usable_state(hass, solar_sell_entity):
            issues.append("solar_sell_entity")

    if inverter is not None and inverter.is_configured and not await inverter.is_available():
        issues.append("inverter_unavailable")

    if charger is not None and charger.is_configured:
        for key in ("ev_charger_status_entity", "ev_charger_power_entity"):
            entity_id = entry_value(config_entry, key)
            if entity_id and not has_usable_state(hass, entity_id):
                issues.append(key)

    if vehicle is not None and vehicle.is_configured:
        for key in ("vehicle_soc_entity", "vehicle_plugged_in_entity"):
            entity_id = entry_value(config_entry, key)
            if entity_id and not has_usable_state(hass, entity_id):
                issues.append(key)

    return issues
