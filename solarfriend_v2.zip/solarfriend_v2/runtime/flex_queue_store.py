"""Serialize and restore persisted flex queue state."""
from __future__ import annotations

from typing import Any

from ..core.time_utils import parse_local_or_aware
from ..planning.base import FlexLoad


def serialize_flex_loads(loads: list[FlexLoad]) -> dict[str, Any]:
    return {
        "loads": [
            {
                "entity_id": load.entity_id,
                "needed_w": load.needed_w,
                "duration_minutes": load.duration_minutes,
                "deadline": load.deadline.isoformat(),
            }
            for load in loads
        ]
    }


def deserialize_flex_loads(state: dict[str, Any]) -> list[FlexLoad]:
    loads: list[FlexLoad] = []
    for raw in state.get("loads", []):
        if not isinstance(raw, dict):
            continue
        deadline_raw = raw.get("deadline")
        if deadline_raw is None:
            continue
        try:
            deadline = parse_local_or_aware(deadline_raw)
        except (TypeError, ValueError):
            continue
        loads.append(
            FlexLoad(
                entity_id=str(raw.get("entity_id", "")),
                needed_w=float(raw.get("needed_w", 0.0)),
                duration_minutes=int(raw.get("duration_minutes", 0)),
                deadline=deadline,
            )
        )
    return [load for load in loads if load.entity_id]
