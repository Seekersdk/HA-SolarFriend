"""Pure battery tracker for weighted cost and realized savings."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Any

from ..core.economics import weighted_battery_cost

_BATTERY_NOISE_W = 50.0
_DRIFT_THRESHOLD = 0.10


@dataclass
class BatteryTrackerState:
    solar_kwh: float = 0.0
    grid_kwh: float = 0.0
    grid_avg_cost: float = 0.0
    seeded_from_soc: bool = False
    today_solar_direct_saved_dkk: float = 0.0
    today_optimizer_saved_dkk: float = 0.0
    total_solar_direct_saved_dkk: float = 0.0
    total_optimizer_saved_dkk: float = 0.0
    today_battery_sell_saved_dkk: float = 0.0
    total_battery_sell_saved_dkk: float = 0.0
    last_reset_date: str = ""
    previous_update_at: datetime | None = None
    last_soc_correction_at: datetime | None = None


class BatteryTracker:
    def __init__(self, battery_cost_per_kwh: float) -> None:
        self._battery_cost_per_kwh = float(battery_cost_per_kwh)
        self.state = BatteryTrackerState()

    @property
    def battery_cost_per_kwh(self) -> float:
        return self._battery_cost_per_kwh

    @battery_cost_per_kwh.setter
    def battery_cost_per_kwh(self, value: float) -> None:
        self._battery_cost_per_kwh = float(value)

    @property
    def weighted_cost(self) -> float:
        return weighted_battery_cost(
            self.state.solar_kwh,
            self.state.grid_kwh,
            self.state.grid_avg_cost,
            self._battery_cost_per_kwh,
        )

    def get_state(self) -> dict[str, Any]:
        return {
            "solar_kwh": self.state.solar_kwh,
            "grid_kwh": self.state.grid_kwh,
            "grid_avg_cost": self.state.grid_avg_cost,
            "seeded_from_soc": self.state.seeded_from_soc,
            "today_solar_direct_saved_dkk": self.state.today_solar_direct_saved_dkk,
            "today_optimizer_saved_dkk": self.state.today_optimizer_saved_dkk,
            "total_solar_direct_saved_dkk": self.state.total_solar_direct_saved_dkk,
            "total_optimizer_saved_dkk": self.state.total_optimizer_saved_dkk,
            "today_battery_sell_saved_dkk": self.state.today_battery_sell_saved_dkk,
            "total_battery_sell_saved_dkk": self.state.total_battery_sell_saved_dkk,
            "last_reset_date": self.state.last_reset_date,
            "previous_update_at": self.state.previous_update_at.isoformat() if self.state.previous_update_at else None,
            "last_soc_correction_at": (
                self.state.last_soc_correction_at.isoformat()
                if self.state.last_soc_correction_at
                else None
            ),
        }

    def set_state(self, payload: dict[str, Any]) -> None:
        self.state = BatteryTrackerState(
            solar_kwh=float(payload.get("solar_kwh", 0.0)),
            grid_kwh=float(payload.get("grid_kwh", 0.0)),
            grid_avg_cost=float(payload.get("grid_avg_cost", 0.0)),
            seeded_from_soc=bool(payload.get("seeded_from_soc", False)),
            today_solar_direct_saved_dkk=float(payload.get("today_solar_direct_saved_dkk", 0.0)),
            today_optimizer_saved_dkk=float(payload.get("today_optimizer_saved_dkk", 0.0)),
            total_solar_direct_saved_dkk=float(payload.get("total_solar_direct_saved_dkk", 0.0)),
            total_optimizer_saved_dkk=float(payload.get("total_optimizer_saved_dkk", 0.0)),
            today_battery_sell_saved_dkk=float(payload.get("today_battery_sell_saved_dkk", 0.0)),
            total_battery_sell_saved_dkk=float(payload.get("total_battery_sell_saved_dkk", 0.0)),
            last_reset_date=str(payload.get("last_reset_date", "")),
            previous_update_at=self._parse_datetime(payload.get("previous_update_at")),
            last_soc_correction_at=self._parse_datetime(payload.get("last_soc_correction_at")),
        )

    def reset_state(self) -> None:
        self.state = BatteryTrackerState()

    def update(
        self,
        *,
        now: datetime,
        pv_w: float,
        load_w: float,
        battery_w: float,
        battery_soc_pct: float,
        battery_capacity_kwh: float,
        battery_min_soc_pct: float,
        current_price_dkk: float,
        sell_price_dkk: float,
        active_strategy: str | None,
        load_is_trustworthy: bool = True,
    ) -> None:
        self._rollover_if_needed(now.date())
        dt_seconds = self._dt_seconds(now)
        if dt_seconds > 0:
            self._update_energy_mix(
                pv_w=pv_w,
                load_w=load_w,
                battery_w=battery_w,
                current_price_dkk=current_price_dkk,
                dt_seconds=dt_seconds,
            )
            self._update_realized_savings(
                pv_w=pv_w,
                load_w=load_w,
                battery_w=battery_w,
                current_price_dkk=current_price_dkk,
                sell_price_dkk=sell_price_dkk,
                active_strategy=active_strategy,
                dt_seconds=dt_seconds,
                load_is_trustworthy=load_is_trustworthy,
            )
        self._soc_correction(
            battery_soc_pct=battery_soc_pct,
            battery_capacity_kwh=battery_capacity_kwh,
            battery_min_soc_pct=battery_min_soc_pct,
            now=now,
        )
        self.state.previous_update_at = now

    def _update_energy_mix(
        self,
        *,
        pv_w: float,
        load_w: float,
        battery_w: float,
        current_price_dkk: float,
        dt_seconds: float,
    ) -> None:
        dt_h = dt_seconds / 3600.0
        surplus_w = pv_w - load_w
        if battery_w < -_BATTERY_NOISE_W:
            charge_kwh = abs(battery_w) / 1000.0 * dt_h
            if surplus_w > _BATTERY_NOISE_W:
                self.state.solar_kwh += charge_kwh
            else:
                new_cost = max(0.0, current_price_dkk)
                if self.state.grid_kwh > 0:
                    total = self.state.grid_kwh + charge_kwh
                    self.state.grid_avg_cost = (
                        self.state.grid_kwh * self.state.grid_avg_cost + charge_kwh * new_cost
                    ) / total
                else:
                    self.state.grid_avg_cost = new_cost
                self.state.grid_kwh += charge_kwh
            self.state.seeded_from_soc = False
        elif battery_w > _BATTERY_NOISE_W:
            discharge_kwh = battery_w / 1000.0 * dt_h
            from_grid = min(discharge_kwh, self.state.grid_kwh)
            self.state.grid_kwh = max(0.0, self.state.grid_kwh - from_grid)
            self.state.solar_kwh = max(0.0, self.state.solar_kwh - (discharge_kwh - from_grid))
            if self.state.solar_kwh + self.state.grid_kwh > 0:
                self.state.seeded_from_soc = False

    def _update_realized_savings(
        self,
        *,
        pv_w: float,
        load_w: float,
        battery_w: float,
        current_price_dkk: float,
        sell_price_dkk: float,
        active_strategy: str | None,
        dt_seconds: float,
        load_is_trustworthy: bool,
    ) -> None:
        if current_price_dkk > 0 and load_is_trustworthy:
            direct_solar_kwh = max(0.0, min(pv_w, load_w)) * dt_seconds / 3_600_000
            if direct_solar_kwh > 0:
                self.state.today_solar_direct_saved_dkk += direct_solar_kwh * current_price_dkk

            battery_kwh = max(0.0, battery_w) * dt_seconds / 3_600_000
            if battery_kwh > 0 and current_price_dkk > self.weighted_cost:
                self.state.today_optimizer_saved_dkk += battery_kwh * (current_price_dkk - self.weighted_cost)

        if (
            (active_strategy or "").upper() == "SELL_BATTERY"
            and sell_price_dkk > 0
            and battery_w > _BATTERY_NOISE_W
        ):
            sell_kwh = battery_w * dt_seconds / 3_600_000
            self.state.today_battery_sell_saved_dkk += sell_kwh * sell_price_dkk

    def _soc_correction(
        self,
        *,
        battery_soc_pct: float,
        battery_capacity_kwh: float,
        battery_min_soc_pct: float,
        now: datetime,
    ) -> None:
        if (
            self.state.last_soc_correction_at is not None
            and (now - self.state.last_soc_correction_at).total_seconds() < 300
        ):
            return
        actual_total = max(0.0, (battery_soc_pct - battery_min_soc_pct) / 100.0 * battery_capacity_kwh)
        tracked_total = self.state.solar_kwh + self.state.grid_kwh
        if tracked_total <= 0 and actual_total <= 0:
            self.state.last_soc_correction_at = now
            return
        if tracked_total <= 0 < actual_total:
            # If provenance is unknown after restart, avoid inventing expensive grid energy.
            self.state.solar_kwh = actual_total
            self.state.grid_kwh = 0.0
            self.state.seeded_from_soc = True
            self.state.last_soc_correction_at = now
            return
        if tracked_total > 0:
            drift = abs(actual_total - tracked_total) / max(tracked_total, 0.001)
            if drift > _DRIFT_THRESHOLD:
                scale = actual_total / tracked_total if tracked_total > 0 else 0.0
                self.state.solar_kwh *= scale
                self.state.grid_kwh *= scale
        self.state.last_soc_correction_at = now

    def _rollover_if_needed(self, today: date) -> None:
        today_iso = today.isoformat()
        if self.state.last_reset_date and self.state.last_reset_date != today_iso:
            self.state.total_solar_direct_saved_dkk += self.state.today_solar_direct_saved_dkk
            self.state.total_optimizer_saved_dkk += self.state.today_optimizer_saved_dkk
            self.state.total_battery_sell_saved_dkk += self.state.today_battery_sell_saved_dkk
            self.state.today_solar_direct_saved_dkk = 0.0
            self.state.today_optimizer_saved_dkk = 0.0
            self.state.today_battery_sell_saved_dkk = 0.0
        self.state.last_reset_date = today_iso

    def _dt_seconds(self, now: datetime) -> float:
        if self.state.previous_update_at is None:
            return 0.0
        return max(0.0, (now - self.state.previous_update_at).total_seconds())

    @staticmethod
    def _parse_datetime(value: Any) -> datetime | None:
        if value in (None, ""):
            return None
        if isinstance(value, datetime):
            return value
        try:
            return datetime.fromisoformat(str(value))
        except (TypeError, ValueError):
            return None
