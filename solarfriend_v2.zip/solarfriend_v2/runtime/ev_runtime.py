"""EV runtime with state sync, anti-flap, and solar-only hysteresis."""
from __future__ import annotations

from dataclasses import replace
from datetime import timedelta

from ..control.charger_interface import ChargerController
from ..control.vehicle_interface import VehicleController
from ..planning.base import EVPlan
from ..planning.world_snapshot import WorldSnapshot
from .models import EVRuntimeState, RuntimeApplyResult
from .solar_only_profile import select_solar_only_profile

_MIN_1PHASE_W = 6.0 * 235.0
_MIN_3PHASE_W = 6.0 * 3 * 235.0
_MAX_1PHASE_W = 16.0 * 235.0
_MAX_3PHASE_W = 16.0 * 3 * 235.0


class EVRuntime:
    def __init__(
        self,
        charger: ChargerController,
        vehicle: VehicleController,
        *,
        min_action_interval: timedelta = timedelta(seconds=120),
        min_session: timedelta = timedelta(seconds=300),
        min_power_change_interval: timedelta = timedelta(seconds=30),
        min_phase_change_interval: timedelta = timedelta(seconds=180),
        start_hold: timedelta = timedelta(seconds=90),
        stop_hold: timedelta = timedelta(seconds=120),
        grid_buffer_w: float = 250.0,
        minimum_power_delta_w: float = 150.0,
    ) -> None:
        self._charger = charger
        self._vehicle = vehicle
        self._state = EVRuntimeState()
        self._min_action_interval = min_action_interval
        self._min_session = min_session
        self._min_power_change_interval = min_power_change_interval
        self._min_phase_change_interval = min_phase_change_interval
        self._start_hold = start_hold
        self._stop_hold = stop_hold
        self._grid_buffer_w = grid_buffer_w
        self._minimum_power_delta_w = minimum_power_delta_w

    @property
    def state(self) -> EVRuntimeState:
        return self._state

    async def sync_state(self) -> tuple:
        charger_state = await self._charger.get_state()
        vehicle_state = await self._vehicle.get_state()
        self._state.currently_charging = charger_state.charging
        return charger_state, vehicle_state

    async def apply(self, plan: EVPlan, snapshot: WorldSnapshot) -> RuntimeApplyResult:
        charger_state = snapshot.charger
        now = snapshot.now
        effective_plan = self._apply_hysteresis(plan, snapshot, charger_state)
        actual_charging = bool(charger_state and charger_state.charging)

        if effective_plan.should_charge and not actual_charging:
            if not self._can_act(now):
                return RuntimeApplyResult(False, False, "EV action cooldown")
            await self._charger.resume()
            await self._charger.set_power(int(effective_plan.target_power_w), effective_plan.phases)
            if self._state.last_power_command is None or self._state.last_power_command[1] != int(effective_plan.phases):
                self._state.last_phase_switch_at = now
            self._state.currently_charging = True
            self._state.charging_started_at = now
            self._state.last_action_at = now
            self._state.last_power_command = (
                float(effective_plan.target_power_w),
                int(effective_plan.phases),
            )
            self._state.last_power_command_at = now
            return RuntimeApplyResult(True, True, f"Start EV charging: {effective_plan.reason}")

        if effective_plan.should_charge and actual_charging:
            command = (float(effective_plan.target_power_w), int(effective_plan.phases))
            if self._state.last_power_command == command:
                return RuntimeApplyResult(False, False, "EV target unchanged")
            if self._state.last_power_command is not None:
                delta = abs(self._state.last_power_command[0] - command[0])
                if delta < self._minimum_power_delta_w and self._state.last_power_command[1] == command[1]:
                    return RuntimeApplyResult(False, False, "EV power delta too small")
            if self._state.last_power_command_at is not None and (
                now - self._state.last_power_command_at
            ) < self._min_power_change_interval:
                return RuntimeApplyResult(False, False, "EV power change cooldown")
            await self._charger.set_power(int(effective_plan.target_power_w), effective_plan.phases)
            if self._state.last_power_command is None or self._state.last_power_command[1] != command[1]:
                self._state.last_phase_switch_at = now
            self._state.last_power_command = command
            self._state.last_power_command_at = now
            return RuntimeApplyResult(True, False, f"Adjust EV power: {effective_plan.reason}")

        if not effective_plan.should_charge and actual_charging:
            if self._state.charging_started_at is not None and (
                now - self._state.charging_started_at
            ) < self._min_session:
                return RuntimeApplyResult(False, False, "EV minimum session not reached")
            if not self._can_act(now):
                return RuntimeApplyResult(False, False, "EV action cooldown")
            await self._charger.pause()
            self._state.currently_charging = False
            self._state.charging_started_at = None
            self._state.last_action_at = now
            self._state.last_power_command = None
            self._state.last_power_command_at = None
            return RuntimeApplyResult(True, True, f"Pause EV charging: {effective_plan.reason}")

        return RuntimeApplyResult(False, False, "No EV action needed")

    def _apply_hysteresis(
        self,
        plan: EVPlan,
        snapshot: WorldSnapshot,
        charger_state,
    ) -> EVPlan:
        if plan.priority == "emergency":
            self._state.solar_start_candidate_since = None
            self._state.solar_stop_candidate_since = None
            return plan

        if plan.mode != "solar_only":
            self._state.solar_start_candidate_since = None
            self._state.solar_stop_candidate_since = None
            return plan

        now = snapshot.now
        actual_charging = bool(charger_state and charger_state.charging)
        surplus_w = max(0.0, snapshot.power.pv_w - snapshot.power.load_w - abs(snapshot.power.battery_w))
        profile = select_solar_only_profile(snapshot)
        current_phase = (
            charger_state.phases
            if charger_state is not None and charger_state.phases
            else (
                self._state.last_power_command[1]
                if self._state.last_power_command is not None
                else plan.phases
            )
        )

        if plan.should_charge:
            self._state.solar_stop_candidate_since = None
            if actual_charging:
                self._state.solar_start_candidate_since = None
                target_power_w, phases = self._resolve_solar_command(
                    target_power_w=plan.target_power_w,
                    current_phase=current_phase,
                    profile=profile,
                    now=now,
                )
                return replace(
                    plan,
                    target_power_w=target_power_w,
                    phases=phases,
                    reason=f"{profile.label}: {plan.reason}",
                )
            if self._state.solar_start_candidate_since is None:
                self._state.solar_start_candidate_since = now
            start_hold = min(self._start_hold, timedelta(seconds=profile.start_hold_seconds))
            if (now - self._state.solar_start_candidate_since) < start_hold:
                return replace(
                    plan,
                    should_charge=False,
                    target_power_w=0.0,
                    phases=0,
                    reason=(
                        f"{profile.label}: Start hysterese {(now - self._state.solar_start_candidate_since).seconds}/"
                        f"{int(start_hold.total_seconds())}s ({surplus_w:.0f}W >= {profile.start_surplus_w:.0f}W)"
                    ),
                )
            self._state.solar_start_candidate_since = None
            target_power_w, phases = self._resolve_solar_command(
                target_power_w=plan.target_power_w,
                current_phase=0,
                profile=profile,
                now=now,
            )
            return replace(
                plan,
                target_power_w=target_power_w,
                phases=phases,
                reason=f"{profile.label}: {plan.reason}",
            )

        self._state.solar_start_candidate_since = None
        if not actual_charging:
            self._state.solar_stop_candidate_since = None
            return replace(plan, reason=f"{profile.label}: {plan.reason}")
        if self._state.solar_stop_candidate_since is None:
            self._state.solar_stop_candidate_since = now
        stop_hold = min(self._stop_hold, timedelta(seconds=profile.stop_hold_seconds))
        if (now - self._state.solar_stop_candidate_since) < stop_hold:
            buffered_target = max(_MIN_1PHASE_W, surplus_w + self._grid_buffer_w + profile.grid_buffer_w)
            target_power_w, phases = self._resolve_solar_command(
                target_power_w=buffered_target,
                current_phase=current_phase,
                profile=profile,
                now=now,
            )
            return replace(
                plan,
                should_charge=True,
                target_power_w=target_power_w,
                phases=phases,
                reason=(
                    f"{profile.label}: Stop hysterese {(now - self._state.solar_stop_candidate_since).seconds}/"
                    f"{int(stop_hold.total_seconds())}s ({surplus_w:.0f}W < {profile.stop_surplus_w:.0f}W)"
                ),
            )
        self._state.solar_stop_candidate_since = None
        return replace(plan, reason=f"{profile.label}: {plan.reason}")

    def _can_act(self, now) -> bool:
        return self._state.last_action_at is None or (now - self._state.last_action_at) >= self._min_action_interval

    def _resolve_solar_command(
        self,
        *,
        target_power_w: float,
        current_phase: int,
        profile,
        now,
    ) -> tuple[float, int]:
        desired_power, desired_phase = self._calc_phase_and_power(target_power_w)

        if current_phase == 1 and desired_phase == 3:
            if desired_power < profile.phase_switch_up_w:
                desired_power, desired_phase = self._calc_phase_and_power(target_power_w, force_phase=1)
            elif self._state.last_phase_switch_at is not None and (
                now - self._state.last_phase_switch_at
            ) < self._min_phase_change_interval:
                desired_power, desired_phase = self._calc_phase_and_power(target_power_w, force_phase=1)

        elif current_phase == 3 and desired_phase == 1:
            keep_three_phase = (
                target_power_w >= profile.phase_switch_down_w
                and target_power_w >= _MIN_3PHASE_W
                and self._state.last_phase_switch_at is not None
                and (now - self._state.last_phase_switch_at) < self._min_phase_change_interval
            )
            if keep_three_phase:
                desired_power, desired_phase = self._calc_phase_and_power(target_power_w, force_phase=3)
        return desired_power, desired_phase

    def _calc_phase_and_power(self, target_power_w: float, *, force_phase: int | None = None) -> tuple[float, int]:
        effective_target = max(_MIN_1PHASE_W, float(target_power_w))
        if force_phase == 3:
            effective_target = max(_MIN_3PHASE_W, min(effective_target, _MAX_3PHASE_W))
            amps = max(6.0, min(16.0, effective_target / (3 * 235.0)))
            return round(amps * 3 * 235.0), 3
        if force_phase == 1:
            effective_target = min(effective_target, _MAX_1PHASE_W)
            amps = max(6.0, min(16.0, effective_target / 235.0))
            return round(amps * 235.0), 1
        if effective_target >= _MIN_3PHASE_W:
            return self._calc_phase_and_power(effective_target, force_phase=3)
        return self._calc_phase_and_power(effective_target, force_phase=1)
