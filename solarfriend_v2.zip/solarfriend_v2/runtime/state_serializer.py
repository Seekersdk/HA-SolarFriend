"""Serialize and restore runtime state objects."""
from __future__ import annotations

from typing import Any

from ..core.time_utils import parse_local_or_aware


def serialize_battery_runtime_state(runtime) -> dict[str, Any]:
    state = runtime.state
    return {
        "active_strategy": state.active_strategy,
        "active_since": state.active_since.isoformat() if state.active_since else None,
        "active_reference_pv_w": state.active_reference_pv_w,
        "pending_strategy": state.pending_strategy,
        "pending_count": state.pending_count,
        "last_plan_deviation_key": state.last_plan_deviation_key,
    }


def restore_battery_runtime_state(runtime, payload: dict[str, Any]) -> None:
    state = runtime.state
    state.active_strategy = payload.get("active_strategy")
    state.active_since = _parse_optional_datetime(payload.get("active_since"))
    state.active_reference_pv_w = float(payload.get("active_reference_pv_w", 0.0))
    state.pending_strategy = payload.get("pending_strategy")
    state.pending_count = int(payload.get("pending_count", 0))
    state.last_plan_deviation_key = payload.get("last_plan_deviation_key")


def serialize_ev_runtime_state(runtime) -> dict[str, Any]:
    state = runtime.state
    return {
        "currently_charging": state.currently_charging,
        "charging_started_at": state.charging_started_at.isoformat() if state.charging_started_at else None,
        "last_action_at": state.last_action_at.isoformat() if state.last_action_at else None,
        "last_power_command": list(state.last_power_command) if state.last_power_command else None,
        "last_power_command_at": state.last_power_command_at.isoformat() if state.last_power_command_at else None,
        "last_phase_switch_at": state.last_phase_switch_at.isoformat() if state.last_phase_switch_at else None,
        "solar_start_candidate_since": state.solar_start_candidate_since.isoformat() if state.solar_start_candidate_since else None,
        "solar_stop_candidate_since": state.solar_stop_candidate_since.isoformat() if state.solar_stop_candidate_since else None,
    }


def restore_ev_runtime_state(runtime, payload: dict[str, Any]) -> None:
    state = runtime.state
    state.currently_charging = bool(payload.get("currently_charging", False))
    state.charging_started_at = _parse_optional_datetime(payload.get("charging_started_at"))
    state.last_action_at = _parse_optional_datetime(payload.get("last_action_at"))
    command = payload.get("last_power_command")
    if isinstance(command, list) and len(command) == 2:
        state.last_power_command = (float(command[0]), int(command[1]))
    else:
        state.last_power_command = None
    state.last_power_command_at = _parse_optional_datetime(payload.get("last_power_command_at"))
    state.last_phase_switch_at = _parse_optional_datetime(payload.get("last_phase_switch_at"))
    state.solar_start_candidate_since = _parse_optional_datetime(payload.get("solar_start_candidate_since"))
    state.solar_stop_candidate_since = _parse_optional_datetime(payload.get("solar_stop_candidate_since"))


def _parse_optional_datetime(value: Any):
    if value in (None, ""):
        return None
    try:
        return parse_local_or_aware(value)
    except (TypeError, ValueError):
        return None
