"""One-time migration from V1 storage keys to V2 checkpoint keys.

Lag: runtime
Afhænger af: runtime/checkpoint.py, homeassistant.helpers.storage
Må IKKE importere: planning/, control/, decision/

Centrale klasser/funktioner:
  MigrationManager: runs one-time V1 -> V2 migration using HA Store data
  MigrationResult:  compact summary of what was migrated or skipped

Vigtige invarianter / gotchas:
  - Only modules approved by the masterplan are migrated
  - SolarProfile and AdvancedModel are intentionally NOT migrated
  - Migration reads stable V1 keys first, then legacy entry_id suffixed keys
  - A migration marker prevents re-running successful migrations automatically
"""
from __future__ import annotations

from dataclasses import dataclass, field
import logging
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

from .checkpoint import Checkpoint, CHECKPOINT_VERSION

_LOGGER = logging.getLogger(__name__)

MIGRATION_STATE_KEY = "solarfriend_v2.migration_state"
MIGRATION_STATE_VERSION = 1

V1_TO_V2_KEYS = {
    "solarfriend_battery_tracker": "battery_tracker",
    "solarfriend_profile": "consumption_simple",
    "solarfriend_forecast_correction": "forecast_correction",
}


@dataclass(frozen=True)
class MigrationResult:
    """Summary of one migration run."""

    migrated: dict[str, str] = field(default_factory=dict)
    skipped: dict[str, str] = field(default_factory=dict)
    already_done: bool = False


class MigrationManager:
    """Reads V1 Store data and writes it into V2 checkpoint keys once."""

    def __init__(self, hass: HomeAssistant, checkpoint: Checkpoint, entry_id: str) -> None:
        self._hass = hass
        self._checkpoint = checkpoint
        self._entry_id = entry_id
        self._state_store = Store(hass, MIGRATION_STATE_VERSION, MIGRATION_STATE_KEY)

    async def async_migrate_once(self) -> MigrationResult:
        marker = await self._load_marker()
        if marker.get("completed") is True:
            return MigrationResult(already_done=True)

        migrated: dict[str, str] = {}
        skipped: dict[str, str] = {}

        for v1_key, v2_key in V1_TO_V2_KEYS.items():
            existing = await self._checkpoint.load(v2_key)
            if existing:
                skipped[v2_key] = "v2_state_exists"
                continue

            data, source_key = await self._load_v1_state(v1_key)
            if data is None:
                skipped[v2_key] = "no_v1_state"
                continue

            await self._checkpoint.save(v2_key, data)
            migrated[v2_key] = source_key

        await self._state_store.async_save(
            {
                "completed": True,
                "entry_id": self._entry_id,
                "migrated": migrated,
                "skipped": skipped,
            }
        )
        _LOGGER.info("SolarFriend V2 migration completed: migrated=%s skipped=%s", migrated, skipped)
        return MigrationResult(migrated=migrated, skipped=skipped)

    async def _load_marker(self) -> dict[str, Any]:
        try:
            data = await self._state_store.async_load()
        except Exception as exc:  # noqa: BLE001
            _LOGGER.warning("Migration marker load failed: %s", exc)
            return {}
        return data if isinstance(data, dict) else {}

    async def _load_v1_state(self, stable_key: str) -> tuple[dict[str, Any] | None, str]:
        candidates = [stable_key]
        if self._entry_id:
            candidates.append(f"{stable_key}_{self._entry_id}")

        for key in candidates:
            store = Store(self._hass, CHECKPOINT_VERSION, key)
            try:
                data = await store.async_load()
            except Exception as exc:  # noqa: BLE001
                _LOGGER.warning("Migration load failed for key=%s: %s", key, exc)
                continue
            if isinstance(data, dict) and data:
                return data, key
        return None, ""
