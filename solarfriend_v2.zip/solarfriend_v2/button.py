"""SolarFriend V2 button platform."""
from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .config import entry_value
from .const import DOMAIN


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [
            SolarFriendV2PopulateLoadModelButton(coordinator, entry),
            SolarFriendV2ResetAdvancedConsumptionModelButton(coordinator, entry),
            SolarFriendV2ResetBatteryTrackerButton(coordinator, entry),
        ]
    )


class SolarFriendV2PopulateLoadModelButton(ButtonEntity):
    _attr_has_entity_name = True
    _attr_name = "Populate Load Model"
    _attr_icon = "mdi:database-arrow-down"

    def __init__(self, coordinator, entry: ConfigEntry) -> None:
        self._coordinator = coordinator
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_populate_load_model"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry_value(entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )

    async def async_press(self) -> None:
        callback = getattr(self._coordinator, "async_force_populate_load_model", None)
        if callable(callback):
            await callback(days=14)
        refresh = getattr(self._coordinator, "async_request_refresh", None)
        if callable(refresh):
            await refresh()


class SolarFriendV2ResetAdvancedConsumptionModelButton(ButtonEntity):
    _attr_has_entity_name = True
    _attr_name = "Reset Advanced Consumption Model"
    _attr_icon = "mdi:brain"

    def __init__(self, coordinator, entry: ConfigEntry) -> None:
        self._coordinator = coordinator
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_reset_advanced_consumption_model"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry_value(entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )

    async def async_press(self) -> None:
        callback = getattr(self._coordinator, "async_reset_advanced_consumption_model", None)
        if callable(callback):
            await callback()
        refresh = getattr(self._coordinator, "async_request_refresh", None)
        if callable(refresh):
            await refresh()


class SolarFriendV2ResetBatteryTrackerButton(ButtonEntity):
    _attr_has_entity_name = True
    _attr_name = "Reset Battery Tracker"
    _attr_icon = "mdi:battery-sync"

    def __init__(self, coordinator, entry: ConfigEntry) -> None:
        self._coordinator = coordinator
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_reset_battery_tracker"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry_value(entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )

    async def async_press(self) -> None:
        callback = getattr(self._coordinator, "async_reset_battery_tracker", None)
        if callable(callback):
            await callback()
        refresh = getattr(self._coordinator, "async_request_refresh", None)
        if callable(refresh):
            await refresh()
