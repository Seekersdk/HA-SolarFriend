"""Basistyper for alle planners — plan-dataklasser og planner-interface.

Lag: planning
Afhænger af: core/types.py, planning/world_snapshot.py
Må IKKE importere: homeassistant, control/, runtime/

Centrale klasser:
  BatteryPlan:      batteriets planlagte strategi over prisaksen
  EVPlan:           EV-opladningsplan med slots
  FlexLoad:         én registreret flex load (entity_id er unik nøgle)
  FlexLoadDecision: plannerens beslutning for ét flex load
  FlexPlan:         samlet flex plan — én beslutning per load
  HourlySlot:       ét time-slot i en plan
  Planner:          abstract base — implementer plan() i hvert modul

Vigtige invarianter:
  - Planners er pure functions: WorldSnapshot → Plan, ingen side effects
  - EVPlanner planlægger EV isoleret; EV-vs-battery konflikter løses i EnergyAllocator
  - FlexPlanner modtager BatteryPlan som constraint — kør battery før flex
  - Hysterese og cooldown hører IKKE hjemme her — det er runtime/'s ansvar
  - FlexLoad.entity_id er unik nøgle — upsert ved registrering
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .world_snapshot import WorldSnapshot


@dataclass
class HourlySlot:
    start: datetime
    strategy: str
    forecast_load_w: float
    forecast_solar_w: float
    price_dkk: float
    planned_soc_pct: float
    reason: str = ""
    planned_energy_kwh: float = 0.0
    grid_charge_w: float = 0.0
    solar_charge_w: float = 0.0
    discharge_w: float = 0.0
    discharge_to_load_w: float = 0.0
    battery_export_w: float = 0.0
    grid_import_w: float = 0.0
    sell_price_dkk: float | None = None
    discharge_value_dkk: float | None = None
    allowed_discharge_w: float = 0.0


@dataclass
class BatteryPlan:
    strategy: str                       # IDLE | USE_BATTERY | SELL_BATTERY | CHARGE_GRID | CHARGE_NIGHT | SAVE_SOLAR | ANTI_EXPORT
    hourly_plan: list[HourlySlot]
    reason: str
    next_cheap_window: datetime | None = None
    next_expensive_window: datetime | None = None
    next_recharge_window: datetime | None = None
    target_soc_pct: float | None = None
    export_stop_soc_pct: float | None = None
    required_reserve_kwh: float = 0.0
    export_budget_kwh: float = 0.0
    planned_export_kwh: float = 0.0
    can_defer_for_ev_solar: bool = False


@dataclass
class EVPlan:
    should_charge: bool
    target_power_w: float
    phases: int
    reason: str
    planned_slots: list[HourlySlot]
    mode: str = "solar_only"
    priority: str = "opportunistic"    # opportunistic | deadline | emergency


@dataclass(frozen=True)
class FlexLoad:
    """One registered flex load. entity_id is the unique key (upsert semantics)."""

    entity_id: str
    needed_w: float
    duration_minutes: int
    deadline: datetime


@dataclass(frozen=True)
class FlexLoadDecision:
    """Planner's decision for one flex load."""

    entity_id: str
    status: str                     # GO_NOW | SCHEDULED | DEADLINE_FORCED
    window_start: datetime | None   # when to start (None only if truly no deadline feasible)
    window_end: datetime | None     # informational: when surplus window ends
    reason: str


@dataclass
class FlexPlan:
    decisions: list[FlexLoadDecision]
    reserved_solar_today_kwh: float
    reserved_solar_tomorrow_kwh: float


class Planner(ABC):
    """Base interface for all planners."""

    @abstractmethod
    def plan(self, snapshot: WorldSnapshot) -> Any:
        """Compute a plan from the current world snapshot. Pure — no side effects."""
        ...
