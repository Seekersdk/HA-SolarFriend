"""Energy allocator - resolves EV-vs-battery solar ownership before decision.

Lag: planning
Afhaenger af: planning/base.py, planning/world_snapshot.py
Maa IKKE importere: homeassistant, runtime/, control/

Centrale klasser:
  EnergyAllocator: fordeler lokal sol mellem stationaert batteri og mobil EV
  EnergyAllocation: simple signaler til decision engine

Vigtige invarianter:
  - Ingen oekonomiske beregninger her; de kommer fra planners
  - solar_only EV er opportunistisk og maa kun fortraenge batteriet, naar batteriet kan vente
  - Export har altid laveste prioritet og blokeres af lokal anvendelse
"""
from __future__ import annotations

from dataclasses import dataclass

from .base import BatteryPlan, EVPlan, FlexPlan
from .world_snapshot import WorldSnapshot


@dataclass(frozen=True)
class EnergyAllocation:
    ev_has_solar_priority_now: bool = False
    battery_should_wait_for_ev_solar: bool = False
    battery_should_wait_for_flex: bool = False
    battery_export_blocked: bool = False
    ev_should_pause_for_battery: bool = False
    ev_should_pause_for_flex: bool = False
    has_conflicts: bool = False
    reason: str = ""


class EnergyAllocator:
    """Resolve local-energy ownership before the thin decision layer runs."""

    def allocate(
        self,
        snapshot: WorldSnapshot,
        battery_plan: BatteryPlan,
        ev_plan: EVPlan,
        flex_plan: FlexPlan,
    ) -> EnergyAllocation:
        flex_go_now = any(item.status == "GO_NOW" for item in flex_plan.decisions)
        ev_active = ev_plan.should_charge
        ev_solar_only = ev_active and ev_plan.mode == "solar_only"
        ev_deadline_mode = ev_active and ev_plan.priority in {"deadline", "emergency"}
        ev_emergency_mode = ev_active and ev_plan.priority == "emergency"

        notes: list[str] = []
        battery_export_blocked = battery_plan.strategy == "SELL_BATTERY" and (
            ev_active or flex_go_now
        )
        if battery_export_blocked:
            notes.append("Eksport blokeret af lokal anvendelse")

        battery_should_wait_for_flex = False
        if flex_go_now and battery_plan.strategy in {"SAVE_SOLAR", "SELL_BATTERY"}:
            battery_should_wait_for_flex = True
            notes.append("Flex GO_NOW har prioritet over husbatteriets lokale brug nu")

        battery_should_wait = False
        ev_has_priority = False
        if (
            ev_solar_only
            and battery_plan.strategy == "SAVE_SOLAR"
            and battery_plan.can_defer_for_ev_solar
        ):
            ev_has_priority = True
            battery_should_wait = True
            notes.append("EV solar_only faar aktuel sol; husbatteri kan vente")

        ev_should_pause_for_battery = False
        if ev_deadline_mode and battery_plan.strategy in {"USE_BATTERY", "SELL_BATTERY"}:
            ev_should_pause_for_battery = True
            notes.append("EV deadline-mode maa ikke traekke gennem husbatteriet")
        ev_should_pause_for_flex = False
        if flex_go_now and ev_plan.mode != "grid_only" and not ev_emergency_mode:
            ev_should_pause_for_flex = True
            notes.append("Flex GO_NOW har prioritet over EV nu")

        return EnergyAllocation(
            ev_has_solar_priority_now=ev_has_priority,
            battery_should_wait_for_ev_solar=battery_should_wait,
            battery_should_wait_for_flex=battery_should_wait_for_flex,
            battery_export_blocked=battery_export_blocked,
            ev_should_pause_for_battery=ev_should_pause_for_battery,
            ev_should_pause_for_flex=ev_should_pause_for_flex,
            has_conflicts=bool(notes),
            reason="; ".join(notes) if notes else "Ingen allokeringskonflikter",
        )
