"""EV planner - pure function: WorldSnapshot -> EVPlan.

Lag: planning
Afhaenger af: planning/base.py, planning/world_snapshot.py
Maa IKKE importere: homeassistant, runtime/, control/

Centrale klasser:
  EVPlanner: beslutter EV-opladning ud fra solsurplus og prishorisont

Vigtige invarianter:
  - Konflikter mod husbatteri loeses ikke her, men i planning/energy_allocator.py
  - EV-surplus = pv_w - load_w - |battery_w|
  - solar_only er opportunistisk: brug kun lokal sol, der ellers gaar tabt
  - hybrid og grid_only er deadline-baserede modes
  - Hysterese og throttle hoerer hjemme i runtime/ev_runtime.py
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta

from ..core.solar_only_profile import select_solar_only_profile
from .base import EVPlan, HourlySlot, Planner
from .world_snapshot import WorldSnapshot

_VOLTAGE = 235.0
_MIN_AMPS = 6.0
_MAX_AMPS = 16.0
_MIN_1PHASE_W = _MIN_AMPS * _VOLTAGE
_MIN_3PHASE_W = _MIN_AMPS * 3 * _VOLTAGE


class EVPlanner(Planner):
    """Plans EV charging across the known price and solar horizon."""

    def plan(
        self,
        snapshot: WorldSnapshot,
    ) -> EVPlan:
        ev = snapshot.ev

        if not snapshot.ev_charging_enabled or ev is None:
            return _idle("EV-opladning ikke aktiveret eller ingen bil tilgaengelig", mode=snapshot.ev_mode)
        if not ev.plugged_in:
            return _idle("Bil ikke tilsluttet", mode=snapshot.ev_mode)
        if ev.soc_pct >= ev.target_soc_pct:
            return _idle(
                f"Maal-SOC naaet ({ev.soc_pct:.0f}% >= {ev.target_soc_pct:.0f}%)",
                mode=snapshot.ev_mode,
            )
        emergency = self._emergency_charge(snapshot)
        if emergency is not None:
            return emergency

        mode = snapshot.ev_mode
        departure = snapshot.ev_departure

        bat = snapshot.battery
        if bat.soc_pct < bat.min_soc_pct + 2.0:
            deadline_mode = mode in {"hybrid", "grid_only"} and departure is not None
            if not deadline_mode:
                return _idle(
                    f"Batteri SOC {bat.soc_pct:.0f}% under minimum - batteri prioriteres",
                    mode=snapshot.ev_mode,
                )

        if mode == "hybrid" and departure is not None:
            return self._hybrid(snapshot, departure)
        if mode == "grid_only" and departure is not None:
            return self._grid_only(snapshot, departure)
        return self._solar_only(snapshot)

    def _emergency_charge(self, snapshot: WorldSnapshot) -> EVPlan | None:
        ev = snapshot.ev
        min_range_km = max(0.0, snapshot.ev_min_range_km)
        if ev is None or min_range_km <= 0.0:
            return None
        if ev.range_km >= min_range_km:
            return None

        needed_soc_pct = ev.target_soc_pct
        if ev.soc_pct > 0.0 and ev.range_km > 0.0:
            needed_soc_pct = min(100.0, max(ev.target_soc_pct, min_range_km / ev.range_km * ev.soc_pct))
        max_charge_w = _max_charge_kw(snapshot) * 1000.0
        phases, amps, power_w = _phase_and_power(max_charge_w, max_charge_w)
        if power_w <= 0.0:
            return None
        now_hour = snapshot.now.replace(minute=0, second=0, microsecond=0)
        planned_energy_kwh = round(power_w / 1000.0, 3)
        return EVPlan(
            should_charge=True,
            target_power_w=power_w,
            phases=phases,
            reason=(
                f"Noedopladning - {ev.range_km:.0f}km < {min_range_km:.0f}km minimum "
                f"(lader til ca. {needed_soc_pct:.0f}% SOC)"
            ),
            planned_slots=[
                HourlySlot(
                    start=now_hour,
                    strategy="CHARGE_GRID",
                    forecast_load_w=snapshot.power.load_w,
                    forecast_solar_w=max(snapshot.power.pv_w, 0.0),
                    price_dkk=snapshot.prices[0].price_dkk if snapshot.prices else 0.0,
                    planned_soc_pct=needed_soc_pct,
                    planned_energy_kwh=planned_energy_kwh,
                    reason="Noedopladning pga. minimum raekkevidde",
                    grid_charge_w=power_w,
                )
            ],
            mode=snapshot.ev_mode,
            priority="emergency",
        )

    def _solar_only(self, snapshot: WorldSnapshot) -> EVPlan:
        """Charge only from live local solar surplus."""
        surplus = _ev_surplus_w(snapshot)
        profile = select_solar_only_profile(snapshot.cloud_coverage_pct)
        planned_slots = self._build_solar_only_slots(snapshot)
        if surplus < profile.start_surplus_w:
            return _idle(
                f"{profile.label}: Solsurplus {surplus:.0f}W < startgrænse {profile.start_surplus_w:.0f}W",
                mode="solar_only",
                planned_slots=planned_slots,
            )

        max_charge_w = _max_charge_kw(snapshot) * 1000.0
        phases, amps, power_w = _phase_and_power(surplus, max_charge_w)
        return EVPlan(
            should_charge=True,
            target_power_w=power_w,
            phases=phases,
            reason=f"{profile.label}: Solsurplus {surplus:.0f}W -> {phases}-fase {amps:.1f}A ({power_w:.0f}W)",
            planned_slots=planned_slots,
            mode="solar_only",
            priority="opportunistic",
        )

    def _build_solar_only_slots(self, snapshot: WorldSnapshot) -> list[HourlySlot]:
        now = snapshot.now
        current_hour = now.replace(minute=0, second=0, microsecond=0)
        max_charge_w = _max_charge_kw(snapshot) * 1000.0
        profile = select_solar_only_profile(snapshot.cloud_coverage_pct)
        ev = snapshot.ev
        needed_kwh = max(0.0, (ev.target_soc_pct - ev.soc_pct) / 100.0 * ev.battery_kwh) if ev is not None else 0.0
        remaining_kwh = needed_kwh

        is_weekend = now.weekday() >= 5
        hourly_loads = (
            snapshot.consumption.hourly_weekend_w
            if snapshot.consumption.hourly_weekend_w
            else snapshot.consumption.hourly_weekday_w
        ) if is_weekend else snapshot.consumption.hourly_weekday_w

        forecast_map: dict[datetime, float] = {}
        for slot in snapshot.forecast:
            hour_key = slot.start.replace(minute=0, second=0, microsecond=0)
            forecast_map[hour_key] = forecast_map.get(hour_key, 0.0) + slot.kwh * 1000.0

        planned: list[HourlySlot] = []
        for price in sorted(snapshot.prices, key=lambda item: item.start):
            if remaining_kwh <= 1e-6:
                break
            hour_key = price.start.replace(minute=0, second=0, microsecond=0)
            if hour_key < current_hour:
                continue
            if hour_key == current_hour:
                surplus_w = _ev_surplus_w(snapshot)
                duration_h = max(0.0, 1.0 - (now.minute / 60.0) - (now.second / 3600.0))
            else:
                load_w = hourly_loads[hour_key.hour] if 0 <= hour_key.hour < 24 else snapshot.power.load_w
                surplus_w = max(0.0, forecast_map.get(hour_key, 0.0) - load_w)
                duration_h = 1.0
            if surplus_w < profile.start_surplus_w:
                continue
            phases, amps, power_w = _phase_and_power(surplus_w, max_charge_w)
            slot_kwh = min(remaining_kwh, power_w / 1000.0 * duration_h)
            if slot_kwh <= 0.0:
                continue
            remaining_kwh -= slot_kwh
            planned.append(
                HourlySlot(
                    start=hour_key,
                    strategy="CHARGE_SOLAR",
                    forecast_load_w=(
                        snapshot.power.load_w
                        if hour_key == current_hour
                        else (hourly_loads[hour_key.hour] if 0 <= hour_key.hour < 24 else snapshot.power.load_w)
                    ),
                    forecast_solar_w=(snapshot.power.pv_w if hour_key == current_hour else forecast_map.get(hour_key, 0.0)),
                    price_dkk=price.price_dkk,
                    planned_soc_pct=0.0,
                    planned_energy_kwh=round(slot_kwh, 3),
                    reason=(
                        f"{profile.label}: Solar-only vindue: {phases}-fase {amps:.1f}A ({power_w:.0f}W), "
                        f"{slot_kwh:.2f} kWh mod target"
                    ),
                )
            )
        return planned

    def _hybrid(self, snapshot: WorldSnapshot, departure: datetime) -> EVPlan:
        """Combine solar surplus with cheapest grid hours before departure."""
        return self._plan_deadline_mode(snapshot, departure, mode="hybrid")

    def _grid_only(self, snapshot: WorldSnapshot, departure: datetime) -> EVPlan:
        """Ensure the EV is charged by departure, regardless of source."""
        return self._plan_deadline_mode(snapshot, departure, mode="grid_only")

    def _plan_deadline_mode(
        self,
        snapshot: WorldSnapshot,
        departure: datetime,
        *,
        mode: str,
    ) -> EVPlan:
        ev = snapshot.ev
        now = snapshot.now

        needed_kwh = max(0.0, (ev.target_soc_pct - ev.soc_pct) / 100.0 * ev.battery_kwh)
        if needed_kwh < 0.1:
            return _idle("Maal-SOC naesten naaet", mode=mode, priority="deadline")

        max_charge_kw = _max_charge_kw(snapshot)
        if max_charge_kw <= 0:
            return _idle("Ingen laderkapacitet tilgaengelig", mode=mode, priority="deadline")

        current_hour = now.replace(minute=0, second=0, microsecond=0)
        departure_deadline = departure

        price_map: dict[datetime, float] = {}
        for ps in snapshot.prices:
            hour = ps.start.replace(minute=0, second=0, microsecond=0)
            price_map[hour] = ps.price_dkk

        live_surplus = _ev_surplus_w(snapshot)
        forecast_map = _forecast_power_by_hour(snapshot)
        planning_slots: list[dict] = []
        remaining = needed_kwh
        cursor = current_hour

        while cursor < departure_deadline and cursor < now + timedelta(hours=48):
            eff_start = max(cursor, now)
            eff_end = min(cursor + timedelta(hours=1), departure_deadline)
            duration_h = (eff_end - eff_start).total_seconds() / 3600.0
            if duration_h <= 0:
                cursor += timedelta(hours=1)
                continue

            solar_w = 0.0
            solar_kwh = 0.0
            if mode == "hybrid":
                surplus = live_surplus if cursor == current_hour else _forecast_surplus_w(snapshot, forecast_map, cursor)
                solar_w = min(max(0.0, surplus), max_charge_kw * 1000.0)
                solar_kwh = min(remaining, solar_w / 1000.0 * duration_h) if solar_w > 0 else 0.0
                remaining -= solar_kwh

            planning_slots.append(
                {
                    "start": cursor,
                    "duration_h": duration_h,
                    "price": price_map.get(cursor, float("inf")),
                    "solar_w": solar_w,
                    "solar_kwh": solar_kwh,
                    "grid_w": 0.0,
                    "grid_kwh": 0.0,
                }
            )
            cursor += timedelta(hours=1)

        current_slot = planning_slots[0] if planning_slots else None
        future_slots = planning_slots[1:] if len(planning_slots) > 1 else []
        deficit_reason: str | None = None
        if mode == "hybrid" and remaining > 0.01 and current_slot is not None:
            future_capacity_kwh = sum(
                max(0.0, max_charge_kw - slot["solar_w"] / 1000.0) * slot["duration_h"]
                for slot in future_slots
                if not math.isinf(slot["price"])
            )
            current_headroom_kwh = max(0.0, max_charge_kw - current_slot["solar_w"] / 1000.0) * current_slot["duration_h"]
            cheapest_future = min(
                (slot["price"] for slot in future_slots if not math.isinf(slot["price"])),
                default=float("inf"),
            )
            if remaining > future_capacity_kwh + 1e-6 and current_headroom_kwh > 0.0:
                deficit_now_kwh = min(remaining - future_capacity_kwh, current_headroom_kwh)
                current_slot["grid_kwh"] = deficit_now_kwh
                current_slot["grid_w"] = deficit_now_kwh / current_slot["duration_h"] * 1000.0
                remaining -= deficit_now_kwh
                deficit_reason = (
                    f"Bagud {remaining + deficit_now_kwh:.1f} kWh mod afgang - "
                    f"supplerer nu med {current_slot['grid_w']:.0f}W"
                )
            elif cheapest_future < current_slot["price"] * 0.7:
                deficit_reason = (
                    f"Mangler {remaining:.1f} kWh - venter pa billigere time "
                    f"({cheapest_future:.2f} kr vs {current_slot['price']:.2f} kr nu)"
                )

        if remaining > 0.01:
            indexed = sorted(
                ((i, slot) for i, slot in enumerate(planning_slots) if not math.isinf(slot["price"])),
                key=lambda item: (item[1]["price"], item[1]["start"]),
            )
            for idx, slot in indexed:
                if remaining <= 1e-6:
                    break
                if idx == 0 and deficit_reason is not None and "venter pa billigere time" in deficit_reason:
                    continue
                headroom_kw = max(0.0, max_charge_kw - slot["solar_w"] / 1000.0)
                grid_cap_kwh = headroom_kw * slot["duration_h"]
                if grid_cap_kwh <= 0:
                    continue
                grid_kwh = min(remaining, grid_cap_kwh)
                planning_slots[idx]["grid_w"] = grid_kwh / slot["duration_h"] * 1000.0
                planning_slots[idx]["grid_kwh"] = grid_kwh
                remaining -= grid_kwh

        hourly_slots = [
            HourlySlot(
                start=slot["start"],
                strategy=(
                    "CHARGE_HYBRID"
                    if slot["solar_w"] > 0 and slot["grid_w"] > 0
                    else ("CHARGE_SOLAR" if slot["solar_w"] > 0 else ("CHARGE_GRID" if slot["grid_w"] > 0 else "IDLE"))
                ),
                forecast_load_w=snapshot.power.load_w,
                forecast_solar_w=slot["solar_w"],
                price_dkk=slot["price"] if not math.isinf(slot["price"]) else 0.0,
                planned_soc_pct=0.0,
                planned_energy_kwh=round(slot["solar_kwh"] + slot["grid_kwh"], 3),
                solar_charge_w=slot["solar_w"],
                grid_charge_w=slot["grid_w"],
                reason="",
            )
            for slot in planning_slots
        ]

        current = planning_slots[0] if planning_slots else None
        should_charge_now = current is not None and (current["solar_w"] > 0 or current["grid_w"] > 0)
        if not should_charge_now:
            reason = deficit_reason or f"Ingen opladning planlagt i denne time - afgang {departure.strftime('%H:%M')}"
            return EVPlan(
                should_charge=False,
                target_power_w=0.0,
                phases=0,
                reason=reason,
                planned_slots=hourly_slots,
                mode=mode,
                priority="deadline",
            )

        total_w = current["solar_w"] + current["grid_w"]
        phases, amps, power_w = _phase_and_power(total_w, max_charge_kw * 1000.0)
        if mode == "hybrid":
            reason = deficit_reason or (
                f"Hybrid-plan: sol {current['solar_w']:.0f}W + net {current['grid_w']:.0f}W"
                f" - afgang {departure.strftime('%H:%M')}"
            )
        else:
            reason = f"Grid-plan: {current['grid_w']:.0f}W - afgang {departure.strftime('%H:%M')}"

        return EVPlan(
            should_charge=True,
            target_power_w=power_w,
            phases=phases,
            reason=reason,
            planned_slots=hourly_slots,
            mode=mode,
            priority="deadline",
        )


def _ev_surplus_w(snapshot: WorldSnapshot) -> float:
    """Solar power available for EV - battery excluded in both directions."""
    pv = snapshot.power.pv_w
    load = snapshot.power.load_w
    battery_abs = abs(snapshot.power.battery_w)
    return max(0.0, pv - load - battery_abs)


def _phase_and_power(surplus_w: float, max_charge_w: float) -> tuple[int, float, float]:
    """Return (phases, amps, actual_w) for given surplus, capped at max_charge_w."""
    effective = min(surplus_w, max_charge_w)
    if effective < _MIN_1PHASE_W:
        return 0, 0.0, 0.0
    if effective >= _MIN_3PHASE_W:
        amps = min(_MAX_AMPS, effective / 3.0 / _VOLTAGE)
        return 3, round(amps, 1), round(amps * 3.0 * _VOLTAGE)
    amps = min(_MAX_AMPS, effective / _VOLTAGE)
    return 1, round(amps, 1), round(amps * _VOLTAGE)


def _max_charge_kw(snapshot: WorldSnapshot) -> float:
    """Return configured EV charge power in kW."""
    return max(0.0, snapshot.ev_max_charge_kw)


def _forecast_power_by_hour(snapshot: WorldSnapshot) -> dict[datetime, float]:
    forecast_map: dict[datetime, float] = {}
    for slot in snapshot.forecast:
        hour_key = slot.start.replace(minute=0, second=0, microsecond=0)
        forecast_map[hour_key] = forecast_map.get(hour_key, 0.0) + slot.kwh * 1000.0
    return forecast_map


def _forecast_surplus_w(snapshot: WorldSnapshot, forecast_map: dict[datetime, float], hour_key: datetime) -> float:
    hourly_loads = snapshot.consumption.hourly_weekend_w if hour_key.weekday() >= 5 else snapshot.consumption.hourly_weekday_w
    load_w = hourly_loads[hour_key.hour] if 0 <= hour_key.hour < 24 else snapshot.power.load_w
    return max(0.0, forecast_map.get(hour_key, 0.0) - load_w)


def _idle(
    reason: str,
    *,
    mode: str,
    priority: str = "opportunistic",
    planned_slots: list[HourlySlot] | None = None,
) -> EVPlan:
    return EVPlan(
        should_charge=False,
        target_power_w=0.0,
        phases=0,
        reason=reason,
        planned_slots=planned_slots or [],
        mode=mode,
        priority=priority,
    )
