"""Battery planner - computes the economically preferred battery strategy.

Lag: planning
Afhaenger af: planning/base.py, planning/world_snapshot.py, core/economics.py
Maa IKKE importere: homeassistant, runtime/, control/

Centrale klasser:
  BatteryPlanner: implementerer Planner og returnerer BatteryPlan

Vigtige invarianter:
  - Pure function: samme input giver altid samme output
  - SAVE_SOLAR: live solsurplus > 50W
  - USE_BATTERY: kun naar forecast_load > forecast_solar i slotten, og price > weighted_cost
  - SELL_BATTERY: sell_price - weighted_cost >= min_charge_saving
  - ANTI_EXPORT: negativ/nul salgspris slaar eksport fra
  - Export planlaegges efter 12:00 kun hvis prishorisonten rækker forbi naeste midnat
  - Hysterese og strategi-confirmation hoerer hjemme i runtime/battery_runtime.py
"""
from __future__ import annotations

from datetime import datetime, timedelta
from functools import lru_cache

from ..core.economics import discharge_is_profitable, sell_is_profitable
from .base import BatteryPlan, HourlySlot, Planner
from .world_snapshot import WorldSnapshot

_SOLAR_SURPLUS_THRESHOLD_W = 50.0
_ALLOWED_DISCHARGE_SOLAR_THRESHOLD_W = 2000.0
_MEANINGFUL_SOLAR_WINDOW_W = 500.0
_MEANINGFUL_BATTERY_EXPORT_W = 500.0
_SELF_SUFFICIENCY_SOC_BUFFER_PCT = 5.0
_EVENING_RUSH_START_HOUR = 17
_EVENING_RUSH_END_HOUR = 22
_QUANTUM_KWH = 0.1
_DP_MAX_CACHE = 16384
_EXPORT_BUDGET_EPS_KWH = 0.05


class BatteryPlanner(Planner):
    """Plans battery strategy across the known price horizon."""

    def plan(self, snapshot: WorldSnapshot) -> BatteryPlan:
        bat = snapshot.battery

        if bat.capacity_kwh <= 0:
            return BatteryPlan(strategy="IDLE", hourly_plan=[], reason="Ugyldig batterikapacitet")

        now = snapshot.now
        current_hour = now.replace(minute=0, second=0, microsecond=0)
        prices = sorted(
            [p for p in snapshot.prices if p.start >= current_hour],
            key=lambda p: p.start,
        )
        if not prices:
            return BatteryPlan(strategy="IDLE", hourly_plan=[], reason="Ingen prisdata tilgaengelig")

        sell_price_map = {p.start: p.sell_price_dkk for p in snapshot.sell_prices}

        current_price = prices[0].price_dkk
        current_sell = sell_price_map.get(prices[0].start, prices[0].sell_price_dkk)
        weighted_cost = bat.weighted_cost_dkk

        hourly_plan = self._build_hourly_plan(snapshot, prices, sell_price_map)
        allowed_discharge_by_start = self._build_allowed_discharge_map(snapshot, prices, sell_price_map)
        hourly_plan = self._apply_allowed_discharge(hourly_plan, allowed_discharge_by_start)
        hourly_plan = self._apply_pre_solar_export(snapshot, hourly_plan)
        hourly_plan, export_context = self._apply_export_budget(snapshot, hourly_plan)
        can_defer_for_ev_solar = self._can_defer_for_ev_solar(snapshot, hourly_plan)
        target_soc_pct = self._target_soc_pct(snapshot, hourly_plan)
        metrics = self._plan_metrics(snapshot, hourly_plan)

        if current_price < 0:
            return BatteryPlan(
                strategy="ANTI_EXPORT",
                hourly_plan=hourly_plan,
                reason=f"Negativ koebspris ({current_price:.4f} kr/kWh) - koeber fra net",
                next_recharge_window=export_context["next_recharge_window"],
                target_soc_pct=target_soc_pct,
                export_stop_soc_pct=export_context["export_stop_soc_pct"],
                required_reserve_kwh=export_context["required_reserve_kwh"],
                export_budget_kwh=export_context["export_budget_kwh"],
                planned_export_kwh=export_context["planned_export_kwh"],
                can_defer_for_ev_solar=can_defer_for_ev_solar,
            )
        pv = snapshot.power.pv_w
        load = snapshot.power.load_w
        if pv - load > _SOLAR_SURPLUS_THRESHOLD_W:
            return BatteryPlan(
                strategy="SAVE_SOLAR",
                hourly_plan=hourly_plan,
                reason=f"Solcelleoverskud {pv - load:.0f}W - gemmer i batteri",
                next_recharge_window=export_context["next_recharge_window"],
                target_soc_pct=target_soc_pct,
                export_stop_soc_pct=export_context["export_stop_soc_pct"],
                required_reserve_kwh=export_context["required_reserve_kwh"],
                export_budget_kwh=export_context["export_budget_kwh"],
                planned_export_kwh=export_context["planned_export_kwh"],
                can_defer_for_ev_solar=can_defer_for_ev_solar,
            )

        current_slot = hourly_plan[0] if hourly_plan else None
        if current_slot is None:
            return BatteryPlan(strategy="IDLE", hourly_plan=[], reason="Tom plan")

        residual_load_w = max(0.0, current_slot.forecast_load_w - current_slot.forecast_solar_w)
        if current_slot.battery_export_w >= _MEANINGFUL_BATTERY_EXPORT_W:
            if snapshot.battery_sell_enabled and sell_is_profitable(
                current_sell,
                weighted_cost,
                snapshot.min_charge_saving_dkk,
            ):
                return BatteryPlan(
                    strategy="SELL_BATTERY",
                    hourly_plan=hourly_plan,
                    reason=(
                        f"Saelger batteri: sell {current_sell:.2f} - cost {weighted_cost:.2f}"
                        f" = {current_sell - weighted_cost:.2f} kr/kWh"
                    ),
                    next_recharge_window=export_context["next_recharge_window"],
                    target_soc_pct=target_soc_pct,
                    export_stop_soc_pct=export_context["export_stop_soc_pct"],
                    required_reserve_kwh=export_context["required_reserve_kwh"],
                    export_budget_kwh=export_context["export_budget_kwh"],
                    planned_export_kwh=export_context["planned_export_kwh"],
                    can_defer_for_ev_solar=can_defer_for_ev_solar,
                )

        if (
            (
                current_slot.strategy == "USE_BATTERY"
                or current_slot.allowed_discharge_w > 0
                or current_slot.discharge_to_load_w > 0
            )
            and residual_load_w > 0.0
            and discharge_is_profitable(current_price, weighted_cost)
        ):
            return BatteryPlan(
                strategy="USE_BATTERY",
                hourly_plan=hourly_plan,
                reason=(
                    f"Restunderskud {residual_load_w:.0f}W efter sol og pris "
                    f"{current_price:.2f} > vaegtet cost {weighted_cost:.2f} kr/kWh"
                ),
                next_recharge_window=export_context["next_recharge_window"],
                target_soc_pct=target_soc_pct,
                export_stop_soc_pct=export_context["export_stop_soc_pct"],
                required_reserve_kwh=export_context["required_reserve_kwh"],
                export_budget_kwh=export_context["export_budget_kwh"],
                planned_export_kwh=export_context["planned_export_kwh"],
                can_defer_for_ev_solar=can_defer_for_ev_solar,
            )

        if current_slot.grid_charge_w > 0 and (
            metrics["available_kwh"] < metrics["energy_needed_before_next_solar_kwh"]
            or metrics["expected_saving_per_kwh"] > snapshot.min_charge_saving_dkk
        ):
            return BatteryPlan(
                strategy=current_slot.strategy if current_slot.strategy in ("CHARGE_GRID", "CHARGE_NIGHT") else "CHARGE_GRID",
                hourly_plan=hourly_plan,
                reason=current_slot.reason or "Planlagt opladning i billig time",
                next_recharge_window=export_context["next_recharge_window"],
                target_soc_pct=target_soc_pct,
                export_stop_soc_pct=export_context["export_stop_soc_pct"],
                required_reserve_kwh=export_context["required_reserve_kwh"],
                export_budget_kwh=export_context["export_budget_kwh"],
                planned_export_kwh=export_context["planned_export_kwh"],
                can_defer_for_ev_solar=can_defer_for_ev_solar,
            )

        if (
            current_price <= max(weighted_cost, snapshot.cheap_grid_threshold_dkk)
            and metrics["battery_has_headroom"]
            and metrics["future_discharge_exists"]
        ):
            return BatteryPlan(
                strategy="SAVE_SOLAR",
                hourly_plan=hourly_plan,
                reason=(
                    f"Billig netstroem ({current_price:.2f} kr) - holder batteriet "
                    f"til dyrere timer senere"
                ),
                next_recharge_window=export_context["next_recharge_window"],
                target_soc_pct=target_soc_pct,
                export_stop_soc_pct=export_context["export_stop_soc_pct"],
                required_reserve_kwh=export_context["required_reserve_kwh"],
                export_budget_kwh=export_context["export_budget_kwh"],
                planned_export_kwh=export_context["planned_export_kwh"],
                can_defer_for_ev_solar=can_defer_for_ev_solar,
            )

        return BatteryPlan(
            strategy="IDLE",
            hourly_plan=hourly_plan,
            reason="Ingen rentabel handling i denne time",
            next_recharge_window=export_context["next_recharge_window"],
            target_soc_pct=target_soc_pct,
            export_stop_soc_pct=export_context["export_stop_soc_pct"],
            required_reserve_kwh=export_context["required_reserve_kwh"],
            export_budget_kwh=export_context["export_budget_kwh"],
            planned_export_kwh=export_context["planned_export_kwh"],
            can_defer_for_ev_solar=can_defer_for_ev_solar,
        )

    def _build_hourly_plan(
        self,
        snapshot: WorldSnapshot,
        prices: list,
        sell_price_map: dict,
    ) -> list[HourlySlot]:
        """Run DP over price horizon and return HourlySlot list."""
        if not prices:
            return []

        bat = snapshot.battery
        now = snapshot.now
        is_weekend = now.weekday() >= 5
        cons = snapshot.consumption
        hourly_w = cons.hourly_weekend_w if is_weekend else cons.hourly_weekday_w

        forecast_map: dict[datetime, float] = {}
        for slot in snapshot.forecast:
            hour_key = slot.start.replace(minute=0, second=0, microsecond=0)
            forecast_map[hour_key] = forecast_map.get(hour_key, 0.0) + slot.kwh

        has_tomorrow = _has_prices_beyond_midnight(prices, now)
        weighted_cost = bat.weighted_cost_dkk
        wear_cost = snapshot.battery_cost_per_kwh_dkk
        min_saving = snapshot.min_charge_saving_dkk
        charge_rate = bat.charge_rate_kw

        usable_kwh = bat.capacity_kwh * (bat.max_soc_pct - bat.min_soc_pct) / 100.0
        available_kwh = max(
            0.0,
            (bat.soc_pct - bat.min_soc_pct) / 100.0 * bat.capacity_kwh,
        )

        slots = []
        for ps in prices:
            hour_key = ps.start.replace(minute=0, second=0, microsecond=0)
            h = ps.start.hour
            load_w = hourly_w[h] if 0 <= h < 24 else 500.0
            load_kwh = load_w / 1000.0
            solar_kwh = forecast_map.get(hour_key, 0.0)
            net_load_kwh = max(0.0, load_kwh - solar_kwh)
            solar_surplus_kwh = max(0.0, solar_kwh - load_kwh)
            sell = sell_price_map.get(ps.start, ps.sell_price_dkk)
            slots.append(
                {
                    "start": ps.start,
                    "price": ps.price_dkk,
                    "sell": sell,
                    "load_w": load_w,
                    "solar_kwh": solar_kwh,
                    "net_load_kwh": net_load_kwh,
                    "solar_surplus_kwh": solar_surplus_kwh,
                }
            )

        evening_target_kwh = self._target_kwh_before_evening_rush(slots, snapshot)

        q = _QUANTUM_KWH
        capacity_u = max(1, int(round(usable_kwh / q)))
        initial_u = int(round(min(usable_kwh, available_kwh) / q))
        charge_limit_u = max(0, int(round(charge_rate / q)))

        net_load_u = [int(round(min(s["net_load_kwh"], charge_rate) / q)) for s in slots]
        solar_u = [int(round(min(s["solar_surplus_kwh"], charge_rate) / q)) for s in slots]

        @lru_cache(maxsize=_DP_MAX_CACHE)
        def _solve(idx: int, stored: int) -> tuple[float, tuple]:
            if idx >= len(slots):
                return 0.0, ()
            s = slots[idx]
            max_solar_store = min(solar_u[idx], max(0, capacity_u - stored))

            best_cost = float("inf")
            best_acts: tuple = ()

            for solar_store_units in range(max_solar_store + 1):
                after_solar = min(capacity_u, stored + solar_store_units)
                direct_solar_export = max(0, solar_u[idx] - solar_store_units)
                max_d = min(charge_limit_u, after_solar)
                max_c = min(charge_limit_u, capacity_u - after_solar)

                for d_units in range(max_d + 1):
                    c_range = range(0, max_c + 1) if d_units == 0 else range(0, 1)
                    for c_units in c_range:
                        d_to_load = min(net_load_u[idx], d_units)
                        export = max(0, d_units - d_to_load)
                        export_ok = has_tomorrow or s["start"].hour < 12
                        if (
                            not export_ok
                            and (
                                export > 0
                                or (direct_solar_export > 0 and solar_store_units < max_solar_store)
                            )
                        ):
                            continue
                        if solar_store_units > 0 and export > 0:
                            continue
                        if direct_solar_export > 0 and c_units > 0:
                            continue
                        if (
                            direct_solar_export > 0
                            and solar_store_units < max_solar_store
                            and evening_target_kwh is not None
                            and not self._can_direct_export_solar(
                                idx=idx,
                                stored=stored,
                                solar_store_units=solar_store_units,
                                capacity_u=capacity_u,
                                q=q,
                                slots=slots,
                                evening_target_kwh=evening_target_kwh,
                            )
                        ):
                            continue
                        next_stored = after_solar - d_units + c_units
                        grid_import = max(0, net_load_u[idx] - d_to_load) + c_units
                        sell_credit = (
                            max(0.0, s["sell"] - min_saving)
                            if snapshot.battery_sell_enabled
                            else 0.0
                        )
                        direct_solar_sell_credit = (
                            max(0.0, s["sell"] - min_saving)
                            if snapshot.battery_sell_enabled
                            else 0.0
                        )
                        cost = (
                            grid_import * q * s["price"]
                            + c_units * q * wear_cost
                            + solar_store_units * q * s["sell"]
                            + d_units * q * weighted_cost
                            - export * q * sell_credit
                            - direct_solar_export * q * direct_solar_sell_credit
                        )
                        fut_cost, fut_acts = _solve(idx + 1, next_stored)
                        total = cost + fut_cost
                        if total < best_cost - 1e-9:
                            best_cost = total
                            best_acts = ((solar_store_units, d_units, c_units),) + fut_acts

            return best_cost, best_acts

        _, best_actions = _solve(0, initial_u)

        stored_kwh = min(usable_kwh, available_kwh)
        hourly_plan: list[HourlySlot] = []

        for slot, (solar_store_units, d_units, c_units) in zip(slots, best_actions):
            solar_charge_kwh = min(
                solar_store_units * q,
                slot["solar_surplus_kwh"],
                charge_rate,
                max(0.0, usable_kwh - stored_kwh),
            )
            stored_kwh += solar_charge_kwh
            direct_solar_export_kwh = max(0.0, slot["solar_surplus_kwh"] - solar_charge_kwh)

            d_kwh = min(d_units * q, charge_rate, stored_kwh)
            d_to_load_kwh = min(slot["net_load_kwh"], d_kwh)
            battery_export_kwh = max(0.0, d_kwh - d_to_load_kwh)
            export_ok = has_tomorrow or slot["start"].hour < 12
            if not export_ok and battery_export_kwh > 0:
                stored_kwh += battery_export_kwh
                battery_export_kwh = 0.0
                d_kwh = d_to_load_kwh
            if battery_export_kwh > 0 and (
                not snapshot.battery_sell_enabled or (slot["sell"] - weighted_cost) < min_saving
            ):
                stored_kwh += battery_export_kwh
                battery_export_kwh = 0.0
                d_kwh = d_to_load_kwh
            stored_kwh -= d_kwh

            c_kwh = min(
                c_units * q,
                max(0.0, charge_rate - solar_charge_kwh),
                max(0.0, usable_kwh - stored_kwh),
            )
            stored_kwh += c_kwh

            soc_end = bat.min_soc_pct + stored_kwh / bat.capacity_kwh * 100.0
            soc_end = max(bat.min_soc_pct, min(bat.max_soc_pct, soc_end))

            if battery_export_kwh > 0:
                strategy = "SELL_BATTERY"
                reason = f"Eksporter {battery_export_kwh:.2f} kWh @ {slot['sell']:.2f} kr/kWh"
            elif d_to_load_kwh > 0:
                strategy = "USE_BATTERY"
                reason = f"Aflad {d_to_load_kwh:.2f} kWh, pris {slot['price']:.2f} kr/kWh"
            elif c_kwh > 0:
                hour = slot["start"].hour
                strategy = "CHARGE_NIGHT" if (hour >= 21 or hour < 6) else "CHARGE_GRID"
                reason = f"Lad {c_kwh:.2f} kWh @ {slot['price']:.2f} kr/kWh"
            elif solar_charge_kwh > 0:
                strategy = "SAVE_SOLAR"
                reason = f"Sol {solar_charge_kwh:.2f} kWh gemmes i batteri"
            elif direct_solar_export_kwh > 0:
                strategy = "IDLE"
                reason = f"Sol {direct_solar_export_kwh:.2f} kWh eksporteres direkte"
            else:
                strategy = "IDLE"
                reason = ""

            hourly_plan.append(
                HourlySlot(
                    start=slot["start"],
                    strategy=strategy,
                    forecast_load_w=slot["load_w"],
                    forecast_solar_w=slot["solar_kwh"] * 1000.0,
                    price_dkk=slot["price"],
                    planned_soc_pct=round(soc_end, 1),
                    reason=reason,
                    grid_charge_w=round(c_kwh * 1000.0, 1),
                    solar_charge_w=round(solar_charge_kwh * 1000.0, 1),
                    discharge_w=round(d_kwh * 1000.0, 1),
                    discharge_to_load_w=round(d_to_load_kwh * 1000.0, 1),
                    battery_export_w=round(battery_export_kwh * 1000.0, 1),
                    grid_import_w=round((max(0.0, slot["net_load_kwh"] - d_to_load_kwh) + c_kwh) * 1000.0, 1),
                    sell_price_dkk=slot["sell"],
                    discharge_value_dkk=round(slot["price"] - weighted_cost, 4),
                )
            )

        return hourly_plan

    def _target_kwh_before_evening_rush(
        self,
        slots: list[dict],
        snapshot: WorldSnapshot,
    ) -> float | None:
        if not slots:
            return None
        rush_index = next(
            (
                idx
                for idx, slot in enumerate(slots)
                if _EVENING_RUSH_START_HOUR <= slot["start"].hour < _EVENING_RUSH_END_HOUR
            ),
            None,
        )
        if rush_index is None:
            return None
        bat = snapshot.battery
        reserve_pct = min(
            bat.max_soc_pct,
            bat.min_soc_pct + _SELF_SUFFICIENCY_SOC_BUFFER_PCT,
        )
        reserve_kwh = bat.capacity_kwh * max(0.0, reserve_pct - bat.min_soc_pct) / 100.0
        evening_load_kwh = sum(
            max(0.0, slots[idx]["net_load_kwh"])
            for idx in range(rush_index, len(slots))
            if _EVENING_RUSH_START_HOUR <= slots[idx]["start"].hour < _EVENING_RUSH_END_HOUR
        )
        return min(
            bat.capacity_kwh * (bat.max_soc_pct - bat.min_soc_pct) / 100.0,
            reserve_kwh + evening_load_kwh,
        )

    def _can_direct_export_solar(
        self,
        *,
        idx: int,
        stored: int,
        solar_store_units: int,
        capacity_u: int,
        q: float,
        slots: list[dict],
        evening_target_kwh: float,
    ) -> bool:
        current = slots[idx]
        if current["start"].hour >= _EVENING_RUSH_START_HOUR:
            return False
        if current["solar_surplus_kwh"] <= 0:
            return True
        after_solar_kwh = min(capacity_u, stored + solar_store_units) * q
        future_charge_kwh = 0.0
        for future in slots[idx + 1 :]:
            if future["start"].hour >= _EVENING_RUSH_START_HOUR:
                break
            future_charge_kwh += max(0.0, future["solar_surplus_kwh"])
        return after_solar_kwh + future_charge_kwh >= evening_target_kwh - 1e-9

    def _build_allowed_discharge_map(
        self,
        snapshot: WorldSnapshot,
        prices: list,
        sell_price_map: dict,
    ) -> dict[datetime, float]:
        no_solar_snapshot = WorldSnapshot(
            now=snapshot.now,
            power=snapshot.power,
            battery=snapshot.battery,
            prices=snapshot.prices,
            sell_prices=snapshot.sell_prices,
            forecast=[],
            consumption=snapshot.consumption,
            ev=snapshot.ev,
            charger=snapshot.charger,
            flex_loads=list(snapshot.flex_loads),
            ev_departure=snapshot.ev_departure,
            ev_mode=snapshot.ev_mode,
            min_charge_saving_dkk=snapshot.min_charge_saving_dkk,
            battery_cost_per_kwh_dkk=snapshot.battery_cost_per_kwh_dkk,
            cheap_grid_threshold_dkk=snapshot.cheap_grid_threshold_dkk,
            battery_sell_enabled=snapshot.battery_sell_enabled,
            ev_charging_enabled=snapshot.ev_charging_enabled,
        )
        no_solar_plan = self._build_hourly_plan(no_solar_snapshot, prices, sell_price_map)
        allowed: dict[datetime, float] = {}
        for slot in no_solar_plan:
            if slot.discharge_to_load_w <= 0:
                continue
            if slot.forecast_solar_w >= _ALLOWED_DISCHARGE_SOLAR_THRESHOLD_W:
                continue
            allowed[slot.start] = slot.discharge_to_load_w
        return allowed

    def _apply_allowed_discharge(
        self,
        hourly_plan: list[HourlySlot],
        allowed_discharge_by_start: dict[datetime, float],
    ) -> list[HourlySlot]:
        updated: list[HourlySlot] = []
        for slot in hourly_plan:
            allowed_w = round(allowed_discharge_by_start.get(slot.start, 0.0), 1)
            if slot.forecast_solar_w >= _ALLOWED_DISCHARGE_SOLAR_THRESHOLD_W:
                allowed_w = 0.0
            if allowed_w > 0 and slot.strategy == "IDLE":
                updated.append(
                    HourlySlot(
                        start=slot.start,
                        strategy="USE_BATTERY",
                        forecast_load_w=slot.forecast_load_w,
                        forecast_solar_w=slot.forecast_solar_w,
                        price_dkk=slot.price_dkk,
                        planned_soc_pct=slot.planned_soc_pct,
                        reason=slot.reason,
                        grid_charge_w=slot.grid_charge_w,
                        solar_charge_w=slot.solar_charge_w,
                        discharge_w=allowed_w,
                        discharge_to_load_w=allowed_w,
                        battery_export_w=0.0,
                        grid_import_w=max(0.0, slot.forecast_load_w - slot.forecast_solar_w - allowed_w),
                        sell_price_dkk=slot.sell_price_dkk,
                        discharge_value_dkk=slot.discharge_value_dkk,
                        allowed_discharge_w=allowed_w,
                    )
                )
                continue
            updated.append(
                HourlySlot(
                    start=slot.start,
                    strategy=slot.strategy,
                    forecast_load_w=slot.forecast_load_w,
                    forecast_solar_w=slot.forecast_solar_w,
                    price_dkk=slot.price_dkk,
                    planned_soc_pct=slot.planned_soc_pct,
                    reason=slot.reason,
                    grid_charge_w=slot.grid_charge_w,
                    solar_charge_w=slot.solar_charge_w,
                    discharge_w=slot.discharge_w,
                    discharge_to_load_w=slot.discharge_to_load_w,
                    battery_export_w=slot.battery_export_w,
                    grid_import_w=slot.grid_import_w,
                    sell_price_dkk=slot.sell_price_dkk,
                    discharge_value_dkk=slot.discharge_value_dkk,
                    allowed_discharge_w=allowed_w,
                )
            )
        return updated

    def _apply_pre_solar_export(
        self,
        snapshot: WorldSnapshot,
        hourly_plan: list[HourlySlot],
    ) -> list[HourlySlot]:
        if not hourly_plan or not snapshot.battery_sell_enabled:
            return hourly_plan

        target_soc_pct, target_index = self._pre_solar_target(hourly_plan, snapshot)
        if target_index is None:
            return hourly_plan

        target_soc_pct = min(snapshot.battery.max_soc_pct, max(snapshot.battery.min_soc_pct, target_soc_pct))
        plan = [HourlySlot(**slot.__dict__) for slot in hourly_plan]
        capacity_kwh = max(snapshot.battery.capacity_kwh, 0.1)
        charge_rate_kwh = snapshot.battery.charge_rate_kw
        weighted_cost = snapshot.battery.weighted_cost_dkk
        min_saving = snapshot.min_charge_saving_dkk
        target_margin_eps = 1e-6

        for idx, slot in enumerate(plan[:target_index]):
            sell_price = slot.sell_price_dkk if slot.sell_price_dkk is not None else slot.price_dkk
            if not sell_is_profitable(sell_price, weighted_cost, min_saving):
                continue

            discharge_to_load_kwh = slot.discharge_to_load_w / 1000.0
            charge_headroom_kwh = max(0.0, charge_rate_kwh - discharge_to_load_kwh)
            if charge_headroom_kwh <= 0.0:
                continue

            min_margin_pct = min(
                max(0.0, future_slot.planned_soc_pct - target_soc_pct)
                for future_slot in plan[idx:target_index + 1]
            )
            max_extra_kwh = min(charge_headroom_kwh, min_margin_pct / 100.0 * capacity_kwh)
            if max_extra_kwh <= target_margin_eps:
                continue

            slot.discharge_w = round(slot.discharge_w + max_extra_kwh * 1000.0, 1)
            slot.battery_export_w = round(slot.battery_export_w + max_extra_kwh * 1000.0, 1)
            slot.strategy = "SELL_BATTERY"
            slot.reason = (
                f"Eksporterer ned mod reserve {target_soc_pct:.0f}% før selvforsynende solvindue"
            )
            for future_slot in plan[idx:]:
                future_slot.planned_soc_pct = round(
                    max(snapshot.battery.min_soc_pct, future_slot.planned_soc_pct - max_extra_kwh / capacity_kwh * 100.0),
                    1,
                )

        return plan

    def _apply_export_budget(
        self,
        snapshot: WorldSnapshot,
        hourly_plan: list[HourlySlot],
    ) -> tuple[list[HourlySlot], dict[str, float | datetime | None]]:
        if not hourly_plan:
            return hourly_plan, {
                "next_recharge_window": None,
                "export_stop_soc_pct": None,
                "required_reserve_kwh": 0.0,
                "export_budget_kwh": 0.0,
                "planned_export_kwh": 0.0,
            }

        next_recharge_index = self._next_recharge_index(hourly_plan)
        if next_recharge_index is None:
            return hourly_plan, {
                "next_recharge_window": None,
                "export_stop_soc_pct": None,
                "required_reserve_kwh": 0.0,
                "export_budget_kwh": 0.0,
                "planned_export_kwh": 0.0,
            }

        next_recharge_window = hourly_plan[next_recharge_index].start
        reserve_buffer_kwh = snapshot.battery.capacity_kwh * _SELF_SUFFICIENCY_SOC_BUFFER_PCT / 100.0
        required_self_use_kwh = sum(
            max(0.0, slot.discharge_to_load_w) / 1000.0
            for slot in hourly_plan[:next_recharge_index]
        )
        required_reserve_kwh = max(0.0, required_self_use_kwh + reserve_buffer_kwh)
        available_kwh = max(
            0.0,
            (snapshot.battery.soc_pct - snapshot.battery.min_soc_pct) / 100.0 * snapshot.battery.capacity_kwh,
        )
        export_budget_kwh = max(0.0, available_kwh - required_reserve_kwh)
        export_stop_soc_pct = min(
            snapshot.battery.max_soc_pct,
            snapshot.battery.min_soc_pct + required_reserve_kwh / max(snapshot.battery.capacity_kwh, 0.1) * 100.0,
        )

        if export_budget_kwh <= _EXPORT_BUDGET_EPS_KWH:
            return self._clear_export_slots(hourly_plan), {
                "next_recharge_window": next_recharge_window,
                "export_stop_soc_pct": round(export_stop_soc_pct, 2),
                "required_reserve_kwh": round(required_reserve_kwh, 3),
                "export_budget_kwh": 0.0,
                "planned_export_kwh": 0.0,
            }

        candidate_indices = [
            idx
            for idx, slot in enumerate(hourly_plan[:next_recharge_index])
            if slot.battery_export_w > 0.0
        ]
        if not candidate_indices:
            return hourly_plan, {
                "next_recharge_window": next_recharge_window,
                "export_stop_soc_pct": round(export_stop_soc_pct, 2),
                "required_reserve_kwh": round(required_reserve_kwh, 3),
                "export_budget_kwh": round(export_budget_kwh, 3),
                "planned_export_kwh": 0.0,
            }

        ranked_indices = sorted(
            candidate_indices,
            key=lambda idx: (
                hourly_plan[idx].sell_price_dkk if hourly_plan[idx].sell_price_dkk is not None else hourly_plan[idx].price_dkk,
                hourly_plan[idx].price_dkk,
            ),
            reverse=True,
        )
        remaining_export_kwh = export_budget_kwh
        allowed_export_by_index: dict[int, float] = {}
        for idx in ranked_indices:
            slot = hourly_plan[idx]
            original_export_kwh = slot.battery_export_w / 1000.0
            allowed_export_kwh = min(original_export_kwh, remaining_export_kwh)
            if allowed_export_kwh > _EXPORT_BUDGET_EPS_KWH:
                allowed_export_by_index[idx] = allowed_export_kwh
                remaining_export_kwh -= allowed_export_kwh
            if remaining_export_kwh <= _EXPORT_BUDGET_EPS_KWH:
                break

        plan: list[HourlySlot] = []
        for idx, slot in enumerate(hourly_plan):
            allowed_export_kwh = allowed_export_by_index.get(idx, 0.0)
            plan.append(self._slot_with_limited_export(slot, allowed_export_kwh))
        plan = self._recompute_planned_soc(snapshot, plan)

        used_export_kwh = sum(allowed_export_by_index.values())
        return plan, {
            "next_recharge_window": next_recharge_window,
            "export_stop_soc_pct": round(export_stop_soc_pct, 2),
            "required_reserve_kwh": round(required_reserve_kwh, 3),
            "export_budget_kwh": round(export_budget_kwh, 3),
            "planned_export_kwh": round(max(0.0, used_export_kwh), 3),
        }

    def _clear_export_slots(self, hourly_plan: list[HourlySlot]) -> list[HourlySlot]:
        return [self._slot_with_limited_export(slot, 0.0) for slot in hourly_plan]

    def _slot_with_limited_export(self, slot: HourlySlot, allowed_export_kwh: float) -> HourlySlot:
        discharge_to_load_w = max(0.0, slot.discharge_to_load_w)
        export_w = round(max(0.0, allowed_export_kwh) * 1000.0, 1)
        discharge_w = round(discharge_to_load_w + export_w, 1)
        grid_import_w = round(max(0.0, slot.forecast_load_w - slot.forecast_solar_w - discharge_to_load_w), 1)

        strategy = slot.strategy
        reason = slot.reason
        if export_w > 0.0:
            strategy = "SELL_BATTERY"
            reason = f"Eksporter {allowed_export_kwh:.2f} kWh @ {(slot.sell_price_dkk or slot.price_dkk):.2f} kr/kWh"
        elif discharge_to_load_w > 0.0:
            strategy = "USE_BATTERY"
            reason = f"Aflad {discharge_to_load_w / 1000.0:.2f} kWh til huslast"
        elif strategy == "SELL_BATTERY":
            strategy = "IDLE"
            reason = ""

        return HourlySlot(
            start=slot.start,
            strategy=strategy,
            forecast_load_w=slot.forecast_load_w,
            forecast_solar_w=slot.forecast_solar_w,
            price_dkk=slot.price_dkk,
            planned_soc_pct=slot.planned_soc_pct,
            reason=reason,
            planned_energy_kwh=slot.planned_energy_kwh,
            grid_charge_w=slot.grid_charge_w,
            solar_charge_w=slot.solar_charge_w,
            discharge_w=discharge_w,
            discharge_to_load_w=discharge_to_load_w,
            battery_export_w=export_w,
            grid_import_w=grid_import_w,
            sell_price_dkk=slot.sell_price_dkk,
            discharge_value_dkk=slot.discharge_value_dkk,
            allowed_discharge_w=slot.allowed_discharge_w,
        )

    def _recompute_planned_soc(
        self,
        snapshot: WorldSnapshot,
        hourly_plan: list[HourlySlot],
    ) -> list[HourlySlot]:
        if not hourly_plan:
            return hourly_plan

        capacity_kwh = max(snapshot.battery.capacity_kwh, 0.1)
        usable_kwh = capacity_kwh * (snapshot.battery.max_soc_pct - snapshot.battery.min_soc_pct) / 100.0
        stored_kwh = max(
            0.0,
            min(
                usable_kwh,
                (snapshot.battery.soc_pct - snapshot.battery.min_soc_pct) / 100.0 * capacity_kwh,
            ),
        )

        recomputed: list[HourlySlot] = []
        for slot in hourly_plan:
            stored_kwh = min(usable_kwh, stored_kwh + slot.solar_charge_w / 1000.0 + slot.grid_charge_w / 1000.0)
            stored_kwh = max(0.0, stored_kwh - slot.discharge_w / 1000.0)
            soc_end = snapshot.battery.min_soc_pct + stored_kwh / capacity_kwh * 100.0
            soc_end = max(snapshot.battery.min_soc_pct, min(snapshot.battery.max_soc_pct, soc_end))
            recomputed.append(
                HourlySlot(
                    start=slot.start,
                    strategy=slot.strategy,
                    forecast_load_w=slot.forecast_load_w,
                    forecast_solar_w=slot.forecast_solar_w,
                    price_dkk=slot.price_dkk,
                    planned_soc_pct=round(soc_end, 1),
                    reason=slot.reason,
                    planned_energy_kwh=slot.planned_energy_kwh,
                    grid_charge_w=slot.grid_charge_w,
                    solar_charge_w=slot.solar_charge_w,
                    discharge_w=slot.discharge_w,
                    discharge_to_load_w=slot.discharge_to_load_w,
                    battery_export_w=slot.battery_export_w,
                    grid_import_w=slot.grid_import_w,
                    sell_price_dkk=slot.sell_price_dkk,
                    discharge_value_dkk=slot.discharge_value_dkk,
                    allowed_discharge_w=slot.allowed_discharge_w,
                )
            )
        return recomputed

    @staticmethod
    def _next_recharge_index(hourly_plan: list[HourlySlot]) -> int | None:
        for idx, slot in enumerate(hourly_plan[1:], start=1):
            if slot.grid_charge_w > 0.0 or slot.solar_charge_w > 0.0:
                return idx
        return None

    def _plan_metrics(
        self,
        snapshot: WorldSnapshot,
        hourly_plan: list[HourlySlot],
    ) -> dict[str, float | bool]:
        next_solar_window = None
        for slot in hourly_plan:
            if slot.start <= snapshot.now:
                continue
            if slot.forecast_solar_w >= _MEANINGFUL_SOLAR_WINDOW_W:
                next_solar_window = slot.start
                break

        energy_needed_before_next_solar_kwh = 0.0
        day_deficit_kwh = 0.0
        for slot in hourly_plan:
            slot_net_load_kwh = max(0.0, (slot.forecast_load_w - slot.forecast_solar_w) / 1000.0)
            if next_solar_window is not None and slot.start < next_solar_window:
                energy_needed_before_next_solar_kwh += slot_net_load_kwh
            else:
                day_deficit_kwh += slot_net_load_kwh
        if next_solar_window is None:
            energy_needed_before_next_solar_kwh = sum(
                max(0.0, (slot.forecast_load_w - slot.forecast_solar_w) / 1000.0)
                for slot in hourly_plan
            )
            day_deficit_kwh = 0.0
        energy_needed_before_next_solar_kwh *= 1.10

        total_planned_charge_kwh = sum(slot.grid_charge_w for slot in hourly_plan) / 1000.0
        expected_saving_dkk = (
            sum(
                (slot.discharge_to_load_w / 1000.0) * max(0.0, slot.price_dkk - snapshot.battery.weighted_cost_dkk)
                + (slot.battery_export_w / 1000.0)
                * max(0.0, (slot.sell_price_dkk or slot.price_dkk) - snapshot.battery.weighted_cost_dkk)
                for slot in hourly_plan
            )
            - sum(
                (slot.grid_charge_w / 1000.0) * (slot.price_dkk + snapshot.battery_cost_per_kwh_dkk)
                for slot in hourly_plan
            )
        )
        available_kwh = max(
            0.0,
            (snapshot.battery.soc_pct - snapshot.battery.min_soc_pct) / 100.0 * snapshot.battery.capacity_kwh,
        )
        usable_kwh = snapshot.battery.capacity_kwh * (
            snapshot.battery.max_soc_pct - snapshot.battery.min_soc_pct
        ) / 100.0
        return {
            "energy_needed_before_next_solar_kwh": energy_needed_before_next_solar_kwh,
            "day_deficit_kwh": day_deficit_kwh,
            "planned_self_use_kwh": sum(slot.discharge_to_load_w for slot in hourly_plan) / 1000.0,
            "future_recharge_kwh": sum(
                (slot.solar_charge_w + slot.grid_charge_w) / 1000.0 for slot in hourly_plan[1:]
            ),
            "expected_saving_per_kwh": (
                expected_saving_dkk / total_planned_charge_kwh if total_planned_charge_kwh > 0 else 0.0
            ),
            "available_kwh": available_kwh,
            "battery_has_headroom": available_kwh < usable_kwh * 0.9,
            "future_discharge_exists": any(slot.discharge_w > 0 for slot in hourly_plan[1:]),
            "next_solar_window": next_solar_window,
        }

    def _can_defer_for_ev_solar(
        self,
        snapshot: WorldSnapshot,
        hourly_plan: list[HourlySlot],
    ) -> bool:
        """True when today's stationary battery can wait for later solar slots.

        We only allow EV solar-only preemption when the current slot wants to
        store solar and later SAVE_SOLAR slots can replace that same SOC gain.
        """
        if not hourly_plan:
            return False

        current = hourly_plan[0]
        if current.strategy != "SAVE_SOLAR":
            return False

        prev_soc = snapshot.battery.soc_pct
        current_gain_pct = max(0.0, current.planned_soc_pct - prev_soc)
        if current_gain_pct <= 0.0:
            return False

        future_gain_pct = 0.0
        prev_soc = current.planned_soc_pct
        for slot in hourly_plan[1:]:
            gain_pct = max(0.0, slot.planned_soc_pct - prev_soc)
            prev_soc = slot.planned_soc_pct
            if slot.strategy in {"SAVE_SOLAR", "CHARGE_GRID", "CHARGE_NIGHT"}:
                future_gain_pct += gain_pct

        return future_gain_pct + 1e-6 >= current_gain_pct

    def _target_soc_pct(
        self,
        snapshot: WorldSnapshot,
        hourly_plan: list[HourlySlot],
    ) -> float | None:
        """Return the relevant target SOC for control-layer charge strategies."""
        charge_slots = [slot for slot in hourly_plan if slot.strategy in {"CHARGE_GRID", "CHARGE_NIGHT", "SAVE_SOLAR"}]
        if not charge_slots:
            return None
        return max(slot.planned_soc_pct for slot in charge_slots)

    def _pre_solar_target(
        self,
        hourly_plan: list[HourlySlot],
        snapshot: WorldSnapshot,
    ) -> tuple[float, int | None]:
        for idx, slot in enumerate(hourly_plan):
            if slot.forecast_solar_w >= max(slot.forecast_load_w, _MEANINGFUL_SOLAR_WINDOW_W):
                if idx == 0:
                    return snapshot.battery.min_soc_pct + _SELF_SUFFICIENCY_SOC_BUFFER_PCT, None
                return snapshot.battery.min_soc_pct + _SELF_SUFFICIENCY_SOC_BUFFER_PCT, idx - 1
        return snapshot.battery.min_soc_pct + _SELF_SUFFICIENCY_SOC_BUFFER_PCT, None


def _has_prices_beyond_midnight(prices: list, now: datetime) -> bool:
    """True if any price slot starts after the next local midnight."""
    next_midnight = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return any(p.start >= next_midnight for p in prices)
