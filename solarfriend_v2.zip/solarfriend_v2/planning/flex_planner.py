"""Flex load planlegger — finder optimale starttidspunkter for registrerede flex loads.

Lag: planning
Afhænger af: planning/base.py, planning/world_snapshot.py
Må IKKE importere: homeassistant, runtime/, control/

Centrale klasser:
  FlexPlanner: implementerer Planner — returnerer FlexPlan med GO_NOW/SCHEDULED/DEADLINE_FORCED

Flex load registreres via HA service (ikke config flow):
  solarfriend_v2.register_flex_load: entity_id, needed_w, duration_minutes, deadline
  solarfriend_v2.cancel_flex_load:   entity_id

Vigtige invarianter:
  - entity_id er unik nøgle — register er en upsert (overskriver eksisterende)
  - Start er one-way — ingen stop-signal sendes
  - Deadline-fallback: start 30 min før deadline hvis ingen solsurplus-vindue fundet
  - FlexPlanner styrer IKKE enheder — den beregner kun tidspunkter
  - Events fyres af coordinator, ikke af planner
  - Scope er udelukkende solsurplus — ikke priser
  - Loads sekvenseres grådigt i deadline-rækkefølge
  - Erstatter v1's FlexLoadReservationManager fuldstændigt

Surplus-beregning pr. slot:
  surplus_w = forecast_kwh / slot_h * 1000 - consumption_w
  Et vindue kræver surplus_w >= needed_w i mindst duration_minutes.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from .base import FlexLoad, FlexLoadDecision, FlexPlan, Planner
from .world_snapshot import WorldSnapshot

_LOGGER = logging.getLogger(__name__)

_DEADLINE_FALLBACK_MINUTES = 30     # start this many minutes before deadline
_MIN_SLOT_MINUTES = 30              # smallest surplus slot we consider


class FlexPlanner(Planner):
    """Plans flex load reservations around solar surplus windows."""

    def plan(self, snapshot: WorldSnapshot) -> FlexPlan:
        flex_loads: list[FlexLoad] = list(snapshot.flex_loads)
        if not flex_loads:
            return FlexPlan(decisions=[], reserved_solar_today_kwh=0.0, reserved_solar_tomorrow_kwh=0.0)

        now = snapshot.now
        is_weekend = now.weekday() >= 5
        cons = snapshot.consumption
        hourly_w = cons.hourly_weekend_w if is_weekend else cons.hourly_weekday_w

        # Build surplus map: datetime (slot_start) → surplus_w
        # Use forecast slots (typically 30-min resolution)
        surplus_map = _build_surplus_map(snapshot.forecast, hourly_w, now)

        # Sort loads by deadline — earliest deadline first (greedy)
        loads_sorted = sorted(flex_loads, key=lambda fl: fl.deadline)

        decisions: list[FlexLoadDecision] = []
        reserved_today_kwh = 0.0
        reserved_tomorrow_kwh = 0.0
        midnight_today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        midnight_tomorrow = midnight_today + timedelta(days=1)

        for load in loads_sorted:
            decision, reserved_kwh, reserved_dt = _plan_single_load(
                load=load,
                surplus_map=surplus_map,
                now=now,
            )
            decisions.append(decision)

            # Reduce future surplus by what this load claims
            if decision.window_start is not None:
                _subtract_reserved(
                    surplus_map=surplus_map,
                    window_start=decision.window_start,
                    duration_minutes=load.duration_minutes,
                    needed_w=load.needed_w,
                )

            # Accumulate reserved solar
            if reserved_dt is not None:
                if reserved_dt >= midnight_tomorrow:
                    reserved_tomorrow_kwh += reserved_kwh
                elif reserved_dt >= midnight_today:
                    reserved_today_kwh += reserved_kwh

        return FlexPlan(
            decisions=decisions,
            reserved_solar_today_kwh=round(reserved_today_kwh, 3),
            reserved_solar_tomorrow_kwh=round(reserved_tomorrow_kwh, 3),
        )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _build_surplus_map(
    forecast_slots: list,
    hourly_w: list[float],
    now: datetime,
) -> dict[datetime, float]:
    """Build {slot_start → surplus_w} from forecast slots from now onward."""
    surplus: dict[datetime, float] = {}
    for slot in forecast_slots:
        if slot.end <= now:
            continue
        slot_h = (slot.end - slot.start).total_seconds() / 3600.0
        if slot_h <= 0:
            continue
        solar_w = slot.kwh / slot_h * 1000.0
        h = slot.start.hour
        consumption_w = hourly_w[h] if 0 <= h < 24 else 500.0
        surplus[slot.start] = solar_w - consumption_w
    return surplus


def _plan_single_load(
    load: FlexLoad,
    surplus_map: dict[datetime, float],
    now: datetime,
) -> tuple[FlexLoadDecision, float, datetime | None]:
    """Return (decision, reserved_kwh, window_start_dt) for one load."""
    needed_w = load.needed_w
    duration_min = load.duration_minutes
    deadline = load.deadline

    # Find first window where we have enough consecutive surplus
    window_start, window_end = _find_surplus_window(
        surplus_map=surplus_map,
        needed_w=needed_w,
        duration_minutes=duration_min,
        now=now,
        deadline=deadline,
    )

    if window_start is not None:
        # Is this window NOW?
        slot_duration = timedelta(minutes=_MIN_SLOT_MINUTES)
        is_now = window_start <= now < window_start + slot_duration

        reserved_kwh = needed_w / 1000.0 * (duration_min / 60.0)
        status = "GO_NOW" if is_now else "SCHEDULED"
        reason = (
            f"Solsurplus {needed_w:.0f}W tilgængeligt"
            if is_now
            else f"Solsurplus-vindue fundet kl. {window_start.strftime('%H:%M')}"
        )
        return (
            FlexLoadDecision(
                entity_id=load.entity_id,
                status=status,
                window_start=window_start,
                window_end=window_end,
                reason=reason,
            ),
            reserved_kwh,
            window_start,
        )

    # No good window — deadline fallback
    fallback_start = deadline - timedelta(minutes=_DEADLINE_FALLBACK_MINUTES)
    if fallback_start < now:
        fallback_start = now

    reserved_kwh = needed_w / 1000.0 * (duration_min / 60.0)
    return (
        FlexLoadDecision(
            entity_id=load.entity_id,
            status="DEADLINE_FORCED",
            window_start=fallback_start,
            window_end=fallback_start + timedelta(minutes=duration_min),
            reason=f"Intet solsurplus-vindue fundet — starter 30 min før deadline",
        ),
        reserved_kwh,
        fallback_start,
    )


def _find_surplus_window(
    surplus_map: dict[datetime, float],
    needed_w: float,
    duration_minutes: int,
    now: datetime,
    deadline: datetime,
) -> tuple[datetime | None, datetime | None]:
    """Find earliest consecutive surplus window that satisfies needed_w for duration_minutes.

    Returns (window_start, window_end) or (None, None) if not found.
    Slots are treated as _MIN_SLOT_MINUTES intervals.
    """
    if not surplus_map:
        return None, None

    slot_min = _MIN_SLOT_MINUTES
    slots_needed = max(1, -(-duration_minutes // slot_min))  # ceiling division
    sorted_starts = sorted(s for s in surplus_map if s >= now and s < deadline)

    run_start: datetime | None = None
    run_count = 0

    for start in sorted_starts:
        if surplus_map[start] >= needed_w:
            if run_start is None:
                run_start = start
                run_count = 1
            else:
                # Check consecutive (no gap)
                expected = run_start + timedelta(minutes=slot_min * run_count)
                if abs((start - expected).total_seconds()) < 60:
                    run_count += 1
                else:
                    # Reset run
                    run_start = start
                    run_count = 1

            if run_count >= slots_needed:
                window_end = run_start + timedelta(minutes=slot_min * slots_needed)
                return run_start, window_end
        else:
            run_start = None
            run_count = 0

    return None, None


def _subtract_reserved(
    surplus_map: dict[datetime, float],
    window_start: datetime,
    duration_minutes: int,
    needed_w: float,
) -> None:
    """Reduce surplus in claimed slots so subsequent loads see reduced availability."""
    slot_min = _MIN_SLOT_MINUTES
    n = max(1, -(-duration_minutes // slot_min))
    for i in range(n):
        slot = window_start + timedelta(minutes=slot_min * i)
        if slot in surplus_map:
            surplus_map[slot] = surplus_map[slot] - needed_w
