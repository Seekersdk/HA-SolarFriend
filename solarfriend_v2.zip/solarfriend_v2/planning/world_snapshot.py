"""WorldSnapshot — det samlede, normaliserede verdensbillede pr. coordinator-tick.

Lag: planning
Afhænger af: core/types.py
Må IKKE importere: homeassistant, control/, runtime/

Centrale klasser:
  WorldSnapshot:              komplet input til alle planners — bygges af ingest-laget
  BatterySnapshot:            batteriets aktuelle tilstand og økonomi
  ConsumptionProfileSnapshot: immutable view af læringsmodellen til planlægning

Vigtige invarianter:
  - WorldSnapshot er immutable (frozen=True) — planners må aldrig mutere den
  - Alle datetimes er aware local tid — normaliseret af ingest/ inden de når hertil
  - Planners modtager KUN WorldSnapshot — ingen direkte HA-kald
  - Tilføj nye input-felter her og populer dem i ingest/ — ikke andre steder
  - min_charge_saving_dkk og battery_cost_per_kwh kommer fra HA number-entiteter
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from ..core.types import ChargerState, EVState, ForecastSlot, PowerReading, PriceSlot


@dataclass(frozen=True)
class ConsumptionProfileSnapshot:
    """Immutable view of the learned consumption profile for planning use."""
    hourly_weekday_w: list[float] = field(default_factory=lambda: [500.0] * 24)
    hourly_weekend_w: list[float] = field(default_factory=lambda: [500.0] * 24)
    confidence: str = "LEARNING"        # LEARNING | MATURE
    days_collected: int = 0


@dataclass(frozen=True)
class BatterySnapshot:
    soc_pct: float
    solar_kwh: float                    # solar energy currently in battery
    grid_kwh: float                     # grid energy currently in battery
    weighted_cost_dkk: float
    capacity_kwh: float
    min_soc_pct: float
    max_soc_pct: float
    charge_rate_kw: float = 6.0         # max charge/discharge rate


@dataclass(frozen=True)
class WorldSnapshot:
    """Complete, normalized view of the world at one point in time.

    Built by ingest layer. Passed to all planners unchanged.
    """
    now: datetime                       # aware local
    power: PowerReading
    battery: BatterySnapshot
    prices: list[PriceSlot]            # today + tomorrow, sorted by start
    sell_prices: list[PriceSlot]
    forecast: list[ForecastSlot]       # solar forecast, sorted by start
    consumption: ConsumptionProfileSnapshot
    ev: Optional[EVState] = None
    charger: Optional[ChargerState] = None

    # Flex loads — keyed by entity_id (upsert semantics, managed by coordinator)
    flex_loads: list = field(default_factory=list)  # list[FlexLoad] — avoid circular import

    # EV planning config
    ev_departure: Optional[datetime] = None
    sunset_datetime: Optional[datetime] = None
    ev_mode: str = "solar_only"         # solar_only | hybrid
    ev_max_charge_kw: float = 11.0
    ev_min_range_km: float = 0.0
    cloud_coverage_pct: float | None = None
    solar_elevation_deg: float | None = None
    solar_azimuth_deg: float | None = None

    # Runtime config — thresholds passed in from HA number entities
    min_charge_saving_dkk: float = 0.20
    battery_cost_per_kwh_dkk: float = 0.30
    cheap_grid_threshold_dkk: float = 0.10
    battery_sell_enabled: bool = True
    ev_charging_enabled: bool = False
