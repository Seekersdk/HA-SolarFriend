"""Diagnostics support for SolarFriend V2."""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .config import merged_entry_config
from .const import DOMAIN


def _to_jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return _to_jsonable(asdict(value))
    if isinstance(value, dict):
        return {str(key): _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_to_jsonable(item) for item in value]
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except TypeError:
            return str(value)
    return value


async def async_get_config_entry_diagnostics(
    hass: HomeAssistant,
    entry: ConfigEntry,
) -> dict[str, Any]:
    coordinator = hass.data.get(DOMAIN, {}).get(entry.entry_id)
    presentation_state = getattr(coordinator, "presentation_state", None)

    diagnostics: dict[str, Any] = {
        "entry": {
            "entry_id": entry.entry_id,
            "title": entry.title,
            "data": _to_jsonable(dict(entry.data)),
            "options": _to_jsonable(dict(entry.options)),
            "merged_config": _to_jsonable(merged_entry_config(entry)),
        },
        "coordinator_loaded": coordinator is not None,
    }

    if presentation_state is None:
        diagnostics["presentation_state"] = None
        return diagnostics

    diagnostics["presentation_state"] = {
        "runtime_health": presentation_state.runtime_health,
        "last_successful_update": _to_jsonable(presentation_state.last_successful_update),
        "realized_savings_today": presentation_state.realized_savings_today,
        "realized_savings_total": presentation_state.realized_savings_total,
        "battery_runtime_result": _to_jsonable(presentation_state.battery_runtime_result),
        "ev_runtime_result": _to_jsonable(presentation_state.ev_runtime_result),
        "decision": {
            "reason": presentation_state.decision.reason,
            "battery_strategy": presentation_state.decision.battery_plan.strategy,
            "battery_reason": presentation_state.decision.battery_plan.reason,
            "ev_mode": presentation_state.decision.ev_plan.mode,
            "ev_should_charge": presentation_state.decision.ev_plan.should_charge,
            "ev_reason": presentation_state.decision.ev_plan.reason,
            "flex_statuses": [
                decision.status for decision in presentation_state.decision.flex_plan.decisions
            ],
        },
        "solar_profile_snapshot": _to_jsonable(presentation_state.solar_profile_snapshot),
        "battery_tracker_state": _to_jsonable(presentation_state.battery_tracker_state),
        "model_evaluation_summary": _to_jsonable(presentation_state.model_evaluation_summary),
    }
    return diagnostics
