# Sensor Review

This file captures the agreed V2 sensor scope before the presentation layer is
built. The goal is to keep V2 small and useful:

- sensors are for reading state
- attributes are for explaining state
- logs are for diagnostics and model analysis
- controls belong in `select`, `number`, `switch`, or `button`, not sensors

## Approved Top-Level Sensors

These are the sensors V2 should expose as first-class entities.

| Entity | Purpose | Notes |
|--------|---------|-------|
| `battery_strategy` | Active battery decision | Main state sensor for battery behavior |
| `decision_summary` | Human-readable current system decision | Cross-domain summary for dashboards |
| `pv_power` | Live PV power | Pass-through reading |
| `grid_power` | Live grid import/export | Pass-through reading |
| `load_power` | Live house load | Pass-through reading |
| `battery_soc` | Live battery state of charge | Pass-through reading |
| `battery_power` | Live battery power | Pass-through reading |
| `current_price` | Current import price | Pass-through reading |
| `forecast_today` | Forecast production today | Keep one top-level forecast number |
| `flex_active_count` | Number of active/pending flex loads | Main flex overview |
| `ev_status` | EV/charger live state | Only when EV is enabled |
| `ev_charge_mode` | Active EV mode as read-only state | The user-facing control remains a `select` |
| `ev_charging_power` | Current EV charging power | Only when EV is enabled |
| `ev_vehicle_soc` | Current EV SOC | Only when EV is enabled |
| `runtime_health` | Runtime status / stale-data indicator | Diagnostic but user-relevant |
| `realized_savings_today` | Realized savings today | Keep only if definition is conservative and stable |
| `realized_savings_total` | Realized savings total | Keep only if definition is conservative and stable |

## Keep As Attributes

These values are useful, but should not become separate entities.

- `battery_reason`
- `battery_target_soc`
- `battery_next_cheap_window`
- `battery_energy_kwh`
- `battery_usable_kwh`
- `battery_weighted_cost`
- `battery_solar_fraction`
- `flex_next_name`
- `flex_next_start`
- `flex_next_power`
- `flex_reserved_solar_today`
- `flex_reserved_solar_tomorrow`
- `ev_reason`
- `ev_target_power`
- `ev_phases`
- `ev_hours_to_departure`
- `ev_needed_kwh`
- `ev_target_soc`
- `forecast_remaining_today`
- `forecast_peak_today`
- `solar_next_2h`
- `solar_until_sunset`
- `consumption_profile_confidence`
- `last_successful_update`
- `decision_changed_at`

## Do Not Recreate As Normal Sensors

These existed in V1 but should stay out of the normal V2 sensor surface.

- `battery_plan`
- `forecast_soc_chart`
- `ev_plan`
- `forecast_actual_today_so_far`
- `forecast_predicted_today_so_far`
- `forecast_error_today_so_far`
- `forecast_accuracy_today_so_far`
- `forecast_actual_yesterday`
- `forecast_predicted_yesterday`
- `forecast_error_yesterday`
- `forecast_accuracy_yesterday`
- `forecast_bias_factor_14d`
- `forecast_mae_14d`
- `forecast_mape_14d`
- `forecast_accuracy_14d`
- `solar_installation_profile*`
- `solar_profile_comparison*`
- `solar_profile_hours_to_ready*`
- `solar_profile_missing_annual_paths*`
- `forecast_correction_*`
- `advanced_consumption_model_*`
- `model_evaluation_summary`
- `consumption_profile_chart`

## Savings Rule

V2 should only expose savings as top-level sensors when the value is realized
and explainable in one sentence. Forecast-style or "expected" savings should be
kept as attributes or logs, not primary sensors.

## Related Review Files

- `presentation/BINARY_SENSOR_REVIEW.md`
- `presentation/CONTROL_ENTITY_REVIEW.md`
