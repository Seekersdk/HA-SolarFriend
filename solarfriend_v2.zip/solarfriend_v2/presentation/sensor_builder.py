"""Sensor builder - maps Decision + WorldSnapshot to HA-facing attributes.

No business logic here. Pure data mapping from domain objects to HA-facing dicts.
Before adding a new sensor, review presentation/SENSOR_REVIEW.md.
"""
from __future__ import annotations

from datetime import timedelta
from typing import Any

from ..decision.engine import Decision
from ..learning.consumption_model import ConsumptionPredictionSnapshot
from ..learning.solar_profile import SolarProfileSnapshot
from ..planning.world_snapshot import WorldSnapshot
from ..runtime.battery_tracker import BatteryTrackerState


def _compact_track2_rows(rows: list[dict[str, Any]], *, limit: int = 8) -> list[dict[str, Any]]:
    compacted: list[dict[str, Any]] = []
    for row in rows[:limit]:
        compacted.append(
            {
                "period_start": row.get("period_start"),
                "solcast_kwh": row.get("solcast_kwh"),
                "faktisk_kwh": row.get("faktisk_kwh"),
                "beregnet_kwh": row.get("beregnet_kwh"),
                "beregnet_confidence": row.get("beregnet_confidence"),
            }
        )
    return compacted


def _track2_surface_preview(
    response_surface: dict[str, float],
    uncertainty_surface: dict[str, float],
    *,
    limit: int = 8,
) -> list[dict[str, Any]]:
    preview: list[dict[str, Any]] = []
    for cell_key in sorted(response_surface)[:limit]:
        preview.append(
            {
                "cell": cell_key,
                "factor": round(float(response_surface.get(cell_key, 1.0)), 4),
                "uncertainty": round(float(uncertainty_surface.get(cell_key, 0.0)), 4),
            }
        )
    return preview


def _parse_track2_cell_key(cell_key: str) -> tuple[float, float] | None:
    try:
        elevation_part, azimuth_part = cell_key.split("|", 1)
        return float(elevation_part.removeprefix("e")), float(azimuth_part.removeprefix("a"))
    except (ValueError, AttributeError):
        return None


def _azimuth_distance_deg(left: float, right: float) -> float:
    delta = abs(left - right) % 360.0
    return min(delta, 360.0 - delta)


def _track2_current_cell_estimate(
    response_surface: dict[str, float],
    uncertainty_surface: dict[str, float],
    *,
    elevation_deg: float | None,
    azimuth_deg: float | None,
) -> dict[str, Any] | None:
    if elevation_deg is None or azimuth_deg is None or not response_surface:
        return None

    best_match: tuple[str, float, float] | None = None
    for cell_key in response_surface:
        parsed = _parse_track2_cell_key(cell_key)
        if parsed is None:
            continue
        cell_elevation, cell_azimuth = parsed
        distance = abs(cell_elevation - elevation_deg) + (_azimuth_distance_deg(cell_azimuth, azimuth_deg) * 0.4)
        if best_match is None or distance < best_match[1]:
            best_match = (cell_key, distance, cell_azimuth)

    if best_match is None:
        return None

    matched = _parse_track2_cell_key(best_match[0])
    if matched is None:
        return None
    matched_elevation, matched_azimuth = matched
    return {
        "cell": best_match[0],
        "factor": round(float(response_surface.get(best_match[0], 1.0)), 4),
        "uncertainty": round(float(uncertainty_surface.get(best_match[0], 0.0)), 4),
        "requested_elevation_deg": round(float(elevation_deg), 2),
        "requested_azimuth_deg": round(float(azimuth_deg), 2),
        "matched_elevation_deg": round(matched_elevation, 2),
        "matched_azimuth_deg": round(matched_azimuth, 2),
        "distance_score": round(best_match[1], 3),
    }


def build_battery_attributes(decision: Decision, snapshot: WorldSnapshot) -> dict[str, Any]:
    battery = snapshot.battery
    plan = decision.battery_plan
    total_kwh = battery.solar_kwh + battery.grid_kwh
    solar_fraction = (battery.solar_kwh / total_kwh) if total_kwh > 0 else None
    energy_kwh = battery.capacity_kwh * battery.soc_pct / 100.0
    usable_kwh = battery.capacity_kwh * max(0.0, battery.soc_pct - battery.min_soc_pct) / 100.0
    return {
        "battery_reason": plan.reason,
        "battery_target_soc": plan.target_soc_pct,
        "battery_next_cheap_window": (
            plan.next_cheap_window.isoformat() if plan.next_cheap_window is not None else None
        ),
        "battery_energy_kwh": round(energy_kwh, 2),
        "battery_usable_kwh": round(usable_kwh, 2),
        "battery_weighted_cost": round(battery.weighted_cost_dkk, 3),
        "battery_solar_fraction": round(solar_fraction, 3) if solar_fraction is not None else None,
    }


def build_horizon_plan_attributes(decision: Decision, snapshot: WorldSnapshot) -> dict[str, Any]:
    effective_plan = _build_effective_horizon_plan(decision, snapshot)
    return {
        "hourly_plan": effective_plan,
        "hourly_plan_points": len(effective_plan),
    }


def _build_effective_horizon_plan(decision: Decision, snapshot: WorldSnapshot) -> list[dict[str, Any]]:
    ev_planned_kwh_by_hour: dict[str, float] = {}
    for slot in decision.ev_plan.planned_slots:
        if slot.solar_charge_w <= 0.0 and slot.strategy != "CHARGE_SOLAR":
            continue
        if slot.planned_energy_kwh <= 0.0:
            continue
        total_charge_w = slot.solar_charge_w + slot.grid_charge_w
        if total_charge_w > 0.0:
            solar_fraction = slot.solar_charge_w / total_charge_w
        else:
            solar_fraction = 1.0
        if solar_fraction > 0.0:
            ev_planned_kwh_by_hour[slot.start.isoformat()] = ev_planned_kwh_by_hour.get(
                slot.start.isoformat(),
                0.0,
            ) + (slot.planned_energy_kwh * solar_fraction)

    effective_plan: list[dict[str, Any]] = []
    shifted_battery_kwh = 0.0
    capacity_kwh = max(snapshot.battery.capacity_kwh, 0.1)
    for slot in decision.battery_plan.hourly_plan:
        data = _serialize_hourly_slot(slot, include_reason=False)
        ev_slot_kwh = ev_planned_kwh_by_hour.get(slot.start.isoformat(), 0.0)
        raw_battery_kwh = max(0.0, slot.solar_charge_w / 1000.0)
        solar_surplus_kwh = max(0.0, (slot.forecast_solar_w - slot.forecast_load_w) / 1000.0)

        preempted_kwh = 0.0
        if ev_slot_kwh > 0.0 and raw_battery_kwh > 0.0:
            preempted_kwh = min(raw_battery_kwh, ev_slot_kwh)
            raw_battery_kwh -= preempted_kwh
            shifted_battery_kwh += preempted_kwh
            if raw_battery_kwh <= 0.0:
                data["strategy"] = "IDLE"
                data["reason"] = "EV solar-only bruger lokalt soloverskud i dette slot"
            else:
                data["reason"] = f"{slot.reason}; EV bruger en del af soloverskuddet"

        available_for_recovery_kwh = max(0.0, solar_surplus_kwh - raw_battery_kwh - ev_slot_kwh)
        recovered_kwh = 0.0
        if shifted_battery_kwh > 1e-6 and available_for_recovery_kwh > 0.0:
            recovered_kwh = min(shifted_battery_kwh, available_for_recovery_kwh)
            raw_battery_kwh += recovered_kwh
            shifted_battery_kwh -= recovered_kwh
            data["strategy"] = "SAVE_SOLAR"
            data["reason"] = "Udskudt husbatteriopladning efter EV solar-only"

        data["solar_charge_w"] = round(raw_battery_kwh * 1000.0, 1)
        data["ev_solar_preemption_w"] = round(preempted_kwh * 1000.0, 1)
        data["shifted_battery_recovery_w"] = round(recovered_kwh * 1000.0, 1)
        if shifted_battery_kwh > 1e-6:
            data["planned_soc_pct"] = round(
                max(0.0, data["planned_soc_pct"] - shifted_battery_kwh / capacity_kwh * 100.0),
                1,
            )
        effective_plan.append(data)
    return effective_plan


def _serialize_hourly_slot(slot, *, include_reason: bool = True) -> dict[str, Any]:
    data = {
        "hour": slot.start.isoformat(),
        "strategy": slot.strategy,
        "forecast_load_w": round(slot.forecast_load_w, 1),
        "forecast_solar_w": round(slot.forecast_solar_w, 1),
        "price_dkk": round(slot.price_dkk, 4),
        "planned_soc_pct": round(slot.planned_soc_pct, 1),
        "grid_charge_w": round(slot.grid_charge_w, 1),
        "solar_charge_w": round(slot.solar_charge_w, 1),
        "discharge_w": round(slot.discharge_w, 1),
        "discharge_to_load_w": round(slot.discharge_to_load_w, 1),
        "battery_export_w": round(slot.battery_export_w, 1),
        "grid_import_w": round(slot.grid_import_w, 1),
    }
    if include_reason:
        data["reason"] = slot.reason
        data["sell_price_dkk"] = round(slot.sell_price_dkk, 4) if slot.sell_price_dkk is not None else None
        data["discharge_value_dkk"] = (
            round(slot.discharge_value_dkk, 4) if slot.discharge_value_dkk is not None else None
        )
        data["allowed_discharge_w"] = round(slot.allowed_discharge_w, 1)
    return data


def build_decision_attributes(decision: Decision, snapshot: WorldSnapshot) -> dict[str, Any]:
    flex_go_now = [
        item.entity_id
        for item in decision.flex_plan.decisions
        if item.status == "GO_NOW"
    ]
    return {
        "decision_summary": decision.reason,
        "decision_changed_at": snapshot.now.isoformat(),
        "flex_go_now_entities": flex_go_now,
    }


def build_runtime_attributes(state) -> dict[str, Any]:
    battery = state.battery_runtime_result
    ev = state.ev_runtime_result
    return {
        "battery_runtime_applied": battery.applied if battery is not None else None,
        "battery_runtime_changed": battery.changed if battery is not None else None,
        "battery_runtime_reason": battery.reason if battery is not None else None,
        "ev_runtime_applied": ev.applied if ev is not None else None,
        "ev_runtime_changed": ev.changed if ev is not None else None,
        "ev_runtime_reason": ev.reason if ev is not None else None,
    }


def build_ev_attributes(decision: Decision, snapshot: WorldSnapshot) -> dict[str, Any]:
    ev = snapshot.ev
    plan = decision.ev_plan
    planned_solar_slots = [
        slot for slot in plan.planned_slots if slot.solar_charge_w > 0.0 or slot.strategy == "CHARGE_SOLAR"
    ]
    expected_solar_kwh = 0.0
    for slot in planned_solar_slots:
        total_charge_w = slot.solar_charge_w + slot.grid_charge_w
        if slot.planned_energy_kwh <= 0.0:
            continue
        if total_charge_w <= 0.0:
            expected_solar_kwh += slot.planned_energy_kwh
        else:
            expected_solar_kwh += slot.planned_energy_kwh * (slot.solar_charge_w / total_charge_w)
    serialized_slots = _serialize_ev_slots(plan.planned_slots)
    slot_preview = serialized_slots[:6]
    if ev is None:
        return {
            "ev_reason": plan.reason,
            "ev_target_power": plan.target_power_w,
            "ev_phases": plan.phases,
            "ev_hours_to_departure": None,
            "ev_needed_kwh": None,
            "ev_target_soc": None,
            "ev_range_km": None,
            "ev_min_range_km": round(snapshot.ev_min_range_km, 1) if snapshot.ev_min_range_km else 0.0,
            "ev_expected_solar_kwh": round(expected_solar_kwh, 2),
            "ev_remaining_kwh_after_planned_solar": None,
            "ev_planned_solar_slots_count": len(planned_solar_slots),
            "ev_planned_slots": serialized_slots,
            "ev_planned_slots_preview": slot_preview,
        }

    needed_kwh = max(0.0, (ev.target_soc_pct - ev.soc_pct) / 100.0 * ev.battery_kwh)
    hours_to_departure = None
    if snapshot.ev_departure is not None:
        hours_to_departure = max(
            0.0,
            (snapshot.ev_departure - snapshot.now).total_seconds() / 3600.0,
        )
    remaining_after_plan = max(0.0, needed_kwh - expected_solar_kwh)
    solar_only_plan_summary = None
    if plan.mode == "solar_only":
        solar_only_plan_summary = (
            f"Behov {needed_kwh:.1f} kWh, planlagt sol {expected_solar_kwh:.1f} kWh "
            f"i {len(planned_solar_slots)} slots, rest {remaining_after_plan:.1f} kWh"
        )
    return {
        "ev_reason": plan.reason,
        "ev_target_power": round(plan.target_power_w, 1),
        "ev_phases": plan.phases,
        "ev_hours_to_departure": round(hours_to_departure, 1) if hours_to_departure is not None else None,
        "ev_needed_kwh": round(needed_kwh, 2),
        "ev_target_soc": ev.target_soc_pct,
        "ev_range_km": round(ev.range_km, 1),
        "ev_min_range_km": round(snapshot.ev_min_range_km, 1) if snapshot.ev_min_range_km else 0.0,
        "ev_expected_solar_kwh": round(expected_solar_kwh, 2),
        "ev_remaining_kwh_after_planned_solar": round(remaining_after_plan, 2),
        "ev_planned_solar_slots_count": len(planned_solar_slots),
        "ev_planned_slots": serialized_slots,
        "ev_planned_slots_preview": slot_preview,
        "ev_solar_only_plan_summary": solar_only_plan_summary,
    }


def _serialize_ev_slots(slots: list[Any]) -> list[dict[str, Any]]:
    serialized: list[dict[str, Any]] = []
    for index, slot in enumerate(slots):
        next_start = slots[index + 1].start if index + 1 < len(slots) else None
        total_charge_w = slot.solar_charge_w + slot.grid_charge_w
        duration_hours = 1.0
        if slot.planned_energy_kwh > 0.0 and total_charge_w > 0.0:
            duration_hours = slot.planned_energy_kwh / (total_charge_w / 1000.0)
        elif next_start is not None:
            duration_hours = max(0.0, (next_start - slot.start).total_seconds() / 3600.0)
        end = slot.start + timedelta(hours=duration_hours or 1.0)
        serialized.append(
            {
                "start": slot.start.isoformat(),
                "end": end.isoformat(),
                "strategy": slot.strategy,
                "forecast_solar_w": round(slot.forecast_solar_w, 1),
                "forecast_load_w": round(slot.forecast_load_w, 1),
                "solar_charge_w": round(slot.solar_charge_w, 1),
                "grid_charge_w": round(slot.grid_charge_w, 1),
                "planned_energy_kwh": round(slot.planned_energy_kwh, 2),
                "reason": slot.reason,
            }
        )
    return serialized


def build_flex_attributes(decision: Decision) -> dict[str, Any]:
    decisions = decision.flex_plan.decisions
    next_item = next(
        (item for item in decisions if item.window_start is not None),
        None,
    )
    return {
        "flex_active_count": len(decisions),
        "flex_next_name": next_item.entity_id if next_item is not None else None,
        "flex_next_start": (
            next_item.window_start.isoformat()
            if next_item is not None and next_item.window_start is not None
            else None
        ),
        "flex_next_power": None,
        "flex_reserved_solar_today": round(decision.flex_plan.reserved_solar_today_kwh, 3),
        "flex_reserved_solar_tomorrow": round(decision.flex_plan.reserved_solar_tomorrow_kwh, 3),
        "flex_statuses": [item.status for item in decisions],
    }


def build_forecast_attributes(
    snapshot: WorldSnapshot,
    solar_profile_snapshot: SolarProfileSnapshot | None = None,
    *,
    track2_current_factor: float | None = None,
    track2_current_confidence: float | None = None,
) -> dict[str, Any]:
    now = snapshot.now
    today_end = now.replace(hour=23, minute=59, second=59, microsecond=999999)
    remaining_today = sum(slot.kwh for slot in snapshot.forecast if slot.end > now and slot.start <= today_end)
    next_2h_end = now + timedelta(hours=2)
    solar_next_2h = sum(slot.kwh for slot in snapshot.forecast if slot.start >= now and slot.start < next_2h_end)
    peak_today_w = 0.0
    for slot in snapshot.forecast:
        if slot.start.date() != now.date():
            continue
        hours = (slot.end - slot.start).total_seconds() / 3600.0
        if hours > 0:
            peak_today_w = max(peak_today_w, slot.kwh / hours * 1000.0)
    attrs = {
        "forecast_remaining_today": round(remaining_today, 3),
        "forecast_peak_today": round(peak_today_w, 1),
        "solar_next_2h": round(solar_next_2h, 3),
        "solar_until_sunset": round(remaining_today, 3),
        "track2_current_solar_elevation_deg": (
            round(snapshot.solar_elevation_deg, 2) if snapshot.solar_elevation_deg is not None else None
        ),
        "track2_current_solar_azimuth_deg": (
            round(snapshot.solar_azimuth_deg, 2) if snapshot.solar_azimuth_deg is not None else None
        ),
        "track2_current_cloud_coverage_pct": (
            round(snapshot.cloud_coverage_pct, 1) if snapshot.cloud_coverage_pct is not None else None
        ),
    }
    if solar_profile_snapshot is None:
        return attrs
    attrs.update(
        {
            "track2_active_resolution": solar_profile_snapshot.active_resolution_key,
            "track2_active_state": solar_profile_snapshot.active_state,
            "track2_hours_to_ready": round(solar_profile_snapshot.hours_to_ready, 1),
            "track2_today_points": len(solar_profile_snapshot.comparison_today),
            "track2_tomorrow_points": len(solar_profile_snapshot.comparison_tomorrow),
            "track2_today_preview": _compact_track2_rows(solar_profile_snapshot.comparison_today),
            "track2_tomorrow_preview": _compact_track2_rows(solar_profile_snapshot.comparison_tomorrow),
            "track2_current_factor": (
                round(track2_current_factor, 4) if track2_current_factor is not None else None
            ),
            "track2_current_confidence": (
                round(track2_current_confidence, 4) if track2_current_confidence is not None else None
            ),
            "track2_variant_states": {
                key: {
                    "state": variant.state,
                    "populated_cells": variant.populated_cells,
                    "confident_cells": variant.confident_cells,
                    "clear_sky_observations": variant.clear_sky_observations,
                    "estimated_hours_to_ready": variant.estimated_hours_to_ready,
                }
                for key, variant in solar_profile_snapshot.variants.items()
            },
        }
    )
    active_variant = solar_profile_snapshot.variants.get(solar_profile_snapshot.active_resolution_key)
    if active_variant is not None:
        attrs["track2_active_surface_preview"] = _track2_surface_preview(
            active_variant.response_surface,
            active_variant.uncertainty_surface,
        )
        attrs["track2_current_cell_estimate"] = _track2_current_cell_estimate(
            active_variant.response_surface,
            active_variant.uncertainty_surface,
            elevation_deg=snapshot.solar_elevation_deg,
            azimuth_deg=snapshot.solar_azimuth_deg,
        )
    return attrs


def build_consumption_attributes(
    snapshot: WorldSnapshot,
    prediction: ConsumptionPredictionSnapshot | None = None,
) -> dict[str, Any]:
    consumption = snapshot.consumption
    attrs = {
        "consumption_profile_confidence": consumption.confidence,
        "consumption_profile_days_collected": consumption.days_collected,
    }
    if prediction is None:
        return attrs
    attrs.update(
        {
            "forecast_load_w": round(prediction.predicted_w, 1),
            "active_consumption_model": prediction.active_model,
            "advanced_model_ready": prediction.advanced_is_mature,
            "load_baseload_w": round(prediction.baseload_w, 1),
            "load_thermal_w": round(prediction.thermal_w, 1),
            "load_behavioral_w": round(prediction.behavioral_w, 1),
            "load_fourier_w": round(prediction.fourier_w, 1),
            "load_ar_w": round(prediction.ar_w, 1),
            "simple_predicted_w": round(prediction.simple_predicted_w, 1),
            "advanced_predicted_w": round(prediction.advanced_predicted_w, 1),
        }
    )
    return attrs


def build_savings_attributes(
    snapshot: WorldSnapshot,
    tracker_state: BatteryTrackerState | None = None,
) -> dict[str, Any]:
    attrs = {
        "battery_weighted_cost": round(snapshot.battery.weighted_cost_dkk, 3),
        "battery_solar_kwh": round(snapshot.battery.solar_kwh, 3),
        "battery_grid_kwh": round(snapshot.battery.grid_kwh, 3),
    }
    if tracker_state is None:
        return attrs
    attrs.update(
        {
            "today_solar_direct_saved_dkk": round(tracker_state.today_solar_direct_saved_dkk, 4),
            "today_optimizer_saved_dkk": round(tracker_state.today_optimizer_saved_dkk, 4),
            "today_battery_sell_saved_dkk": round(tracker_state.today_battery_sell_saved_dkk, 4),
            "total_solar_direct_saved_dkk": round(tracker_state.total_solar_direct_saved_dkk, 4),
            "total_optimizer_saved_dkk": round(tracker_state.total_optimizer_saved_dkk, 4),
            "total_battery_sell_saved_dkk": round(tracker_state.total_battery_sell_saved_dkk, 4),
        }
    )
    return attrs
