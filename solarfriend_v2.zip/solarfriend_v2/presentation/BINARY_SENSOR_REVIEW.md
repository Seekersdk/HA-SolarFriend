# Binary Sensor Review

V1 did not expose a dedicated `binary_sensor` platform. V2 can therefore add a
small binary sensor set based on actual automation value instead of legacy
surface area.

## Approved Binary Sensors

| Entity | Purpose | Why it should exist |
|--------|---------|---------------------|
| `cheap_now` | Current price is in a cheap window | Useful for automations and quick UI logic |
| `solar_surplus_now` | Local solar surplus is available right now | Useful for automations and flex/EV visibility |
| `battery_can_export_now` | Current battery strategy allows export | Better as a simple automation flag than parsing strategy strings |
| `ev_charging_active` | EV is currently charging | Good automation trigger and concise UI state |
| `flex_go_now_active` | At least one flex load should start now | Useful for automations and dashboard badges |
| `runtime_stale` | Coordinator/runtime data is stale | Good health signal |

## Keep As Attributes Or Derived State

- `battery_sell_enabled`: this is a `switch`, not a binary sensor
- `ev_charging_enabled`: this is a `switch`, not a binary sensor
- `advanced_consumption_model_enabled`: this is a `switch`, not a binary sensor

## Do Not Add

- Binary sensors for every planner or runtime intermediate
- Binary versions of values already represented well by `battery_strategy`
- Debug-only model quality flags that belong in observability
