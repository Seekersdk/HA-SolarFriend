"""Presentation-facing coordinator state."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ..decision.engine import Decision
from ..learning.consumption_model import ConsumptionPredictionSnapshot
from ..learning.solar_profile import SolarProfileSnapshot
from ..observability.model_evaluation import EvaluationSummary
from ..planning.world_snapshot import WorldSnapshot
from ..runtime.battery_tracker import BatteryTrackerState
from ..runtime.models import RuntimeApplyResult


@dataclass(frozen=True)
class PresentationState:
    decision: Decision
    snapshot: WorldSnapshot
    consumption_prediction: ConsumptionPredictionSnapshot | None = None
    solar_profile_snapshot: SolarProfileSnapshot | None = None
    track2_current_factor: float | None = None
    track2_current_confidence: float | None = None
    battery_tracker_state: BatteryTrackerState | None = None
    battery_runtime_result: RuntimeApplyResult | None = None
    ev_runtime_result: RuntimeApplyResult | None = None
    runtime_health: str = "ok"
    last_successful_update: datetime | None = None
    realized_savings_today: float | None = None
    realized_savings_total: float | None = None
    model_evaluation_summary: EvaluationSummary | None = None
