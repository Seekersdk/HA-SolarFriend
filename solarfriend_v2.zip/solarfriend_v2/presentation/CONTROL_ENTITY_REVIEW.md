# Control Entity Review

This file captures the user-facing control entities for V2. These are not
sensors. They represent configuration or user overrides.

## Select

| Entity | Keep | Notes |
|--------|------|-------|
| `ev_charge_mode` | Yes | User chooses `solar_only`, `hybrid`, or `grid_only` |
| `ev_departure_time` | Yes | Needed for deadline-based EV modes |

## Number

| Entity | Keep | Notes |
|--------|------|-------|
| `charge_rate_kw` | Yes | Core battery/inverter configuration |
| `battery_min_soc` | Yes | Core battery protection setting |
| `battery_max_soc` | Yes | Core battery target ceiling |
| `min_charge_saving` | Yes | Planner threshold input |
| `cheap_grid_threshold` | Yes | Planner threshold input |
| `deye_default_battery_discharge_current` | Yes, vendor-specific | Only when Deye is configured |
| `ev_target_soc` | Yes | User EV charging target |
| `ev_min_range_km` | Keep only if used in V2 planner/runtime | Otherwise drop |

## Switch

| Entity | Keep | Notes |
|--------|------|-------|
| `ev_charging_enabled` | Yes | Main EV enable/disable override |
| `battery_sell_enabled` | Yes | Runtime/business override; not a sensor |
| `ev_solar_only_grid_buffer_enabled` | Yes | Matches V1 behavior and V2 runtime |
| `advanced_consumption_model_enabled` | Keep only if advanced model remains user-toggleable | Otherwise move to config |
| `shadow_log_enabled` | No as normal product control | Keep as diagnostic/dev-only if still needed |

## Button

| Entity | Keep | Notes |
|--------|------|-------|
| `populate_load_model` | No as normal product control | Dev/maintenance only. Keep only if migration/support workflow still needs it |

## General Rules

- Controls should be few, stable, and understandable without reading logs.
- Vendor-specific controls belong behind vendor checks, not in the common UI.
- If a control is only for debugging or migration, do not expose it as a normal
  end-user entity.
