"""Constants for SolarFriend V2."""

DOMAIN = "solarfriend_v2"
