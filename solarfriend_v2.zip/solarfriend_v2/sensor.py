"""SolarFriend V2 sensor platform.

This layer only maps coordinator presentation state to HA entities.
No planning or decision logic belongs here.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_NAME, PERCENTAGE, UnitOfEnergy, UnitOfPower
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .config import entry_value
from .presentation.models import PresentationState
from .presentation.sensor_builder import (
    build_battery_attributes,
    build_consumption_attributes,
    build_decision_attributes,
    build_ev_attributes,
    build_flex_attributes,
    build_forecast_attributes,
    build_horizon_plan_attributes,
    build_runtime_attributes,
    build_savings_attributes,
)

UNIT_DKK_KWH = "DKK/kWh"
UNIT_KR = "kr"


@dataclass(frozen=True)
class SolarFriendV2SensorDescription(SensorEntityDescription):
    value_fn: Callable[[PresentationState], Any] = lambda state: None
    attrs_fn: Callable[[PresentationState], dict[str, Any] | None] = lambda state: None
    entity_registry_visible_default: bool = True


def _forecast_today_kwh(state: PresentationState) -> float:
    today = state.snapshot.now.date()
    return round(sum(slot.kwh for slot in state.snapshot.forecast if slot.start.date() == today), 3)


def _ev_status(state: PresentationState) -> str | None:
    charger = state.snapshot.charger
    if charger is None:
        return None
    if charger.charging:
        return "charging"
    if charger.connected:
        return "connected"
    return "disconnected"


SENSOR_DESCRIPTIONS: tuple[SolarFriendV2SensorDescription, ...] = (
    SolarFriendV2SensorDescription(
        key="battery_strategy",
        name="Battery Strategy",
        icon="mdi:battery-clock-outline",
        value_fn=lambda state: state.decision.battery_plan.strategy,
        attrs_fn=lambda state: build_battery_attributes(state.decision, state.snapshot),
    ),
    SolarFriendV2SensorDescription(
        key="decision_summary",
        name="Decision Summary",
        icon="mdi:brain",
        value_fn=lambda state: state.decision.reason,
        attrs_fn=lambda state: {
            **build_decision_attributes(state.decision, state.snapshot),
            **build_runtime_attributes(state),
        },
    ),
    SolarFriendV2SensorDescription(
        key="pv_power",
        name="PV Power",
        native_unit_of_measurement=UnitOfPower.WATT,
        device_class=SensorDeviceClass.POWER,
        state_class=SensorStateClass.MEASUREMENT,
        icon="mdi:solar-power",
        value_fn=lambda state: round(state.snapshot.power.pv_w, 1),
    ),
    SolarFriendV2SensorDescription(
        key="grid_power",
        name="Grid Power",
        native_unit_of_measurement=UnitOfPower.WATT,
        device_class=SensorDeviceClass.POWER,
        state_class=SensorStateClass.MEASUREMENT,
        icon="mdi:transmission-tower",
        value_fn=lambda state: round(state.snapshot.power.grid_w, 1),
    ),
    SolarFriendV2SensorDescription(
        key="load_power",
        name="Load Power",
        native_unit_of_measurement=UnitOfPower.WATT,
        device_class=SensorDeviceClass.POWER,
        state_class=SensorStateClass.MEASUREMENT,
        icon="mdi:home-lightning-bolt",
        value_fn=lambda state: round(state.snapshot.power.load_w, 1),
    ),
    SolarFriendV2SensorDescription(
        key="battery_soc",
        name="Battery SOC",
        native_unit_of_measurement=PERCENTAGE,
        device_class=SensorDeviceClass.BATTERY,
        state_class=SensorStateClass.MEASUREMENT,
        icon="mdi:battery",
        value_fn=lambda state: round(state.snapshot.battery.soc_pct, 1),
    ),
    SolarFriendV2SensorDescription(
        key="battery_power",
        name="Battery Power",
        native_unit_of_measurement=UnitOfPower.WATT,
        device_class=SensorDeviceClass.POWER,
        state_class=SensorStateClass.MEASUREMENT,
        icon="mdi:battery-arrow-up-down",
        value_fn=lambda state: round(state.snapshot.power.battery_w, 1),
    ),
    SolarFriendV2SensorDescription(
        key="current_price",
        name="Current Price",
        native_unit_of_measurement=UNIT_DKK_KWH,
        icon="mdi:currency-usd",
        value_fn=lambda state: round(state.snapshot.prices[0].price_dkk, 4) if state.snapshot.prices else None,
    ),
    SolarFriendV2SensorDescription(
        key="forecast_today",
        name="Forecast Today",
        native_unit_of_measurement=UnitOfEnergy.KILO_WATT_HOUR,
        icon="mdi:sun-clock",
        value_fn=_forecast_today_kwh,
        attrs_fn=lambda state: build_forecast_attributes(
            state.snapshot,
            state.solar_profile_snapshot,
            track2_current_factor=state.track2_current_factor,
            track2_current_confidence=state.track2_current_confidence,
        ),
    ),
    SolarFriendV2SensorDescription(
        key="flex_active_count",
        name="Flex Active Count",
        native_unit_of_measurement="loads",
        icon="mdi:calendar-clock",
        value_fn=lambda state: len(state.decision.flex_plan.decisions),
        attrs_fn=lambda state: build_flex_attributes(state.decision),
    ),
    SolarFriendV2SensorDescription(
        key="ev_status",
        name="EV Status",
        icon="mdi:ev-station",
        value_fn=_ev_status,
        attrs_fn=lambda state: build_ev_attributes(state.decision, state.snapshot),
    ),
    SolarFriendV2SensorDescription(
        key="ev_charge_mode",
        name="EV Charge Mode",
        icon="mdi:solar-power",
        value_fn=lambda state: state.decision.ev_plan.mode,
        attrs_fn=lambda state: build_ev_attributes(state.decision, state.snapshot),
    ),
    SolarFriendV2SensorDescription(
        key="ev_charging_power",
        name="EV Charging Power",
        native_unit_of_measurement=UnitOfPower.WATT,
        icon="mdi:lightning-bolt",
        value_fn=lambda state: round(state.snapshot.charger.power_w, 1) if state.snapshot.charger is not None else None,
        attrs_fn=lambda state: build_ev_attributes(state.decision, state.snapshot),
    ),
    SolarFriendV2SensorDescription(
        key="ev_vehicle_soc",
        name="EV Vehicle SOC",
        native_unit_of_measurement=PERCENTAGE,
        device_class=SensorDeviceClass.BATTERY,
        state_class=SensorStateClass.MEASUREMENT,
        icon="mdi:battery-electric-vehicle",
        value_fn=lambda state: round(state.snapshot.ev.soc_pct, 1) if state.snapshot.ev is not None else None,
        attrs_fn=lambda state: build_ev_attributes(state.decision, state.snapshot),
    ),
    SolarFriendV2SensorDescription(
        key="runtime_health",
        name="Runtime Health",
        icon="mdi:heart-pulse",
        value_fn=lambda state: state.runtime_health,
        attrs_fn=lambda state: {
            "last_successful_update": (
                state.last_successful_update.isoformat()
                if state.last_successful_update is not None
                else None
            ),
            **build_runtime_attributes(state),
        },
    ),
    SolarFriendV2SensorDescription(
        key="realized_savings_today",
        name="Realized Savings Today",
        native_unit_of_measurement=UNIT_KR,
        icon="mdi:cash-check",
        value_fn=lambda state: state.realized_savings_today,
        attrs_fn=lambda state: build_savings_attributes(state.snapshot, state.battery_tracker_state),
    ),
    SolarFriendV2SensorDescription(
        key="realized_savings_total",
        name="Realized Savings Total",
        native_unit_of_measurement=UNIT_KR,
        icon="mdi:cash-multiple",
        value_fn=lambda state: state.realized_savings_total,
        attrs_fn=lambda state: build_savings_attributes(state.snapshot, state.battery_tracker_state),
    ),
    SolarFriendV2SensorDescription(
        key="battery_plan",
        name="Battery Plan",
        icon="mdi:chart-timeline-variant",
        entity_registry_visible_default=False,
        value_fn=lambda state: len(state.decision.battery_plan.hourly_plan),
        attrs_fn=lambda state: build_horizon_plan_attributes(state.decision, state.snapshot),
    ),
    SolarFriendV2SensorDescription(
        key="forecast_load_w",
        name="Forecast Load",
        native_unit_of_measurement=UnitOfPower.WATT,
        icon="mdi:chart-bell-curve",
        value_fn=lambda state: (
            round(state.consumption_prediction.predicted_w, 1)
            if state.consumption_prediction is not None
            else None
        ),
        attrs_fn=lambda state: build_consumption_attributes(
            state.snapshot,
            state.consumption_prediction,
        ),
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [SolarFriendV2Sensor(coordinator, entry, description) for description in SENSOR_DESCRIPTIONS]
    )


class SolarFriendV2Sensor(CoordinatorEntity, SensorEntity):
    """A single SolarFriend V2 sensor backed by the coordinator."""

    entity_description: SolarFriendV2SensorDescription
    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: Any,
        entry: ConfigEntry,
        description: SolarFriendV2SensorDescription,
    ) -> None:
        super().__init__(coordinator)
        self.entity_description = description
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_{description.key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry_value(entry, CONF_NAME, "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )
        self._attr_entity_registry_visible_default = description.entity_registry_visible_default

    @property
    def _presentation_state(self) -> PresentationState | None:
        state = getattr(self.coordinator, "presentation_state", None)
        if isinstance(state, PresentationState):
            return state
        if isinstance(self.coordinator.data, PresentationState):
            return self.coordinator.data
        return None

    @property
    def native_value(self) -> Any:
        state = self._presentation_state
        if state is None:
            return None
        return self.entity_description.value_fn(state)

    @property
    def extra_state_attributes(self) -> dict[str, Any] | None:
        state = self._presentation_state
        if state is None:
            return None
        return self.entity_description.attrs_fn(state)
