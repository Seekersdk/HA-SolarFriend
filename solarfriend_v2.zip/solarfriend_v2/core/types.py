"""Centrale domænetyper — delte datastrukturer på tværs af hele systemet.

Lag: core
Afhænger af: ingenting
Må IKKE importere: homeassistant, eller andre v2-lag

Centrale klasser:
  PriceSlot:     ét timeinterval med købs- og salgspris
  ForecastSlot:  ét timeinterval med solcelleprognose i kWh
  PowerReading:  øjebliksbillede af alle effektmålinger
  EVState:       EV-bilens aktuelle tilstand
  ChargerState:  laderens aktuelle tilstand

Vigtige invarianter:
  - Alle datetime-felter skal være timezone-aware local tid
  - Normalisering sker i ingest/ — ikke her
  - Ændr ikke feltnavne uden at opdatere world_snapshot.py og alle ingest-adaptere
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass(frozen=True)
class PriceSlot:
    start: datetime          # always aware local
    end: datetime            # always aware local
    price_dkk: float
    sell_price_dkk: float = 0.0


@dataclass(frozen=True)
class ForecastSlot:
    start: datetime          # always aware local
    end: datetime            # always aware local
    kwh: float


@dataclass(frozen=True)
class PowerReading:
    pv_w: float
    grid_w: float            # positive = import, negative = export
    battery_w: float         # positive = discharge, negative = charge
    load_w: float
    ev_w: float = 0.0
    timestamp: Optional[datetime] = None


@dataclass(frozen=True)
class EVState:
    soc_pct: float
    target_soc_pct: float
    plugged_in: bool
    charging: bool
    range_km: float
    battery_kwh: float


@dataclass(frozen=True)
class ChargerState:
    connected: bool
    charging: bool
    power_w: float
    phases: int
