"""Ét sted for al datetime-håndtering — ingen andre steder må parse eller konvertere timestamps.

Lag: core
Afhænger af: ingenting (stdlib only — zoneinfo, datetime)
Må IKKE importere: homeassistant, eller andre v2-lag

Centrale funktioner:
  set_timezone(tz_name):   konfigurer lokal tidszone ved startup (kaldes af coordinator)
  now_local():             aktuel tid som aware local datetime
  normalize_local(dt):     konverter enhver datetime til aware local
  parse_utc_or_aware(v):   parse timestamps fra eksterne APIs (Solcast, forecast)
  parse_local_or_aware(v): parse timestamps fra HA-attributter og interne slots

Vigtige invarianter:
  - Kald set_timezone() én gang ved coordinator startup — alle andre funktioner fejler uden det
  - Brug aldrig datetime.now() direkte — brug now_local()
  - parse_utc_or_aware:   naive input antages UTC  (Solcast, externe APIs)
  - parse_local_or_aware: naive input antages lokal tid (HA attrs, prisdata, plan-slots)
  - Dette løser v1's datetime-rod — hold kontrakten skarp
"""
from __future__ import annotations

import zoneinfo
from datetime import datetime, timezone
from typing import Union

_tz: zoneinfo.ZoneInfo | None = None


def set_timezone(tz_name: str) -> None:
    """Konfigurer lokal tidszone. Kaldes én gang af coordinator ved startup.

    Eksempel: set_timezone("Europe/Copenhagen")
    """
    global _tz
    _tz = zoneinfo.ZoneInfo(tz_name)


def _require_tz() -> zoneinfo.ZoneInfo:
    if _tz is None:
        raise RuntimeError(
            "time_utils ikke konfigureret. Kald set_timezone() ved startup."
        )
    return _tz


def now_local() -> datetime:
    """Aktuel tid som timezone-aware local datetime."""
    return datetime.now(_require_tz())


def normalize_local(dt: datetime) -> datetime:
    """Konverter enhver datetime til aware local datetime.

    - naive     → antages UTC → konverteres til lokal tid
    - aware UTC → konverteres til lokal tid
    - aware lokal → returneres uændret
    """
    tz = _require_tz()
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(tz)


def parse_utc_or_aware(value: Union[str, datetime]) -> datetime:
    """Parse timestamp fra ekstern API (Solcast, forecast.solar osv.).

    Naive input antages at være UTC.
    Returnerer altid aware local datetime.
    """
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    return normalize_local(value)


def parse_local_or_aware(value: Union[str, datetime]) -> datetime:
    """Parse timestamp fra HA-attributter, prisdata eller interne plan-slots.

    Naive input antages at være lokal tid (ikke UTC).
    Returnerer altid aware local datetime.
    """
    tz = _require_tz()
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    if value.tzinfo is None:
        return value.replace(tzinfo=tz)
    return value.astimezone(tz)
