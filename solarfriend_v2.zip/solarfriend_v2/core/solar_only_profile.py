"""Shared solar-only EV profiles used by planning and runtime."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SolarOnlyProfile:
    key: str
    label: str
    start_surplus_w: float
    stop_surplus_w: float
    start_hold_seconds: int
    stop_hold_seconds: int
    grid_buffer_w: float
    phase_switch_up_w: float
    phase_switch_down_w: float


CLEAR_PROFILE = SolarOnlyProfile(
    key="clear",
    label="Skyfrit",
    start_surplus_w=1600.0,
    stop_surplus_w=1410.0,
    start_hold_seconds=300,
    stop_hold_seconds=300,
    grid_buffer_w=0.0,
    phase_switch_up_w=4700.0,
    phase_switch_down_w=4300.0,
)

PARTLY_CLOUDY_PROFILE = SolarOnlyProfile(
    key="partly_cloudy",
    label="Delvist skyet",
    start_surplus_w=2000.0,
    stop_surplus_w=1200.0,
    start_hold_seconds=300,
    stop_hold_seconds=600,
    grid_buffer_w=300.0,
    phase_switch_up_w=5200.0,
    phase_switch_down_w=4400.0,
)

CLOUDY_PROFILE = SolarOnlyProfile(
    key="cloudy",
    label="Overskyet",
    start_surplus_w=2000.0,
    stop_surplus_w=1000.0,
    start_hold_seconds=300,
    stop_hold_seconds=600,
    grid_buffer_w=500.0,
    phase_switch_up_w=5600.0,
    phase_switch_down_w=4500.0,
)

DEFAULT_PROFILE = PARTLY_CLOUDY_PROFILE


def select_solar_only_profile(cloud_coverage_pct: float | None) -> SolarOnlyProfile:
    if cloud_coverage_pct is None:
        return DEFAULT_PROFILE
    if cloud_coverage_pct < 15.0:
        return CLEAR_PROFILE
    if cloud_coverage_pct >= 70.0:
        return CLOUDY_PROFILE
    return PARTLY_CLOUDY_PROFILE
