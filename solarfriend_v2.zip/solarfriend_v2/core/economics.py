"""Batteriøkonomi — rene beregningsfunktioner for batterislid, cost og besparelser.

Lag: core
Afhænger af: ingenting
Må IKKE importere: homeassistant, eller andre v2-lag

Centrale funktioner:
  weighted_battery_cost():     vægtet gennemsnitspris på energi i batteriet
  discharge_is_profitable():   skal vi aflade nu?
  sell_is_profitable():        skal vi sælge til nettet nu?

Vigtige invarianter:
  - Batterislid bogføres fuldt ved ladning (ikke ved afladning)
  - Solar i batteri: 0 + battery_cost_per_kwh
  - Grid i batteri:  grid_price + battery_cost_per_kwh
  - Disse regler afspejler v1's beslutning — ændr ikke uden at opdatere AI_LOG.md
"""
from __future__ import annotations


def weighted_battery_cost(
    solar_kwh: float,
    grid_kwh: float,
    grid_avg_price_dkk: float,
    battery_cost_per_kwh: float,
) -> float:
    """Weighted average cost of energy currently in the battery.

    Battery wear is booked at charge time:
    - solar → battery: 0 + battery_cost_per_kwh
    - grid  → battery: grid_avg_price + battery_cost_per_kwh

    Args:
        solar_kwh:           kWh currently in battery charged from solar.
        grid_kwh:            kWh currently in battery charged from grid.
        grid_avg_price_dkk:  weighted average raw grid price paid (DKK/kWh).
        battery_cost_per_kwh: wear/degradation cost per kWh charged (DKK/kWh).

    Returns 0.0 if the battery is empty.
    """
    total = solar_kwh + grid_kwh
    if total <= 0:
        return 0.0
    solar_cost = solar_kwh * battery_cost_per_kwh
    grid_cost = grid_kwh * (grid_avg_price_dkk + battery_cost_per_kwh)
    return (solar_cost + grid_cost) / total


def discharge_is_profitable(
    current_price_dkk: float,
    weighted_cost_dkk: float,
    min_margin_dkk: float = 0.0,
) -> bool:
    """True if discharging the battery is economically worthwhile.

    Profitable when: current_price > weighted_cost + min_margin

    Args:
        current_price_dkk:  spot price of grid electricity now (DKK/kWh).
        weighted_cost_dkk:  weighted average cost of battery content (DKK/kWh).
        min_margin_dkk:     minimum required margin above cost (default 0.0).
    """
    return current_price_dkk > weighted_cost_dkk + min_margin_dkk


def sell_is_profitable(
    sell_price_dkk: float,
    weighted_cost_dkk: float,
    min_charge_saving_dkk: float,
) -> bool:
    """True if selling battery energy to the grid is worthwhile.

    Profitable when: sell_price >= weighted_cost + min_charge_saving

    The min_charge_saving acts as a deadband — it must exceed mere break-even
    to justify the sell cycle and associated grid tariffs.

    Args:
        sell_price_dkk:       feed-in tariff / spot sell price (DKK/kWh).
        weighted_cost_dkk:    weighted average cost of battery content (DKK/kWh).
        min_charge_saving_dkk: minimum spread required above battery cost.
    """
    return sell_price_dkk >= weighted_cost_dkk + min_charge_saving_dkk
