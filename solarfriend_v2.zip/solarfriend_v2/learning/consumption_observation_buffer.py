"""Compact rolling observation buffer for consumption-model replay.

Lag: learning
Afhaenger af: core/types.py
Maa IKKE importere: homeassistant, planning/, runtime/, control/

Centrale klasser/funktioner:
  ConsumptionObservationBuffer: keeps a compact 14-day, 10-minute ringbuffer

Vigtige invarianter:
  - Stores household load after EV subtraction, not raw total load
  - Keeps only one sample per 10-minute bucket
  - Buffer is replay-oriented, not human-readable analytics
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from ..core.types import PowerReading

_MAX_REASONABLE_LOAD_W = 10_000.0


@dataclass(frozen=True)
class ConsumptionObservation:
    timestamp: datetime
    household_load_w: float
    outdoor_temp_c: float | None = None
    indoor_temp_c: float | None = None

    def as_state(self) -> dict[str, Any]:
        return {
            "ts": self.timestamp.isoformat(),
            "load_w": round(self.household_load_w, 3),
            "outdoor_temp_c": self.outdoor_temp_c,
            "indoor_temp_c": self.indoor_temp_c,
        }


class ConsumptionObservationBuffer:
    def __init__(
        self,
        *,
        retention_days: int = 14,
        bucket_minutes: int = 10,
    ) -> None:
        self._retention = timedelta(days=retention_days)
        self._bucket_minutes = bucket_minutes
        self._samples: dict[datetime, ConsumptionObservation] = {}

    def observe(self, reading: PowerReading, context: dict[str, Any]) -> None:
        timestamp = reading.timestamp or context.get("timestamp")
        if not isinstance(timestamp, datetime) or timestamp.tzinfo is None:
            return
        household_load_w = max(float(reading.load_w), 0.0)
        if household_load_w > _MAX_REASONABLE_LOAD_W:
            return
        bucket_ts = self._bucket_start(timestamp)
        self._samples[bucket_ts] = ConsumptionObservation(
            timestamp=bucket_ts,
            household_load_w=household_load_w,
            outdoor_temp_c=_coerce_float(context.get("outdoor_temp_c")),
            indoor_temp_c=_coerce_float(context.get("indoor_temp_c")),
        )
        self._prune(bucket_ts)

    def observations(self) -> list[ConsumptionObservation]:
        return [self._samples[key] for key in sorted(self._samples)]

    def get_state(self) -> dict[str, Any]:
        return {"samples": [sample.as_state() for sample in self.observations()]}

    def set_state(self, state: dict[str, Any]) -> None:
        self._samples = {}
        raw_samples = state.get("samples", [])
        newest: datetime | None = None
        for raw in raw_samples:
            if not isinstance(raw, dict):
                continue
            try:
                ts = datetime.fromisoformat(str(raw.get("ts")))
            except (TypeError, ValueError):
                continue
            if ts.tzinfo is None:
                continue
            observation = ConsumptionObservation(
                timestamp=self._bucket_start(ts),
                household_load_w=float(raw.get("load_w", 0.0)),
                outdoor_temp_c=_coerce_float(raw.get("outdoor_temp_c")),
                indoor_temp_c=_coerce_float(raw.get("indoor_temp_c")),
            )
            self._samples[observation.timestamp] = observation
            newest = observation.timestamp if newest is None else max(newest, observation.timestamp)
        if newest is not None:
            self._prune(newest)

    def _bucket_start(self, timestamp: datetime) -> datetime:
        minute = (timestamp.minute // self._bucket_minutes) * self._bucket_minutes
        return timestamp.replace(minute=minute, second=0, microsecond=0)

    def _prune(self, newest: datetime) -> None:
        cutoff = newest - self._retention
        self._samples = {key: value for key, value in self._samples.items() if key >= cutoff}


def _coerce_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
