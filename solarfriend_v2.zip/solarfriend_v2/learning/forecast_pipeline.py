"""Track-2 forecast pipeline helpers.

Lag: learning
Afhaenger af: core/types.py, learning/solar_profile.py
Maa IKKE importere: planning/, control/, runtime/, homeassistant

Ansvar:
  - Observe current PV/forecast slot into SolarProfile
  - Apply learned Track-2 factors to future forecast slots
  - Build comparison rows for later presentation
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime
from typing import Any

from ..core.types import ForecastSlot, PowerReading
from .solar_profile import SolarProfile


class SolarForecastPipeline:
    """Thin adapter around SolarProfile for orchestration-time forecast handling."""

    def __init__(self, profile: SolarProfile) -> None:
        self._profile = profile

    def observe_current_slot(
        self,
        *,
        reading: PowerReading,
        now: datetime,
        forecast: list[ForecastSlot],
        solar_elevation_deg: float | None,
        solar_azimuth_deg: float | None,
        cloud_coverage_pct: float | None,
    ) -> None:
        current_slot = self._find_forecast_slot(now, forecast)
        if current_slot is None or solar_elevation_deg is None or solar_azimuth_deg is None:
            return

        self._profile.observe(
            reading,
            {
                "forecast_slot_kwh": current_slot.kwh,
                "solar_elevation_deg": solar_elevation_deg,
                "solar_azimuth_deg": solar_azimuth_deg,
                "cloud_coverage_pct": cloud_coverage_pct,
            },
        )

    def correct_forecast(
        self,
        forecast: list[ForecastSlot],
        *,
        latitude: float | None,
        longitude: float | None,
    ) -> list[ForecastSlot]:
        if not forecast:
            return forecast

        corrected: list[ForecastSlot] = []
        comparison_points: list[dict[str, Any]] = []

        for slot in forecast:
            midpoint = slot.start + ((slot.end - slot.start) / 2)
            elevation_deg, azimuth_deg = self._solar_position(
                midpoint,
                latitude=latitude,
                longitude=longitude,
            )
            factor = None
            if elevation_deg is not None and azimuth_deg is not None:
                factor = self._profile.get_factor(elevation_deg, azimuth_deg)
            corrected_kwh = round(max(0.0, slot.kwh * factor), 4) if factor is not None else slot.kwh
            corrected.append(replace(slot, kwh=corrected_kwh))
            comparison_points.append(
                {
                    "start": slot.start,
                    "raw_forecast_kwh": slot.kwh,
                    "solar_elevation_deg": elevation_deg,
                    "solar_azimuth_deg": azimuth_deg,
                }
            )

        self._profile.build_snapshot(
            comparison_points=comparison_points,
            now=forecast[0].start,
        )
        return corrected

    def _find_forecast_slot(
        self,
        now: datetime,
        forecast: list[ForecastSlot],
    ) -> ForecastSlot | None:
        for slot in forecast:
            if slot.start <= now < slot.end:
                return slot
        return None

    def _solar_position(
        self,
        when: datetime,
        *,
        latitude: float | None,
        longitude: float | None,
    ) -> tuple[float | None, float | None]:
        if latitude is None or longitude is None:
            return (None, None)
        try:
            from astral import LocationInfo
            from astral.sun import azimuth as calc_azimuth, elevation as calc_elevation
        except ImportError:
            return (None, None)

        observer = LocationInfo(latitude=latitude, longitude=longitude).observer
        try:
            return (
                float(calc_elevation(observer, dateandtime=when)),
                float(calc_azimuth(observer, dateandtime=when)),
            )
        except (TypeError, ValueError):
            return (None, None)
