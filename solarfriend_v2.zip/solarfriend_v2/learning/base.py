"""Basisinterface for alle læringsmoduler.

Lag: learning
Afhænger af: core/types.py
Må IKKE importere: homeassistant, planning/, control/, runtime/

Centrale klasser:
  LearningModule: abstract base — implementer observe(), get_state(), set_state()

Et læringsmodul:
  - Modtager observationer løbende via observe()
  - Opdaterer sin interne model
  - Kan gemmes og gendannes via get_state() / set_state() → checkpoint
  - Eksponerer et snapshot til WorldSnapshot

Tilføj nyt læringsmodul:
  1. Implementer LearningModule
  2. Registrer i coordinator.py learning-setup
  3. Tilføj checkpoint-nøgle
  4. Overvej om WorldSnapshot skal have nye felter

Vigtige invarianter:
  - Alle læringsmoduler observerer altid — uanset hvilken model der er aktiv
  - get_state() skal returnere alt der er nødvendigt for set_state() at genskabe fuld tilstand
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..core.types import PowerReading


class LearningModule(ABC):

    @abstractmethod
    def observe(self, reading: PowerReading, context: dict[str, Any]) -> None:
        """Record a new observation and update the model."""
        ...

    @abstractmethod
    def get_state(self) -> dict[str, Any]:
        """Return serializable state for checkpointing."""
        ...

    @abstractmethod
    def set_state(self, state: dict[str, Any]) -> None:
        """Restore state from a checkpoint."""
        ...
