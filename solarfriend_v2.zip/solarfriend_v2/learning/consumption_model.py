"""Consumption models for household load forecasting.

Lag: learning
Afhænger af: core/types.py, learning/base.py
Må IKKE importere: homeassistant, planning/, control/, runtime/

Centrale klasser/funktioner:
  FeatureConfig:             optional sensor capabilities for AdvancedModel
  SimplePredictionSnapshot: stable output view of SimpleProfile internals
  AdvancedPredictionSnapshot: stable output view of AdvancedModel internals
  ConsumptionPredictionSnapshot: stable output view for the active model choice
  SimpleProfile:            weekday/weekend hourly averages with bootstrap support
  AdvancedModel:            first-pass dynamic model with baseload, thermal and behavioral terms
  ConsumptionModel:         facade that feeds both models and selects the live prediction

Vigtige invarianter / gotchas:
  - SimpleProfile may bootstrap from history, but live samples always outweigh bootstrap data
  - AdvancedModel learns from live observations only
  - advanced_enabled is the only live selection gate; readiness is informational
  - All timestamps must already be timezone-aware local before they reach this module

Næste lag / senere integration:
  - runtime/checkpoint.py skal gemme SimpleProfile og AdvancedModel på separate V2 keys
  - runtime/migration.py skal kun migrere V1 ConsumptionProfile til SimpleProfile
  - coordinator/runtime skal kalde observe() på hvert tick med ingest-normaliseret context
  - manuel "load earlier data" knap/service skal senere kalde load_simple_seed_data()
  - planning/world_snapshot.py og presentation/ skal læse ConsumptionPredictionSnapshot
  - HA sensorer/services bygges først i de senere faser; denne fil er kun learning-laget
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta
import math
from typing import Any, Iterable

import numpy as np

from ..core.types import PowerReading
from .base import LearningModule

DEFAULT_WATT = 500.0
MAX_REASONABLE_LOAD_W = 10_000.0
BOOTSTRAP_SAMPLE_WEIGHT = 0.05
BOOTSTRAP_MIN_SAMPLES = 3.0
SIMPLE_LEARNING_SAMPLES_PER_DAY = 4.0
ADVANCED_MIN_OBSERVATIONS = 72
ADVANCED_MIN_POPULATED_HOURS = 12
AR_DAY_LOOKBACK = timedelta(hours=24)
AR_LAG_TOLERANCE = timedelta(hours=2)
ADVANCED_EXPECTED_SAMPLE_SECONDS = 30.0
AR_HISTORY_RETENTION = timedelta(hours=30)
AR_HISTORY_MAXLEN = int(AR_HISTORY_RETENTION.total_seconds() / ADVANCED_EXPECTED_SAMPLE_SECONDS) + 8
FOURIER_COMPONENT_COUNT = 3
BASELOAD_MIN_W = 50.0
BASELOAD_MAX_W = 4_000.0
FOURIER_STATE_COUNT = FOURIER_COMPONENT_COUNT * 4
STATE_INDEX_BASELOAD = 0
STATE_INDEX_HEAT = 1
STATE_INDEX_INDOOR = 2
STATE_INDEX_FOURIER_START = 3
STATE_INDEX_FOURIER_END = STATE_INDEX_FOURIER_START + FOURIER_STATE_COUNT
STATE_INDEX_AR_START = STATE_INDEX_FOURIER_END
STATE_INDEX_AR_END = STATE_INDEX_AR_START + 3
ADVANCED_STATE_DIM = STATE_INDEX_AR_END


@dataclass
class FeatureConfig:
    """Sensor configuration for AdvancedModel. All fields optional."""

    outdoor_temp_entity: str | None = None
    indoor_temp_entity: str | None = None


@dataclass(frozen=True)
class SeedLoadResult:
    """Result of a manual seed-load operation for SimpleProfile."""

    source: str
    imported_buckets: int = 0
    imported_samples: int = 0


@dataclass(frozen=True)
class SimplePredictionSnapshot:
    """Stable read-only view of SimpleProfile state for one hour."""

    readiness: str
    days_collected: int
    predicted_w: float
    live_samples: float
    bootstrap_samples: float
    live_avg_w: float
    bootstrap_avg_w: float


@dataclass(frozen=True)
class AdvancedPredictionSnapshot:
    """Stable read-only view of AdvancedModel state and latest prediction."""

    readiness: str
    is_mature: bool
    observation_count: int
    populated_hours: int
    mean_abs_error_w: float
    recent_abs_error_w: float
    shadow_simple_abs_error_w: float
    baseload_w: float
    thermal_w: float
    fourier_w: float
    ar_w: float
    behavioral_w: float
    predicted_w: float


@dataclass(frozen=True)
class ConsumptionPredictionSnapshot:
    """Stable prediction contract for the active consumption model."""

    active_model: str
    readiness: str
    predicted_w: float
    simple_predicted_w: float
    advanced_predicted_w: float
    days_collected: int
    advanced_is_mature: bool
    mean_abs_error_w: float = 0.0
    recent_abs_error_w: float = 0.0
    shadow_simple_abs_error_w: float = 0.0
    prediction_gap_w: float = 0.0
    baseload_w: float = 0.0
    thermal_w: float = 0.0
    fourier_w: float = 0.0
    ar_w: float = 0.0
    behavioral_w: float = 0.0


@dataclass
class _ProfileBucket:
    live_samples: float = 0.0
    live_avg_w: float = 0.0
    bootstrap_samples: float = 0.0
    bootstrap_avg_w: float = 0.0

    def add_live(self, value_w: float) -> None:
        total = self.live_samples + 1.0
        self.live_avg_w = ((self.live_avg_w * self.live_samples) + value_w) / total
        self.live_samples = total

    def add_bootstrap(self, value_w: float, weight: float = BOOTSTRAP_MIN_SAMPLES) -> None:
        if self.bootstrap_samples <= 0:
            self.bootstrap_avg_w = value_w
            self.bootstrap_samples = max(BOOTSTRAP_MIN_SAMPLES, weight)
            return

        total = self.bootstrap_samples + weight
        self.bootstrap_avg_w = (
            (self.bootstrap_avg_w * self.bootstrap_samples) + (value_w * weight)
        ) / total
        self.bootstrap_samples = total

    def predicted_w(self) -> float:
        effective_bootstrap = self.bootstrap_samples * BOOTSTRAP_SAMPLE_WEIGHT
        total = self.live_samples + effective_bootstrap
        if total <= 0:
            return DEFAULT_WATT
        return (
            (self.live_avg_w * self.live_samples)
            + (self.bootstrap_avg_w * effective_bootstrap)
        ) / total

    def as_state(self) -> dict[str, float]:
        return {
            "live_samples": round(self.live_samples, 3),
            "live_avg_w": round(self.live_avg_w, 3),
            "bootstrap_samples": round(self.bootstrap_samples, 3),
            "bootstrap_avg_w": round(self.bootstrap_avg_w, 3),
        }

    @classmethod
    def from_state(cls, state: dict[str, Any]) -> _ProfileBucket:
        return cls(
            live_samples=float(state.get("live_samples", 0.0)),
            live_avg_w=float(state.get("live_avg_w", 0.0)),
            bootstrap_samples=float(state.get("bootstrap_samples", 0.0)),
            bootstrap_avg_w=float(state.get("bootstrap_avg_w", 0.0)),
        )


@dataclass
class _ObservationContext:
    timestamp: datetime
    hour: int
    minute: int
    weekday: int
    is_weekend: bool
    outdoor_temp_c: float | None = None
    indoor_temp_c: float | None = None


@dataclass(frozen=True)
class _PredictionComponents:
    baseload_w: float
    thermal_w: float
    fourier_w: float
    ar_w: float
    behavioral_w: float
    predicted_w: float


def _new_profile_buckets() -> dict[str, dict[int, _ProfileBucket]]:
    return {
        "weekday": {hour: _ProfileBucket() for hour in range(24)},
        "weekend": {hour: _ProfileBucket() for hour in range(24)},
    }


def _coerce_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _extract_context(reading: PowerReading, context: dict[str, Any]) -> _ObservationContext:
    timestamp = reading.timestamp
    if timestamp is None:
        timestamp = context.get("timestamp")
    if not isinstance(timestamp, datetime):
        raise ValueError("Consumption models require an aware datetime timestamp")
    if timestamp.tzinfo is None:
        raise ValueError("Consumption models require timezone-aware timestamps")

    is_weekend = bool(context.get("is_weekend", timestamp.weekday() >= 5))
    return _ObservationContext(
        timestamp=timestamp,
        hour=int(context.get("hour", timestamp.hour)),
        minute=int(context.get("minute", timestamp.minute)),
        weekday=int(context.get("weekday", timestamp.weekday())),
        is_weekend=is_weekend,
        outdoor_temp_c=_coerce_float(context.get("outdoor_temp_c")),
        indoor_temp_c=_coerce_float(context.get("indoor_temp_c")),
    )


def _clean_household_load(reading: PowerReading) -> float | None:
    household_w = max(float(reading.load_w), 0.0)
    if household_w > MAX_REASONABLE_LOAD_W:
        return None
    return household_w


def _profile_key(is_weekend: bool) -> str:
    return "weekend" if is_weekend else "weekday"


class SimpleProfile(LearningModule):
    """Weekday/weekend hourly averages with optional low-weight bootstrap data."""

    def __init__(self) -> None:
        self._profiles = _new_profile_buckets()

    def observe(self, reading: PowerReading, context: dict[str, Any]) -> None:
        load_w = _clean_household_load(reading)
        if load_w is None:
            return

        obs = _extract_context(reading, context)
        day_key = _profile_key(obs.is_weekend)
        self._profiles[day_key][obs.hour].add_live(load_w)

    def bootstrap_from_history(self, readings: Iterable[PowerReading]) -> int:
        """Seed hourly buckets from historical load readings with low weight."""

        bootstrapped = 0
        for reading in readings:
            if reading.timestamp is None or reading.timestamp.tzinfo is None:
                continue
            load_w = _clean_household_load(reading)
            if load_w is None:
                continue
            day_key = _profile_key(reading.timestamp.weekday() >= 5)
            self._profiles[day_key][reading.timestamp.hour].add_bootstrap(load_w)
            bootstrapped += 1
        return bootstrapped

    def load_seed_data(
        self,
        *,
        v1_state: dict[str, Any] | None = None,
        history_readings: Iterable[PowerReading] | None = None,
    ) -> SeedLoadResult:
        """Load manual seed data with explicit priority.

        Priority:
          1. V1 model state, if present and usable
          2. Historical load readings, if V1 state is unavailable
          3. No-op otherwise
        """

        if isinstance(v1_state, dict) and self._looks_like_v1_state(v1_state):
            imported_buckets, imported_samples = self._import_v1_state(v1_state)
            if imported_buckets > 0:
                return SeedLoadResult(
                    source="imported_v1_profile",
                    imported_buckets=imported_buckets,
                    imported_samples=imported_samples,
                )

        if history_readings is not None:
            bootstrapped = self.bootstrap_from_history(history_readings)
            if bootstrapped > 0:
                return SeedLoadResult(
                    source="bootstrapped_from_history",
                    imported_buckets=bootstrapped,
                    imported_samples=bootstrapped,
                )

        return SeedLoadResult(source="no_seed_data_found")

    def get_predicted_w(self, hour: int, is_weekend: bool) -> float:
        bucket = self._profiles[_profile_key(is_weekend)][hour]
        if bucket.live_samples < 3.0 and bucket.bootstrap_samples < BOOTSTRAP_MIN_SAMPLES:
            return DEFAULT_WATT
        return round(bucket.predicted_w(), 1)

    @property
    def days_collected(self) -> int:
        estimates: list[int] = []
        for profile in self._profiles.values():
            populated = sorted(
                bucket.live_samples for bucket in profile.values() if bucket.live_samples > 0
            )
            if len(populated) < 6:
                estimates.append(0)
                continue
            median = populated[len(populated) // 2]
            estimates.append(int(median // SIMPLE_LEARNING_SAMPLES_PER_DAY))
        return max(estimates, default=0)

    @property
    def readiness(self) -> str:
        days = self.days_collected
        if days < 3:
            return "LEARNING"
        if days < 7:
            return "LOW"
        if days < 14:
            return "MEDIUM"
        return "HIGH"

    def build_snapshot(self, hour: int, is_weekend: bool) -> SimplePredictionSnapshot:
        """Return a stable summary of the simple profile for one hour."""

        bucket = self._profiles[_profile_key(is_weekend)][hour]
        return SimplePredictionSnapshot(
            predicted_w=self.get_predicted_w(hour, is_weekend),
            days_collected=self.days_collected,
            readiness=self.readiness,
            live_samples=round(bucket.live_samples, 3),
            bootstrap_samples=round(bucket.bootstrap_samples, 3),
            live_avg_w=round(bucket.live_avg_w, 3),
            bootstrap_avg_w=round(bucket.bootstrap_avg_w, 3),
        )

    def get_state(self) -> dict[str, Any]:
        return {
            "profiles": {
                day_key: {
                    str(hour): bucket.as_state()
                    for hour, bucket in profile.items()
                }
                for day_key, profile in self._profiles.items()
            }
        }

    def set_state(self, state: dict[str, Any]) -> None:
        self._profiles = _new_profile_buckets()
        if self._looks_like_v1_state(state):
            self._import_v1_state(state)
            return

        profiles = state.get("profiles", {})
        for day_key in ("weekday", "weekend"):
            for hour in range(24):
                raw_bucket = profiles.get(day_key, {}).get(str(hour))
                if raw_bucket:
                    self._profiles[day_key][hour] = _ProfileBucket.from_state(raw_bucket)

    @staticmethod
    def _looks_like_v1_state(state: dict[str, Any]) -> bool:
        return "profiles" not in state and any(day_key in state for day_key in ("weekday", "weekend"))

    def _import_v1_state(self, state: dict[str, Any]) -> tuple[int, int]:
        """Import V1 ConsumptionProfile buckets as bootstrap state.

        V1 data is useful prior knowledge, but it must not masquerade as V2 live
        observations. Therefore all migrated buckets land in bootstrap fields only.
        """

        imported_buckets = 0
        imported_samples = 0
        for day_key in ("weekday", "weekend"):
            raw_profile = state.get(day_key, {})
            if not isinstance(raw_profile, dict):
                continue
            for hour in range(24):
                raw_bucket = raw_profile.get(str(hour), raw_profile.get(hour))
                if not isinstance(raw_bucket, dict):
                    continue

                avg_w = _coerce_float(raw_bucket.get("avg_watt"))
                samples = _coerce_float(raw_bucket.get("samples")) or 0.0
                if avg_w is None or samples <= 0:
                    continue

                self._profiles[day_key][hour] = _ProfileBucket(
                    live_samples=0.0,
                    live_avg_w=0.0,
                    bootstrap_samples=max(BOOTSTRAP_MIN_SAMPLES, samples),
                    bootstrap_avg_w=avg_w,
                )
                imported_buckets += 1
                imported_samples += int(samples)
        return imported_buckets, imported_samples


class AdvancedModel(LearningModule):
    """Bayesian dynamic linear model for household load forecasting."""

    def __init__(self, feature_config: FeatureConfig) -> None:
        self._config = feature_config
        self._state = np.zeros(ADVANCED_STATE_DIM, dtype=float)
        self._state[STATE_INDEX_BASELOAD] = 300.0
        self._state[STATE_INDEX_HEAT] = 18.0
        self._state[STATE_INDEX_INDOOR] = 35.0
        self._covariance = np.eye(ADVANCED_STATE_DIM, dtype=float) * 400.0
        self._process_noise = np.eye(ADVANCED_STATE_DIM, dtype=float) * 0.05
        self._process_noise[STATE_INDEX_BASELOAD, STATE_INDEX_BASELOAD] = 16.0
        self._process_noise[STATE_INDEX_HEAT, STATE_INDEX_HEAT] = 0.20
        self._process_noise[STATE_INDEX_INDOOR, STATE_INDEX_INDOOR] = 0.20
        self._measurement_variance = 160.0 ** 2
        self._indoor_baseline_c: float | None = None
        self._observation_count: int = 0
        self._recent_loads: deque[float] = deque(maxlen=AR_HISTORY_MAXLEN)
        self._recent_timestamps: deque[datetime] = deque(maxlen=AR_HISTORY_MAXLEN)
        self._recent_residuals: deque[float] = deque(maxlen=AR_HISTORY_MAXLEN)
        self._visited_profile_hours: set[tuple[int, int]] = set()
        self._mean_abs_error_w: float = 0.0
        self._recent_abs_error_w: float = 0.0
        self._shadow_simple_abs_error_w: float = 0.0
        self._last_prediction_components: dict[str, float] = {
            "baseload_w": 300.0,
            "thermal_w": 0.0,
            "fourier_w": 0.0,
            "ar_w": 0.0,
            "behavioral_w": 0.0,
            "predicted_w": DEFAULT_WATT,
        }
        self._last_context: dict[str, float | int | bool | None] = {}

    @property
    def baseload_w(self) -> float:
        return round(float(self._state[STATE_INDEX_BASELOAD]), 1)

    @property
    def is_mature(self) -> bool:
        return (
            self._observation_count >= ADVANCED_MIN_OBSERVATIONS
            and self.populated_hours >= ADVANCED_MIN_POPULATED_HOURS
        )

    @property
    def readiness(self) -> str:
        if self._observation_count == 0:
            return "COLD_START"
        if self.is_mature:
            return "READY"
        return "LEARNING"

    @property
    def populated_hours(self) -> int:
        return len(self._visited_profile_hours)

    @property
    def last_prediction_components(self) -> dict[str, float]:
        return dict(self._last_prediction_components)

    def build_snapshot(self) -> AdvancedPredictionSnapshot:
        return AdvancedPredictionSnapshot(
            readiness=self.readiness,
            is_mature=self.is_mature,
            observation_count=self._observation_count,
            populated_hours=self.populated_hours,
            mean_abs_error_w=round(self._mean_abs_error_w, 1),
            recent_abs_error_w=round(self._recent_abs_error_w, 1),
            shadow_simple_abs_error_w=round(self._shadow_simple_abs_error_w, 1),
            baseload_w=round(self._last_prediction_components["baseload_w"], 1),
            thermal_w=round(self._last_prediction_components["thermal_w"], 1),
            fourier_w=round(self._last_prediction_components["fourier_w"], 1),
            ar_w=round(self._last_prediction_components["ar_w"], 1),
            behavioral_w=round(self._last_prediction_components["behavioral_w"], 1),
            predicted_w=round(self._last_prediction_components["predicted_w"], 1),
        )

    def observe(self, reading: PowerReading, context: dict[str, Any]) -> None:
        load_w = _clean_household_load(reading)
        if load_w is None:
            return

        obs = _extract_context(reading, context)
        self._visited_profile_hours.add((obs.weekday, obs.hour))
        self._update_indoor_baseline(obs)

        feature_vector = self._feature_vector(obs)
        components = self._components_from_state(feature_vector, self._state)
        predicted_before_update = components.predicted_w

        predicted_covariance = self._covariance + self._process_noise
        projection = predicted_covariance @ feature_vector
        innovation_variance = float(feature_vector.T @ projection) + self._measurement_variance
        innovation_variance = max(innovation_variance, 1.0)
        innovation = load_w - predicted_before_update
        kalman_gain = projection / innovation_variance

        self._state = self._state + (kalman_gain * innovation)
        self._covariance = predicted_covariance - np.outer(kalman_gain, projection)
        self._covariance = (self._covariance + self._covariance.T) / 2.0
        self._clip_state()

        self._update_error_metrics(load_w, predicted_before_update)
        self._recent_loads.append(load_w)
        self._recent_timestamps.append(obs.timestamp)
        self._recent_residuals.append(innovation)
        self._observation_count += 1

    def get_predicted_w(self, hour: int, context: dict[str, Any]) -> float:
        is_weekend = bool(context.get("is_weekend", False))
        obs = _ObservationContext(
            timestamp=(
                context.get("timestamp")
                if isinstance(context.get("timestamp"), datetime) and context.get("timestamp").tzinfo is not None
                else datetime.now(tz=self._recent_timestamps[-1].tzinfo) if self._recent_timestamps else datetime.now().astimezone()
            ),
            hour=hour,
            minute=int(context.get("minute", 0)),
            weekday=int(context.get("weekday", 0)),
            is_weekend=is_weekend,
            outdoor_temp_c=_coerce_float(context.get("outdoor_temp_c")),
            indoor_temp_c=_coerce_float(context.get("indoor_temp_c")),
        )
        feature_vector = self._feature_vector(obs)
        components = self._components_from_state(feature_vector, self._state)
        self._last_prediction_components = {
            "baseload_w": round(components.baseload_w, 1),
            "thermal_w": round(components.thermal_w, 1),
            "fourier_w": round(components.fourier_w, 1),
            "ar_w": round(components.ar_w, 1),
            "behavioral_w": round(components.behavioral_w, 1),
            "predicted_w": round(components.predicted_w, 1),
        }
        self._last_context = {
            "hour": hour,
            "weekday": obs.weekday,
            "is_weekend": is_weekend,
            "outdoor_temp_c": obs.outdoor_temp_c,
            "indoor_temp_c": obs.indoor_temp_c,
        }
        return round(components.predicted_w, 1)

    def _update_indoor_baseline(self, obs: _ObservationContext) -> None:
        if not self._config.indoor_temp_entity or obs.indoor_temp_c is None:
            return
        if self._indoor_baseline_c is None:
            self._indoor_baseline_c = obs.indoor_temp_c
            return
        self._indoor_baseline_c += 0.02 * (obs.indoor_temp_c - self._indoor_baseline_c)

    def _feature_vector(self, obs: _ObservationContext) -> np.ndarray:
        vector = np.zeros(ADVANCED_STATE_DIM, dtype=float)
        vector[STATE_INDEX_BASELOAD] = 1.0
        vector[STATE_INDEX_HEAT] = max(0.0, 17.0 - (obs.outdoor_temp_c if obs.outdoor_temp_c is not None else 17.0))

        if self._config.indoor_temp_entity and obs.indoor_temp_c is not None:
            baseline = self._indoor_baseline_c if self._indoor_baseline_c is not None else obs.indoor_temp_c
            vector[STATE_INDEX_INDOOR] = max(baseline - obs.indoor_temp_c, 0.0)

        vector[STATE_INDEX_FOURIER_START:STATE_INDEX_FOURIER_END] = self._fourier_feature_array(obs)
        vector[STATE_INDEX_AR_START:STATE_INDEX_AR_END] = self._ar_feature_array(obs.timestamp)
        return vector

    def _fourier_feature_array(self, obs: _ObservationContext) -> np.ndarray:
        features: list[float] = []
        day_fraction = (obs.hour + (obs.minute / 60.0)) / 24.0
        week_hour = (obs.weekday * 24) + obs.hour + (obs.minute / 60.0)
        week_fraction = week_hour / (7.0 * 24.0)
        for index in range(1, FOURIER_COMPONENT_COUNT + 1):
            day_angle = 2.0 * math.pi * index * day_fraction
            week_angle = 2.0 * math.pi * index * week_fraction
            features.extend(
                [
                    math.sin(day_angle),
                    math.cos(day_angle),
                    math.sin(week_angle),
                    math.cos(week_angle),
                ]
            )
        return np.asarray(features, dtype=float)

    def _ar_feature_array(self, current_timestamp: datetime | None) -> np.ndarray:
        lag1 = self._recent_loads[-1] if len(self._recent_loads) >= 1 else 0.0
        lag2 = self._recent_loads[-2] if len(self._recent_loads) >= 2 else 0.0
        lag_day = self._load_for_day_lag(current_timestamp) if current_timestamp is not None else 0.0
        return np.asarray([lag1, lag2, lag_day], dtype=float)

    def _load_for_day_lag(self, current_timestamp: datetime) -> float:
        if not self._recent_loads or not self._recent_timestamps:
            return 0.0

        target = current_timestamp - AR_DAY_LOOKBACK
        nearest_idx = -1
        nearest_delta: timedelta | None = None
        for idx, sample_ts in enumerate(self._recent_timestamps):
            delta = abs(sample_ts - target)
            if nearest_delta is None or delta < nearest_delta:
                nearest_idx = idx
                nearest_delta = delta

        if nearest_idx >= 0 and nearest_delta is not None and nearest_delta <= AR_LAG_TOLERANCE:
            return self._recent_loads[nearest_idx]

        if len(self._recent_timestamps) >= 2 and len(self._recent_loads) >= 2:
            intervals: list[float] = []
            previous = None
            for sample_ts in self._recent_timestamps:
                if previous is not None:
                    seconds = (sample_ts - previous).total_seconds()
                    if seconds > 0:
                        intervals.append(seconds)
                previous = sample_ts
            if intervals:
                intervals.sort()
                median_seconds = intervals[len(intervals) // 2]
                lag_samples = int(AR_DAY_LOOKBACK.total_seconds() / median_seconds) if median_seconds > 0 else 0
                if lag_samples > 0 and len(self._recent_loads) >= lag_samples:
                    return self._recent_loads[-lag_samples]
        return 0.0

    def _components_from_state(
        self,
        feature_vector: np.ndarray,
        state: np.ndarray,
    ) -> _PredictionComponents:
        baseload_w = float(state[STATE_INDEX_BASELOAD])
        thermal_w = float(feature_vector[STATE_INDEX_HEAT] * state[STATE_INDEX_HEAT])
        thermal_w += float(feature_vector[STATE_INDEX_INDOOR] * state[STATE_INDEX_INDOOR])

        fourier_weights = state[STATE_INDEX_FOURIER_START:STATE_INDEX_FOURIER_END]
        fourier_features = feature_vector[STATE_INDEX_FOURIER_START:STATE_INDEX_FOURIER_END]
        fourier_w = float(fourier_weights @ fourier_features)

        ar_weights = state[STATE_INDEX_AR_START:STATE_INDEX_AR_END]
        ar_features = feature_vector[STATE_INDEX_AR_START:STATE_INDEX_AR_END]
        # AR features are expressed in watts, so the learned AR weights act as direct
        # fractions of previous household load and stay consistent with predicted_w.
        ar_w = float(ar_weights @ ar_features)

        behavioral_w = fourier_w + ar_w
        predicted_w = max(float(state @ feature_vector), 0.0)
        return _PredictionComponents(
            baseload_w=baseload_w,
            thermal_w=thermal_w,
            fourier_w=fourier_w,
            ar_w=ar_w,
            behavioral_w=behavioral_w,
            predicted_w=predicted_w,
        )

    def _clip_state(self) -> None:
        self._state[STATE_INDEX_BASELOAD] = min(
            max(self._state[STATE_INDEX_BASELOAD], BASELOAD_MIN_W),
            BASELOAD_MAX_W,
        )
        self._state[STATE_INDEX_HEAT] = min(max(self._state[STATE_INDEX_HEAT], 0.0), 250.0)
        self._state[STATE_INDEX_INDOOR] = min(max(self._state[STATE_INDEX_INDOOR], 0.0), 400.0)
        self._state[STATE_INDEX_AR_START:STATE_INDEX_AR_END] = np.clip(
            self._state[STATE_INDEX_AR_START:STATE_INDEX_AR_END],
            -0.6,
            0.6,
        )

    def _update_error_metrics(self, actual_w: float, predicted_w: float) -> None:
        abs_error_w = abs(actual_w - predicted_w)
        if self._observation_count <= 0:
            self._mean_abs_error_w = abs_error_w
        else:
            total = self._observation_count + 1
            self._mean_abs_error_w = (
                (self._mean_abs_error_w * self._observation_count) + abs_error_w
            ) / total
        if self._recent_abs_error_w <= 0:
            self._recent_abs_error_w = abs_error_w
        else:
            self._recent_abs_error_w += 0.10 * (abs_error_w - self._recent_abs_error_w)

    def record_shadow_simple_error(self, actual_w: float, simple_predicted_w: float) -> None:
        abs_error_w = abs(actual_w - simple_predicted_w)
        if self._shadow_simple_abs_error_w <= 0:
            self._shadow_simple_abs_error_w = abs_error_w
        else:
            self._shadow_simple_abs_error_w += 0.10 * (abs_error_w - self._shadow_simple_abs_error_w)

    def get_state(self) -> dict[str, Any]:
        return {
            "state_vector": self._state.tolist(),
            "covariance_matrix": self._covariance.tolist(),
            "measurement_variance": self._measurement_variance,
            "mean_abs_error_w": round(self._mean_abs_error_w, 6),
            "recent_abs_error_w": round(self._recent_abs_error_w, 6),
            "shadow_simple_abs_error_w": round(self._shadow_simple_abs_error_w, 6),
            "indoor_baseline_c": self._indoor_baseline_c,
            "observation_count": self._observation_count,
            "visited_profile_hours": [list(item) for item in sorted(self._visited_profile_hours)],
            "recent_loads": [round(value, 3) for value in self._recent_loads],
            "recent_timestamps": [value.isoformat() for value in self._recent_timestamps],
            "recent_residuals": [round(value, 3) for value in self._recent_residuals],
            "last_prediction_components": dict(self._last_prediction_components),
            "last_context": dict(self._last_context),
        }

    def set_state(self, state: dict[str, Any]) -> None:
        raw_state = state.get("state_vector")
        if isinstance(raw_state, list) and len(raw_state) == ADVANCED_STATE_DIM:
            self._state = np.asarray(raw_state, dtype=float)
        else:
            self._state = np.zeros(ADVANCED_STATE_DIM, dtype=float)
            self._state[STATE_INDEX_BASELOAD] = 300.0
            self._state[STATE_INDEX_HEAT] = 18.0
            self._state[STATE_INDEX_INDOOR] = 35.0

        raw_covariance = state.get("covariance_matrix")
        if isinstance(raw_covariance, list) and len(raw_covariance) == ADVANCED_STATE_DIM:
            self._covariance = np.asarray(raw_covariance, dtype=float)
        else:
            self._covariance = np.eye(ADVANCED_STATE_DIM, dtype=float) * 400.0

        self._measurement_variance = float(state.get("measurement_variance", 160.0 ** 2))
        self._mean_abs_error_w = float(state.get("mean_abs_error_w", 0.0))
        self._recent_abs_error_w = float(state.get("recent_abs_error_w", 0.0))
        self._shadow_simple_abs_error_w = float(state.get("shadow_simple_abs_error_w", 0.0))
        self._indoor_baseline_c = _coerce_float(state.get("indoor_baseline_c"))
        self._observation_count = int(state.get("observation_count", 0))
        visited_profile_hours = state.get("visited_profile_hours", [])
        self._visited_profile_hours = {
            (int(item[0]), int(item[1]))
            for item in visited_profile_hours
            if isinstance(item, (list, tuple)) and len(item) == 2
        }
        self._recent_loads = deque(
            (float(value) for value in state.get("recent_loads", [])),
            maxlen=AR_HISTORY_MAXLEN,
        )
        self._recent_timestamps = deque(
            (
                parsed
                for value in state.get("recent_timestamps", [])
                if isinstance(value, str)
                for parsed in [datetime.fromisoformat(value)]
                if parsed.tzinfo is not None
            ),
            maxlen=AR_HISTORY_MAXLEN,
        )
        self._recent_residuals = deque(
            (float(value) for value in state.get("recent_residuals", [])),
            maxlen=AR_HISTORY_MAXLEN,
        )
        self._last_prediction_components = {
            "baseload_w": round(float(state.get("last_prediction_components", {}).get("baseload_w", self._state[STATE_INDEX_BASELOAD])), 1),
            "thermal_w": round(float(state.get("last_prediction_components", {}).get("thermal_w", 0.0)), 1),
            "fourier_w": round(float(state.get("last_prediction_components", {}).get("fourier_w", 0.0)), 1),
            "behavioral_w": round(float(state.get("last_prediction_components", {}).get("behavioral_w", 0.0)), 1),
            "ar_w": round(float(state.get("last_prediction_components", {}).get("ar_w", 0.0)), 1),
            "predicted_w": round(float(state.get("last_prediction_components", {}).get("predicted_w", DEFAULT_WATT)), 1),
        }
        self._last_context = dict(state.get("last_context", {}))
        self._clip_state()

    def reset(self) -> None:
        self.__init__(self._config)


class ConsumptionModel:
    """Facade that feeds both models and selects the active live prediction."""

    def __init__(self, feature_config: FeatureConfig) -> None:
        self.simple = SimpleProfile()
        self.advanced = AdvancedModel(feature_config)
        self.advanced_enabled: bool = False

    def observe(self, reading: PowerReading, context: dict[str, Any]) -> None:
        obs = _extract_context(reading, context)
        simple_predicted_w = self.simple.get_predicted_w(obs.hour, obs.is_weekend)
        self.simple.observe(reading, context)
        self.advanced.observe(reading, context)
        actual_w = _clean_household_load(reading)
        if actual_w is not None:
            self.advanced.record_shadow_simple_error(actual_w, simple_predicted_w)

    def reset_advanced_model(self) -> None:
        self.advanced = AdvancedModel(self.advanced._config)

    def replay_advanced_observations(self, observations: Iterable[dict[str, Any]]) -> int:
        replayed = 0
        for item in observations:
            if not isinstance(item, dict):
                continue
            timestamp = item.get("timestamp")
            if not isinstance(timestamp, datetime) or timestamp.tzinfo is None:
                continue
            try:
                load_w = float(item.get("household_load_w", 0.0))
            except (TypeError, ValueError):
                continue
            reading = PowerReading(
                pv_w=0.0,
                grid_w=0.0,
                battery_w=0.0,
                load_w=load_w,
                ev_w=0.0,
                timestamp=timestamp,
            )
            context = {
                "timestamp": timestamp,
                "hour": timestamp.hour,
                "weekday": timestamp.weekday(),
                "is_weekend": timestamp.weekday() >= 5,
                "outdoor_temp_c": item.get("outdoor_temp_c"),
                "indoor_temp_c": item.get("indoor_temp_c"),
            }
            self.advanced.observe(reading, context)
            replayed += 1
        return replayed

    def load_simple_seed_data(
        self,
        *,
        v1_state: dict[str, Any] | None = None,
        history_readings: Iterable[PowerReading] | None = None,
    ) -> SeedLoadResult:
        """Load manual seed data for SimpleProfile only."""

        return self.simple.load_seed_data(
            v1_state=v1_state,
            history_readings=history_readings,
        )

    def predict_w(self, hour: int, is_weekend: bool, context: dict[str, Any]) -> float:
        if self.advanced_enabled:
            advanced_context = dict(context)
            advanced_context["is_weekend"] = is_weekend
            return self.advanced.get_predicted_w(hour, advanced_context)
        return self.simple.get_predicted_w(hour, is_weekend)

    def build_prediction_snapshot(
        self,
        hour: int,
        is_weekend: bool,
        context: dict[str, Any],
    ) -> ConsumptionPredictionSnapshot:
        """Return one stable prediction object for downstream layers."""

        advanced_context = dict(context)
        advanced_context["is_weekend"] = is_weekend
        simple_snapshot = self.simple.build_snapshot(hour, is_weekend)
        advanced_predicted_w = self.advanced.get_predicted_w(hour, advanced_context)
        advanced_snapshot = self.advanced.build_snapshot()

        if self.advanced_enabled:
            active_model = "advanced"
            readiness = advanced_snapshot.readiness
            predicted_w = advanced_predicted_w
        else:
            active_model = "simple"
            readiness = simple_snapshot.readiness
            predicted_w = simple_snapshot.predicted_w

        return ConsumptionPredictionSnapshot(
            active_model=active_model,
            readiness=readiness,
            predicted_w=round(predicted_w, 1),
            simple_predicted_w=round(simple_snapshot.predicted_w, 1),
            advanced_predicted_w=round(advanced_predicted_w, 1),
            days_collected=simple_snapshot.days_collected,
            advanced_is_mature=advanced_snapshot.is_mature,
            mean_abs_error_w=advanced_snapshot.mean_abs_error_w,
            recent_abs_error_w=advanced_snapshot.recent_abs_error_w,
            shadow_simple_abs_error_w=advanced_snapshot.shadow_simple_abs_error_w,
            prediction_gap_w=round(advanced_predicted_w - simple_snapshot.predicted_w, 1),
            baseload_w=advanced_snapshot.baseload_w,
            thermal_w=advanced_snapshot.thermal_w,
            fourier_w=advanced_snapshot.fourier_w,
            ar_w=advanced_snapshot.ar_w,
            behavioral_w=advanced_snapshot.behavioral_w,
        )

    def get_state(self) -> dict[str, Any]:
        return {
            "simple": self.simple.get_state(),
            "advanced": self.advanced.get_state(),
            "advanced_enabled": self.advanced_enabled,
        }

    def set_state(self, state: dict[str, Any]) -> None:
        if "simple" in state:
            self.simple.set_state(state["simple"])
        if "advanced" in state:
            self.advanced.set_state(state["advanced"])
        self.advanced_enabled = bool(state.get("advanced_enabled", False))
