"""Track-1 forecast correction is intentionally disabled in V2.

Masterplan decision:
- Skip Track-1
- Only use Track-2 (`learning/solar_profile.py`) as the internal solar model

This placeholder is kept only so old imports and migration references do not
break while the active runtime ignores the module completely.
"""
from __future__ import annotations

from typing import Any

from ..core.types import PowerReading
from .base import LearningModule


class ForecastCorrectionModel(LearningModule):
    def observe(self, reading: PowerReading, context: dict[str, Any]) -> None:
        return None

    def get_correction_factors(self) -> dict[str, float]:
        return {
            "geometry_factor": 1.0,
            "temperature_factor": 1.0,
            "total_factor": 1.0,
        }

    def get_state(self) -> dict[str, Any]:
        return {}

    def set_state(self, state: dict[str, Any]) -> None:
        return None
