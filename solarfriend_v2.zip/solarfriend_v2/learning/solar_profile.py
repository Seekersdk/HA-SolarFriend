"""Solar installation profile (Track-2) for installation-specific solar geometry.

Lag: learning
Afhænger af: core/types.py, learning/base.py
Må IKKE importere: homeassistant, planning/, control/, runtime/

Centrale klasser/funktioner:
  ProfileResolution:        resolution contract for fast/medium/fine variants
  ResolutionSnapshot:       stable read-only view of one variant
  SolarProfileSnapshot:     combined view used by later presentation layers
  SolarProfile:             learns clear-sky geometry factors across all variants

Vigtige invarianter / gotchas:
  - All timestamps must already be timezone-aware local datetimes
  - observe() accepts either direct finalized slot context or tick-level accumulation context
  - Learning only uses clear-sky slots with valid production and solar geometry
  - State contains all three variants; no V1 migration is supported for Track-2

Næste lag / senere integration:
  - runtime/checkpoint.py skal gemme hele Track-2 state på solarfriend_v2.solar_profile
  - coordinator/runtime skal feed observe() med solar_elevation_deg, solar_azimuth_deg,
    cloud_coverage_pct og forecast_slot_kwh på hvert tick
  - presentation-laget skal senere folde fast/medium/fine ind som attributter på én sensor
  - planning/ og presentation/ skal senere læse SolarProfileSnapshot i stedet for rå dicts
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
import math
from typing import Any

from ..core.types import PowerReading
from .base import LearningModule

_MIN_ELEVATION_DEG = 5.0
_MIN_VALID_KWH = 0.10
_MAX_CLOUD_PCT = 15.0
_MIN_FACTOR = 0.10
_MAX_FACTOR = 2.00
_ALPHA_CAP = 20
_MIN_SAMPLES_CONFIDENT = 5
_IDW_ELEVATION_WEIGHT = 1.0
_IDW_AZIMUTH_WEIGHT = 0.4
_BLEND_SIGMA = 25.0
_BLEND_FULL_SAMPLES = 12
_MIN_FACTOR_CONFIDENCE = 0.55
_DEFAULT_SLOT_MINUTES = 30
_ACTIVE_RESOLUTION_KEY = "medium"
_RECENCY_DECAY_PER_OBSERVATION = 0.995
_PRIOR_STRENGTH = 2.0
_MIN_VARIANCE = 0.0004


@dataclass(frozen=True)
class ProfileResolution:
    """Bucket resolution and readiness target for one profile variant."""

    key: str
    label: str
    elevation_step_deg: int
    azimuth_step_deg: int
    min_cells_ready: int


@dataclass
class ResponseCell:
    """Learned factor and sample count for one geometry bucket."""

    factor: float = 1.0
    samples: int = 0
    effective_samples: float = 0.0
    avg_abs_error_kwh: float = 0.0
    factor_variance: float = 0.0
    last_seen_observation: int = 0


@dataclass(frozen=True)
class ResolutionSnapshot:
    """Stable diagnostics for one resolution variant."""

    resolution_key: str
    resolution_label: str
    state: str
    populated_cells: int
    confident_cells: int
    clear_sky_observations: int
    estimated_hours_to_ready: float
    response_surface: dict[str, float] = field(default_factory=dict)
    uncertainty_surface: dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class SolarProfileSnapshot:
    """Stable combined view of Track-2 across fast/medium/fine."""

    active_resolution_key: str
    active_state: str
    hours_to_ready: float
    comparison_today: list[dict[str, Any]]
    comparison_tomorrow: list[dict[str, Any]]
    variants: dict[str, ResolutionSnapshot]


DEFAULT_PROFILE_RESOLUTIONS: tuple[ProfileResolution, ...] = (
    ProfileResolution(
        key="fast",
        label="Fast",
        elevation_step_deg=20,
        azimuth_step_deg=60,
        min_cells_ready=6,
    ),
    ProfileResolution(
        key="medium",
        label="Medium",
        elevation_step_deg=10,
        azimuth_step_deg=30,
        min_cells_ready=10,
    ),
    ProfileResolution(
        key="fine",
        label="Fine",
        elevation_step_deg=5,
        azimuth_step_deg=15,
        min_cells_ready=16,
    ),
)


@dataclass
class _SlotAccumulator:
    start: datetime
    forecast_kwh: float = 0.0
    actual_kwh: float = 0.0
    elevation_samples: list[float] = field(default_factory=list)
    azimuth_samples: list[float] = field(default_factory=list)
    cloud_samples: list[float] = field(default_factory=list)

    def add_tick(
        self,
        *,
        pv_w: float,
        dt_seconds: float,
        elevation_deg: float | None,
        azimuth_deg: float | None,
        cloud_coverage_pct: float | None,
    ) -> None:
        if dt_seconds > 0 and pv_w >= 0:
            self.actual_kwh += pv_w * dt_seconds / 3_600_000
        if elevation_deg is not None and azimuth_deg is not None and elevation_deg >= _MIN_ELEVATION_DEG:
            self.elevation_samples.append(elevation_deg)
            self.azimuth_samples.append(azimuth_deg)
        if cloud_coverage_pct is not None:
            self.cloud_samples.append(cloud_coverage_pct)

    def finalize(self) -> dict[str, Any] | None:
        if not self.elevation_samples:
            return None
        average_cloud = None
        if self.cloud_samples:
            average_cloud = sum(self.cloud_samples) / len(self.cloud_samples)
        return {
            "slot_start": self.start,
            "actual_kwh": self.actual_kwh,
            "forecast_kwh": self.forecast_kwh,
            "elevation_deg": sum(self.elevation_samples) / len(self.elevation_samples),
            "azimuth_deg": _circular_mean_azimuth(self.azimuth_samples),
            "cloud_coverage_pct": average_cloud,
        }


class _ResolutionProfile:
    """One fast/medium/fine response surface."""

    def __init__(self, resolution: ProfileResolution) -> None:
        self._resolution = resolution
        self._cells: dict[tuple[int, int], ResponseCell] = {}
        self._clear_sky_observations = 0

    @property
    def resolution_key(self) -> str:
        return self._resolution.key

    @property
    def is_ready(self) -> bool:
        return self._confident_cell_count >= self._resolution.min_cells_ready

    @property
    def clear_sky_observations(self) -> int:
        return self._clear_sky_observations

    @property
    def _confident_cell_count(self) -> int:
        return sum(1 for cell in self._cells.values() if cell.samples >= _MIN_SAMPLES_CONFIDENT)

    def observe_slot(
        self,
        *,
        elevation_deg: float,
        azimuth_deg: float,
        cloud_coverage_pct: float | None,
        actual_kwh: float,
        forecast_kwh: float,
        prior_factor: float | None = None,
    ) -> bool:
        if cloud_coverage_pct is not None and cloud_coverage_pct > _MAX_CLOUD_PCT:
            return False
        if elevation_deg < _MIN_ELEVATION_DEG:
            return False
        if actual_kwh < _MIN_VALID_KWH or forecast_kwh < _MIN_VALID_KWH:
            return False

        elevation_bucket = _elevation_bucket(elevation_deg, self._resolution.elevation_step_deg)
        azimuth_bucket = _azimuth_bucket(azimuth_deg, self._resolution.azimuth_step_deg)
        if elevation_bucket is None or azimuth_bucket is None:
            return False

        observed_factor = max(_MIN_FACTOR, min(_MAX_FACTOR, actual_kwh / forecast_kwh))
        key = (elevation_bucket, azimuth_bucket)
        cell = self._cells.get(key)
        abs_error = abs(actual_kwh - forecast_kwh)
        self._clear_sky_observations += 1
        observation_index = self._clear_sky_observations

        if cell is None:
            initial_factor = observed_factor
            if prior_factor is not None:
                initial_factor = (
                    (prior_factor * _PRIOR_STRENGTH) + observed_factor
                ) / (_PRIOR_STRENGTH + 1.0)
            self._cells[key] = ResponseCell(
                factor=initial_factor,
                samples=1,
                effective_samples=1.0 + (_PRIOR_STRENGTH if prior_factor is not None else 0.0),
                avg_abs_error_kwh=abs_error,
                factor_variance=max(_MIN_VARIANCE, abs(observed_factor - initial_factor) ** 2),
                last_seen_observation=observation_index,
            )
        else:
            age = max(0, observation_index - cell.last_seen_observation)
            if age > 0 and cell.effective_samples > 0:
                cell.effective_samples *= _RECENCY_DECAY_PER_OBSERVATION ** age
                cell.effective_samples = max(1.0, cell.effective_samples)
            alpha = 1.0 / min(cell.effective_samples + 1.0, _ALPHA_CAP)
            previous_factor = cell.factor
            cell.factor = max(
                _MIN_FACTOR,
                min(_MAX_FACTOR, cell.factor + (observed_factor - cell.factor) * alpha),
            )
            cell.avg_abs_error_kwh = (
                (cell.avg_abs_error_kwh * cell.samples) + abs_error
            ) / (cell.samples + 1)
            cell.samples += 1
            cell.effective_samples += 1.0
            innovation = observed_factor - previous_factor
            cell.factor_variance = max(
                _MIN_VARIANCE,
                ((1.0 - alpha) * cell.factor_variance) + (alpha * innovation * innovation),
            )
            cell.last_seen_observation = observation_index
        return True

    def get_factor(self, elevation_deg: float, azimuth_deg: float) -> float | None:
        if elevation_deg < _MIN_ELEVATION_DEG:
            return None
        factor, confidence = self.get_factor_with_confidence(elevation_deg, azimuth_deg)
        if confidence < _MIN_FACTOR_CONFIDENCE:
            return None
        return factor

    def get_direct_cell_factor(
        self,
        elevation_deg: float,
        azimuth_deg: float,
    ) -> float | None:
        elevation_bucket = _elevation_bucket(elevation_deg, self._resolution.elevation_step_deg)
        azimuth_bucket = _azimuth_bucket(azimuth_deg, self._resolution.azimuth_step_deg)
        if elevation_bucket is None or azimuth_bucket is None:
            return None
        direct_cell = self._cells.get((elevation_bucket, azimuth_bucket))
        if direct_cell is None:
            return None
        return direct_cell.factor

    def get_factor_with_confidence(
        self,
        elevation_deg: float,
        azimuth_deg: float,
    ) -> tuple[float | None, float]:
        if not self.is_ready or elevation_deg < _MIN_ELEVATION_DEG:
            return (None, 0.0)
        elevation_bucket = _elevation_bucket(elevation_deg, self._resolution.elevation_step_deg)
        azimuth_bucket = _azimuth_bucket(azimuth_deg, self._resolution.azimuth_step_deg)
        if elevation_bucket is not None and azimuth_bucket is not None:
            direct_cell = self._cells.get((elevation_bucket, azimuth_bucket))
            if direct_cell is not None and direct_cell.samples >= _MIN_SAMPLES_CONFIDENT:
                sample_confidence = min(1.0, direct_cell.samples / _BLEND_FULL_SAMPLES)
                if sample_confidence >= _MIN_FACTOR_CONFIDENCE:
                    return (direct_cell.factor, sample_confidence)
        factor, confidence = _idw_interpolate_with_confidence(
            self._cells,
            elevation_deg,
            azimuth_deg,
            elevation_step_deg=self._resolution.elevation_step_deg,
            azimuth_step_deg=self._resolution.azimuth_step_deg,
            min_samples=_MIN_SAMPLES_CONFIDENT,
        )
        if confidence < _MIN_FACTOR_CONFIDENCE:
            return (None, confidence)
        return (factor, confidence)

    def build_snapshot(self) -> ResolutionSnapshot:
        confident = self._confident_cell_count
        if confident >= self._resolution.min_cells_ready:
            state = "ready"
        elif self._cells:
            state = "learning"
        else:
            state = "inactive"
        return ResolutionSnapshot(
            resolution_key=self._resolution.key,
            resolution_label=self._resolution.label,
            state=state,
            populated_cells=len(self._cells),
            confident_cells=confident,
            clear_sky_observations=self._clear_sky_observations,
            estimated_hours_to_ready=round(self.estimate_hours_to_ready(), 1),
            response_surface={
                f"e{e}|a{a}": round(cell.factor, 4)
                for (e, a), cell in sorted(self._cells.items())
                if cell.samples >= _MIN_SAMPLES_CONFIDENT
            },
            uncertainty_surface={
                f"e{e}|a{a}": round(
                    math.sqrt(max(_MIN_VARIANCE, cell.factor_variance) / max(1.0, cell.effective_samples)),
                    4,
                )
                for (e, a), cell in sorted(self._cells.items())
                if cell.samples >= _MIN_SAMPLES_CONFIDENT
            },
        )

    def estimate_hours_to_ready(self) -> float:
        confident_cells = [cell for cell in self._cells.values() if cell.samples >= _MIN_SAMPLES_CONFIDENT]
        if len(confident_cells) >= self._resolution.min_cells_ready:
            return 0.0

        deficits = sorted(
            _MIN_SAMPLES_CONFIDENT - cell.samples
            for cell in self._cells.values()
            if 0 < cell.samples < _MIN_SAMPLES_CONFIDENT
        )
        confident_count = len(confident_cells)
        missing_slot_samples = 0
        for deficit in deficits:
            if confident_count >= self._resolution.min_cells_ready:
                break
            missing_slot_samples += deficit
            confident_count += 1

        if confident_count < self._resolution.min_cells_ready:
            missing_slot_samples += (
                (self._resolution.min_cells_ready - confident_count) * _MIN_SAMPLES_CONFIDENT
            )
        return missing_slot_samples * 0.5

    def get_state(self) -> dict[str, Any]:
        return {
            "resolution": {
                "key": self._resolution.key,
                "label": self._resolution.label,
                "elevation_step_deg": self._resolution.elevation_step_deg,
                "azimuth_step_deg": self._resolution.azimuth_step_deg,
                "min_cells_ready": self._resolution.min_cells_ready,
            },
            "clear_sky_observations": self._clear_sky_observations,
            "cells": {
                f"{e}|{a}": {
                    "factor": round(cell.factor, 6),
                    "samples": cell.samples,
                    "effective_samples": round(cell.effective_samples, 6),
                    "avg_abs_error_kwh": round(cell.avg_abs_error_kwh, 6),
                    "factor_variance": round(cell.factor_variance, 8),
                    "last_seen_observation": cell.last_seen_observation,
                }
                for (e, a), cell in self._cells.items()
            },
        }

    def set_state(self, state: dict[str, Any]) -> None:
        self._cells = {}
        self._clear_sky_observations = int(state.get("clear_sky_observations", 0))
        for key, raw in (state.get("cells", {}) or {}).items():
            try:
                elevation_bucket, azimuth_bucket = map(int, str(key).split("|"))
                self._cells[(elevation_bucket, azimuth_bucket)] = ResponseCell(
                    factor=float(raw.get("factor", 1.0)),
                    samples=int(raw.get("samples", 0)),
                    effective_samples=float(raw.get("effective_samples", raw.get("samples", 0))),
                    avg_abs_error_kwh=float(raw.get("avg_abs_error_kwh", 0.0)),
                    factor_variance=float(raw.get("factor_variance", _MIN_VARIANCE)),
                    last_seen_observation=int(raw.get("last_seen_observation", 0)),
                )
            except (TypeError, ValueError, AttributeError):
                continue


class SolarProfile(LearningModule):
    """Track-2 installation profile holding fast/medium/fine variants together."""

    def __init__(
        self,
        *,
        resolutions: tuple[ProfileResolution, ...] = DEFAULT_PROFILE_RESOLUTIONS,
        slot_minutes: int = _DEFAULT_SLOT_MINUTES,
        active_resolution_key: str = _ACTIVE_RESOLUTION_KEY,
    ) -> None:
        self._variants = {resolution.key: _ResolutionProfile(resolution) for resolution in resolutions}
        self._slot_minutes = slot_minutes
        self._active_resolution_key = (
            active_resolution_key if active_resolution_key in self._variants else _ACTIVE_RESOLUTION_KEY
        )
        self._active_slot: _SlotAccumulator | None = None
        self._last_tick_timestamp: datetime | None = None
        self._actual_kwh_by_slot: dict[str, float] = {}
        self._last_comparison_series: dict[str, list[dict[str, Any]]] = {"today": [], "tomorrow": []}

    def observe(self, reading: PowerReading, context: dict[str, Any]) -> None:
        direct_slot = self._extract_direct_slot(context, reading)
        if direct_slot is not None:
            self._record_slot(direct_slot)
            self._last_tick_timestamp = reading.timestamp
            return

        timestamp = reading.timestamp
        if not isinstance(timestamp, datetime) or timestamp.tzinfo is None:
            raise ValueError("SolarProfile.observe requires a timezone-aware timestamp")

        slot_start = _current_slot_start(timestamp, self._slot_minutes)
        forecast_slot_kwh = _coerce_float(context.get("forecast_slot_kwh")) or 0.0
        if self._active_slot is not None and self._active_slot.start != slot_start:
            finalized = self._active_slot.finalize()
            if finalized is not None:
                self._record_slot(finalized)
            self._active_slot = None

        if self._active_slot is None:
            self._active_slot = _SlotAccumulator(start=slot_start, forecast_kwh=forecast_slot_kwh)
        else:
            self._active_slot.forecast_kwh = forecast_slot_kwh

        dt_seconds = 0.0
        if self._last_tick_timestamp is not None:
            dt_seconds = max(0.0, (timestamp - self._last_tick_timestamp).total_seconds())
        self._active_slot.add_tick(
            pv_w=float(reading.pv_w),
            dt_seconds=dt_seconds,
            elevation_deg=_coerce_float(context.get("solar_elevation_deg")),
            azimuth_deg=_coerce_float(context.get("solar_azimuth_deg")),
            cloud_coverage_pct=_coerce_float(context.get("cloud_coverage_pct")),
        )
        self._last_tick_timestamp = timestamp
        self._prune_actual_slots(reference=timestamp)

    def get_factor(
        self,
        elevation_deg: float,
        azimuth_deg: float,
        *,
        resolution_key: str | None = None,
    ) -> float | None:
        variant = self._variant_for_resolution(resolution_key)
        return variant.get_factor(elevation_deg, azimuth_deg)

    def get_factor_with_confidence(
        self,
        elevation_deg: float,
        azimuth_deg: float,
        *,
        resolution_key: str | None = None,
    ) -> tuple[float | None, float]:
        variant = self._variant_for_resolution(resolution_key)
        return variant.get_factor_with_confidence(elevation_deg, azimuth_deg)

    def build_comparison_series(
        self,
        points: list[dict[str, Any]],
        *,
        resolution_key: str | None = None,
        now: datetime | None = None,
    ) -> dict[str, list[dict[str, Any]]]:
        variant = self._variant_for_resolution(resolution_key)
        rows: list[dict[str, Any]] = []
        effective_now = now
        if effective_now is None and points:
            effective_now = _coerce_datetime(points[0].get("start"))
        if effective_now is None:
            self._last_comparison_series = {"today": [], "tomorrow": []}
            return self._last_comparison_series

        for point in points:
            start = _coerce_datetime(point.get("start"))
            if start is None:
                continue
            raw_forecast_kwh = _coerce_float(
                point.get("raw_forecast_kwh", point.get("solcast_kwh"))
            ) or 0.0
            empirical_kwh = _coerce_float(
                point.get("empirical_kwh", point.get("empirisk_kwh"))
            )
            elevation_deg = _coerce_float(point.get("elevation_deg", point.get("solar_elevation_deg")))
            azimuth_deg = _coerce_float(point.get("azimuth_deg", point.get("solar_azimuth_deg")))
            actual_kwh = _coerce_float(point.get("actual_kwh", point.get("faktisk_kwh")))
            if actual_kwh is None:
                actual_kwh = self._actual_kwh_by_slot.get(start.isoformat())
            calculated_kwh = None
            factor_confidence = None
            if (
                elevation_deg is not None
                and azimuth_deg is not None
                and raw_forecast_kwh > 0
            ):
                factor, confidence = variant.get_factor_with_confidence(elevation_deg, azimuth_deg)
                factor_confidence = confidence
                if factor is not None:
                    calculated_kwh = round(raw_forecast_kwh * factor, 4)
            rows.append(
                {
                    "period_start": start.isoformat(),
                    "solcast_kwh": round(raw_forecast_kwh, 4) if raw_forecast_kwh > 0 else None,
                    "faktisk_kwh": round(actual_kwh, 4) if actual_kwh is not None else None,
                    "empirisk_kwh": (
                        round(empirical_kwh, 4)
                        if empirical_kwh is not None
                        else round(raw_forecast_kwh, 4) if raw_forecast_kwh > 0 else None
                    ),
                    "beregnet_kwh": calculated_kwh,
                    "beregnet_confidence": (
                        round(factor_confidence, 4) if factor_confidence is not None else None
                    ),
                    "elevation": round(elevation_deg, 1) if elevation_deg is not None else None,
                }
            )

        today = effective_now.date().isoformat()
        tomorrow = (effective_now + timedelta(days=1)).date().isoformat()
        self._last_comparison_series = {
            "today": [row for row in rows if row["period_start"][:10] == today],
            "tomorrow": [row for row in rows if row["period_start"][:10] == tomorrow],
        }
        return self._last_comparison_series

    def get_comparison_series(self) -> dict[str, list[dict[str, Any]]]:
        return {
            "today": list(self._last_comparison_series.get("today", [])),
            "tomorrow": list(self._last_comparison_series.get("tomorrow", [])),
        }

    def build_snapshot(
        self,
        *,
        comparison_points: list[dict[str, Any]] | None = None,
        now: datetime | None = None,
        resolution_key: str | None = None,
    ) -> SolarProfileSnapshot:
        effective_resolution_key = resolution_key or self._best_resolution_key()
        if comparison_points is not None:
            self.build_comparison_series(
                comparison_points,
                resolution_key=effective_resolution_key,
                now=now,
            )
        variants = {
            key: variant.build_snapshot()
            for key, variant in self._variants.items()
        }
        active_variant = variants[effective_resolution_key]
        return SolarProfileSnapshot(
            active_resolution_key=effective_resolution_key,
            active_state=active_variant.state,
            hours_to_ready=active_variant.estimated_hours_to_ready,
            comparison_today=list(self._last_comparison_series.get("today", [])),
            comparison_tomorrow=list(self._last_comparison_series.get("tomorrow", [])),
            variants=variants,
        )

    def get_state(self) -> dict[str, Any]:
        state: dict[str, Any] = {
            "active_resolution_key": self._active_resolution_key,
            "slot_minutes": self._slot_minutes,
            "variants": {
                key: variant.get_state()
                for key, variant in self._variants.items()
            },
            "actual_kwh_by_slot": dict(self._actual_kwh_by_slot),
        }
        if self._active_slot is not None:
            state["active_slot"] = {
                "start": self._active_slot.start.isoformat(),
                "forecast_kwh": round(self._active_slot.forecast_kwh, 6),
                "actual_kwh": round(self._active_slot.actual_kwh, 6),
                "elevation_samples": [round(value, 6) for value in self._active_slot.elevation_samples],
                "azimuth_samples": [round(value, 6) for value in self._active_slot.azimuth_samples],
                "cloud_samples": [round(value, 6) for value in self._active_slot.cloud_samples],
            }
        if self._last_tick_timestamp is not None:
            state["last_tick_timestamp"] = self._last_tick_timestamp.isoformat()
        return state

    def set_state(self, state: dict[str, Any]) -> None:
        self._active_resolution_key = str(
            state.get("active_resolution_key", self._active_resolution_key)
        )
        if self._active_resolution_key not in self._variants:
            self._active_resolution_key = _ACTIVE_RESOLUTION_KEY
        self._slot_minutes = int(state.get("slot_minutes", self._slot_minutes))
        for key, raw_variant in (state.get("variants", {}) or {}).items():
            if key in self._variants and isinstance(raw_variant, dict):
                self._variants[key].set_state(raw_variant)

        self._actual_kwh_by_slot = {}
        for slot_key, value in (state.get("actual_kwh_by_slot", {}) or {}).items():
            slot_dt = _coerce_datetime(slot_key)
            slot_value = _coerce_float(value)
            if slot_dt is None or slot_value is None:
                continue
            self._actual_kwh_by_slot[slot_dt.isoformat()] = slot_value

        active_slot = state.get("active_slot")
        self._active_slot = None
        if isinstance(active_slot, dict):
            slot_start = _coerce_datetime(active_slot.get("start"))
            if slot_start is not None:
                self._active_slot = _SlotAccumulator(
                    start=slot_start,
                    forecast_kwh=float(active_slot.get("forecast_kwh", 0.0)),
                    actual_kwh=float(active_slot.get("actual_kwh", 0.0)),
                    elevation_samples=[
                        float(value) for value in (active_slot.get("elevation_samples", []) or [])
                    ],
                    azimuth_samples=[
                        float(value) for value in (active_slot.get("azimuth_samples", []) or [])
                    ],
                    cloud_samples=[
                        float(value) for value in (active_slot.get("cloud_samples", []) or [])
                    ],
                )

        self._last_tick_timestamp = _coerce_datetime(state.get("last_tick_timestamp"))
        self._last_comparison_series = {"today": [], "tomorrow": []}

    def _extract_direct_slot(
        self,
        context: dict[str, Any],
        reading: PowerReading,
    ) -> dict[str, Any] | None:
        actual_kwh = _coerce_float(context.get("slot_actual_kwh"))
        forecast_kwh = _coerce_float(context.get("slot_forecast_kwh", context.get("forecast_slot_kwh")))
        elevation_deg = _coerce_float(context.get("solar_elevation_deg"))
        azimuth_deg = _coerce_float(context.get("solar_azimuth_deg"))
        if None in (actual_kwh, forecast_kwh, elevation_deg, azimuth_deg):
            return None
        slot_start = _coerce_datetime(context.get("slot_start"))
        if slot_start is None:
            timestamp = reading.timestamp
            if not isinstance(timestamp, datetime) or timestamp.tzinfo is None:
                raise ValueError("SolarProfile.observe requires a timezone-aware timestamp")
            slot_start = _current_slot_start(timestamp, self._slot_minutes)
        return {
            "slot_start": slot_start,
            "actual_kwh": actual_kwh,
            "forecast_kwh": forecast_kwh,
            "elevation_deg": elevation_deg,
            "azimuth_deg": azimuth_deg,
            "cloud_coverage_pct": _coerce_float(context.get("cloud_coverage_pct")),
        }

    def _record_slot(self, slot_data: dict[str, Any]) -> None:
        slot_start = slot_data["slot_start"]
        if not isinstance(slot_start, datetime) or slot_start.tzinfo is None:
            raise ValueError("SolarProfile slot_start must be timezone-aware")
        actual_kwh = float(slot_data["actual_kwh"])
        forecast_kwh = float(slot_data["forecast_kwh"])
        elevation_deg = float(slot_data["elevation_deg"])
        azimuth_deg = float(slot_data["azimuth_deg"])
        cloud_coverage_pct = _coerce_float(slot_data.get("cloud_coverage_pct"))
        accepted_any = False
        prior_factor: float | None = None
        for key in ("fast", "medium", "fine"):
            variant = self._variants[key]
            accepted_any = variant.observe_slot(
                elevation_deg=elevation_deg,
                azimuth_deg=azimuth_deg,
                cloud_coverage_pct=cloud_coverage_pct,
                actual_kwh=actual_kwh,
                forecast_kwh=forecast_kwh,
                prior_factor=prior_factor,
            ) or accepted_any
            prior_factor, _confidence = variant.get_factor_with_confidence(
                elevation_deg,
                azimuth_deg,
            )
            if prior_factor is None:
                prior_factor = variant.get_direct_cell_factor(elevation_deg, azimuth_deg)
        if accepted_any:
            self._actual_kwh_by_slot[slot_start.isoformat()] = round(actual_kwh, 6)
        self._prune_actual_slots(reference=slot_start)

    def _prune_actual_slots(self, *, reference: datetime) -> None:
        cutoff = reference - timedelta(days=3)
        self._actual_kwh_by_slot = {
            slot_key: value
            for slot_key, value in self._actual_kwh_by_slot.items()
            if (slot_dt := _coerce_datetime(slot_key)) is not None and slot_dt >= cutoff
        }

    def _variant_for_resolution(self, resolution_key: str | None) -> _ResolutionProfile:
        key = resolution_key or self._active_resolution_key
        return self._variants[key]

    def _best_resolution_key(self) -> str:
        for key in ("fine", "medium", "fast"):
            variant = self._variants.get(key)
            if variant is not None and variant.is_ready:
                return key
        return self._active_resolution_key


def _coerce_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _coerce_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value if value.tzinfo is not None else None
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError:
            return None
        return parsed if parsed.tzinfo is not None else None
    return None


def _current_slot_start(now: datetime, slot_minutes: int) -> datetime:
    aligned_minute = (now.minute // slot_minutes) * slot_minutes
    return now.replace(minute=aligned_minute, second=0, microsecond=0)


def _circular_mean_azimuth(angles: list[float]) -> float:
    if not angles:
        return 0.0
    sin_sum = sum(math.sin(math.radians(angle)) for angle in angles)
    cos_sum = sum(math.cos(math.radians(angle)) for angle in angles)
    return math.degrees(math.atan2(sin_sum, cos_sum)) % 360


def _elevation_bucket(value: float, step_deg: int) -> int | None:
    if value < -10 or value > 90:
        return None
    return int((max(-10.0, min(90.0, value)) // step_deg) * step_deg)


def _azimuth_bucket(value: float, step_deg: int) -> int | None:
    return int((value % 360.0 // step_deg) * step_deg)


def _idw_interpolate_with_confidence(
    cells: dict[tuple[int, int], ResponseCell],
    elevation_deg: float,
    azimuth_deg: float,
    *,
    elevation_step_deg: int,
    azimuth_step_deg: int,
    min_samples: int,
) -> tuple[float, float]:
    usable = {key: value for key, value in cells.items() if value.samples >= min_samples}
    if not usable:
        return (1.0, 0.0)

    total_weight = 0.0
    weighted_factor = 0.0
    nearest_dist_sq: float | None = None
    nearest_samples = 0
    nearest_variance = _MIN_VARIANCE

    for (elevation_bucket, azimuth_bucket), cell in usable.items():
        de = elevation_deg - (elevation_bucket + elevation_step_deg / 2.0)
        da = azimuth_deg - (azimuth_bucket + azimuth_step_deg / 2.0)
        da = (da + 180.0) % 360.0 - 180.0
        dist_sq = (
            (de * _IDW_ELEVATION_WEIGHT) ** 2
            + (da * _IDW_AZIMUTH_WEIGHT) ** 2
        )
        if nearest_dist_sq is None or dist_sq < nearest_dist_sq:
            nearest_dist_sq = dist_sq
            nearest_samples = cell.samples
            nearest_variance = cell.factor_variance
        if dist_sq < 0.01:
            sample_confidence = min(1.0, cell.effective_samples / _BLEND_FULL_SAMPLES)
            variance_confidence = 1.0 / (1.0 + (math.sqrt(max(_MIN_VARIANCE, cell.factor_variance)) / 0.15))
            return (cell.factor, sample_confidence * variance_confidence)
        weight = 1.0 / dist_sq
        weighted_factor += cell.factor * weight
        total_weight += weight

    raw_factor = weighted_factor / total_weight if total_weight > 0 else 1.0
    if nearest_dist_sq is None:
        return (1.0, 0.0)
    distance_confidence = math.exp(-nearest_dist_sq / (_BLEND_SIGMA ** 2))
    sample_confidence = min(1.0, nearest_samples / _BLEND_FULL_SAMPLES)
    variance_confidence = 1.0 / (1.0 + (math.sqrt(max(_MIN_VARIANCE, nearest_variance)) / 0.15))
    confidence = max(0.0, min(1.0, distance_confidence * sample_confidence * variance_confidence))
    return (raw_factor, confidence)
