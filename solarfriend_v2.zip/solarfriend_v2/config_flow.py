"""Config flow for SolarFriend V2."""
from __future__ import annotations

from typing import Any

import voluptuous as vol

from homeassistant.config_entries import ConfigFlow, ConfigFlowResult, OptionsFlow
from homeassistant.const import CONF_NAME
from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er
import homeassistant.helpers.config_validation as cv
from homeassistant.helpers.selector import (
    EntitySelector,
    EntitySelectorConfig,
    NumberSelector,
    NumberSelectorConfig,
    NumberSelectorMode,
    SelectSelector,
    SelectSelectorConfig,
    SelectSelectorMode,
)

from .const import DOMAIN

CONF_PV_POWER_SENSOR = "pv_power_sensor"
CONF_PV2_POWER_SENSOR = "pv2_power_sensor"
CONF_GRID_POWER_SENSOR = "grid_power_sensor"
CONF_BATTERY_SOC_SENSOR = "battery_soc_sensor"
CONF_BATTERY_POWER_SENSOR = "battery_power_sensor"
CONF_LOAD_POWER_SENSOR = "load_power_sensor"
CONF_LOAD_IS_TOTAL = "load_sensor_is_total_load"
CONF_FORECAST_SENSOR = "forecast_sensor"
CONF_FORECAST_TYPE = "forecast_type"
CONF_BUY_PRICE_SENSOR = "buy_price_sensor"
CONF_SELL_PRICE_SENSOR = "sell_price_sensor"
CONF_INVERTER_TYPE = "inverter_type"
CONF_BATTERY_CAPACITY = "battery_capacity_kwh"
CONF_BATTERY_MIN_SOC = "battery_min_soc"
CONF_BATTERY_MAX_SOC = "battery_max_soc"
CONF_CHARGE_RATE_KW = "charge_rate_kw"
CONF_MIN_CHARGE_SAVING = "min_charge_saving"
CONF_CHEAP_GRID_THRESHOLD = "cheap_grid_threshold"
CONF_BATTERY_COST_PER_KWH = "battery_cost_per_kwh"
CONF_OUTDOOR_TEMP_ENTITY = "outdoor_temp_entity"
CONF_INDOOR_TEMP_ENTITY = "indoor_temp_entity"

CONF_DEYE_GRID_CHARGE_SWITCH = "deye_grid_charge_switch"
CONF_DEYE_TIME_OF_USE_SWITCH = "deye_time_of_use_switch"
CONF_DEYE_TIME_POINT_1_ENABLE = "deye_time_point_1_enable"
CONF_DEYE_TIME_POINT_1_START = "deye_time_point_1_start"
CONF_DEYE_TIME_POINT_1_CAPACITY = "deye_time_point_1_capacity"
CONF_DEYE_GRID_CHARGE_CURRENT = "deye_grid_charge_current"
CONF_DEYE_MAX_BATTERY_DISCHARGE_CURRENT = "deye_max_battery_discharge_current"
CONF_DEYE_DEFAULT_BATTERY_DISCHARGE_CURRENT = "deye_default_battery_discharge_current"
CONF_DEYE_ENERGY_PRIORITY = "deye_energy_priority"
CONF_DEYE_LIMIT_CONTROL_MODE = "deye_limit_control_mode"
CONF_SOLAR_SELL_ENTITY = "solar_sell_entity"

CONF_EV_CHARGING_ENABLED = "ev_charging_enabled"
CONF_EV_CHARGER_TYPE = "ev_charger_type"
CONF_EV_CHARGER_STATUS_ENTITY = "ev_charger_status_entity"
CONF_EV_CHARGER_POWER_ENTITY = "ev_charger_power_entity"
CONF_EV_CHARGER_ID = "ev_charger_id"
CONF_EV_CHARGER_PAUSE_SWITCH = "ev_charger_pause_switch"
CONF_EV_MAX_CHARGE_KW = "ev_max_charge_kw"
CONF_VEHICLE_TYPE = "vehicle_type"
CONF_VEHICLE_SOC_ENTITY = "vehicle_soc_entity"
CONF_VEHICLE_PLUGGED_IN_ENTITY = "vehicle_plugged_in_entity"
CONF_VEHICLE_TARGET_SOC_ENTITY = "vehicle_target_soc_entity"
CONF_VEHICLE_RANGE_ENTITY = "vehicle_range_entity"
CONF_VEHICLE_BATTERY_CAPACITY = "vehicle_battery_capacity_kwh"

DEFAULT_NAME = "SolarFriend V2"
FORECAST_DEFAULT = "sensor.energy_production_today"
SOLCAST_SENSOR = "sensor.solcast_pv_forecast_forecast_today"
DEFAULT_CHEAP_GRID_THRESHOLD = 0.10
DEFAULT_EV_MAX_CHARGE_KW = 11.0

_KLATREMIS_SENSOR_SUFFIXES: dict[str, list[str]] = {
    CONF_PV_POWER_SENSOR: ["_pv1_power"],
    CONF_PV2_POWER_SENSOR: ["_pv2_power"],
    CONF_GRID_POWER_SENSOR: ["_total_grid_power"],
    CONF_BATTERY_SOC_SENSOR: ["_battery_capacity"],
    CONF_BATTERY_POWER_SENSOR: ["_battery_output_power"],
    CONF_LOAD_POWER_SENSOR: ["_load_totalpower"],
}

_KLATREMIS_CONTROL_SUFFIXES: dict[str, tuple[str, list[str]]] = {
    CONF_DEYE_GRID_CHARGE_SWITCH: ("switch", ["_grid_charge"]),
    CONF_DEYE_TIME_OF_USE_SWITCH: ("switch", ["_time_of_use"]),
    CONF_DEYE_TIME_POINT_1_ENABLE: ("switch", ["_time_point_1_charge_enable", "_time_point_1-6_charge_enable"]),
    CONF_DEYE_TIME_POINT_1_START: ("number", ["_time_point_1_start", "_time_point_1-6_start"]),
    CONF_DEYE_TIME_POINT_1_CAPACITY: ("number", ["_time_point_1_capacity", "_time_point_1-6_capacity"]),
    CONF_DEYE_GRID_CHARGE_CURRENT: ("number", ["_maximum_battery_grid_charge_current", "_grid_charge_current"]),
    CONF_DEYE_MAX_BATTERY_DISCHARGE_CURRENT: ("number", ["_maximum_battery_discharge_current"]),
    CONF_DEYE_ENERGY_PRIORITY: ("select", ["_energy_priority"]),
    CONF_DEYE_LIMIT_CONTROL_MODE: ("select", ["_limit_control_mode"]),
}

_SENSOR_PATTERNS: dict[str, tuple[str, list[str]]] = {
    CONF_PV_POWER_SENSOR: ("power", ["pv", "solar", "panel", "photovoltaic"]),
    CONF_GRID_POWER_SENSOR: ("power", ["grid", "net", "mains"]),
    CONF_BATTERY_POWER_SENSOR: ("power", ["battery", "bat", "batt"]),
    CONF_BATTERY_SOC_SENSOR: ("battery", ["soc", "battery", "bat", "charge", "capacity"]),
    CONF_LOAD_POWER_SENSOR: ("power", ["load", "consumption", "forbrug", "house", "home", "totalpower"]),
}


def _match_by_pattern(
    hass: HomeAssistant,
    candidates: list[er.RegistryEntry],
    current: dict[str, str | None],
) -> dict[str, str | None]:
    result = dict(current)
    for conf_key, (expected_dc, keywords) in _SENSOR_PATTERNS.items():
        if result.get(conf_key):
            continue
        for entry in candidates:
            state = hass.states.get(entry.entity_id)
            if state is None:
                continue
            dc = state.attributes.get("device_class") or entry.device_class or entry.original_device_class or ""
            if dc != expected_dc:
                continue
            haystack = (entry.entity_id + (entry.name or "") + (entry.original_name or "")).lower()
            if any(keyword in haystack for keyword in keywords):
                result[conf_key] = entry.entity_id
                break
    return result


def _guess_deye_sensors(hass: HomeAssistant) -> dict[str, str | None]:
    ent_reg = er.async_get(hass)
    dev_reg = dr.async_get(hass)
    all_sensors = [entry for entry in ent_reg.entities.values() if entry.domain == "sensor"]
    result: dict[str, str | None] = {key: None for key in _KLATREMIS_SENSOR_SUFFIXES}

    for conf_key, suffixes in _KLATREMIS_SENSOR_SUFFIXES.items():
        for suffix in suffixes:
            match = next((entry.entity_id for entry in all_sensors if entry.entity_id.endswith(suffix)), None)
            if match:
                result[conf_key] = match
                break

    esphome_device_ids: set[str] = {
        device.id
        for device in dev_reg.devices.values()
        if any(
            keyword in (part or "").lower()
            for part in (device.manufacturer, device.model, device.name, str(device.entry_type))
            for keyword in ("deye", "esphome", "sun12k", "klatremis")
        )
    }
    device_candidates = [entry for entry in all_sensors if entry.device_id in esphome_device_ids]
    result = _match_by_pattern(hass, device_candidates, result)

    broad_candidates = [
        entry
        for entry in all_sensors
        if any(keyword in entry.entity_id for keyword in ("deye", "sun12k", "esphome", "klatremis"))
    ]
    return _match_by_pattern(hass, broad_candidates, result)


def _get_deye_device_sensors(hass: HomeAssistant) -> dict[str, str]:
    ent_reg = er.async_get(hass)
    dev_reg = dr.async_get(hass)
    esphome_device_ids: set[str] = {
        device.id
        for device in dev_reg.devices.values()
        if any(
            keyword in (part or "").lower()
            for part in (device.manufacturer, device.model, device.name, str(device.entry_type))
            for keyword in ("deye", "esphome", "sun12k", "klatremis")
        )
    }
    result: dict[str, str] = {}
    for entry in ent_reg.entities.values():
        if entry.domain != "sensor":
            continue
        in_device = entry.device_id in esphome_device_ids
        in_keyword = any(keyword in entry.entity_id for keyword in ("deye", "sun12k", "esphome", "klatremis"))
        if not (in_device or in_keyword):
            continue
        state = hass.states.get(entry.entity_id)
        name = (
            (state.attributes.get("friendly_name") if state else None)
            or entry.name
            or entry.original_name
            or entry.entity_id
        )
        result[entry.entity_id] = f"{name} ({entry.entity_id})"
    return dict(sorted(result.items(), key=lambda item: item[1]))


def _get_deye_device_entities(hass: HomeAssistant, *domains: str) -> dict[str, str]:
    ent_reg = er.async_get(hass)
    dev_reg = dr.async_get(hass)
    esphome_device_ids: set[str] = {
        device.id
        for device in dev_reg.devices.values()
        if any(
            keyword in (part or "").lower()
            for part in (device.manufacturer, device.model, device.name, str(device.entry_type))
            for keyword in ("deye", "esphome", "sun12k", "klatremis")
        )
    }
    result: dict[str, str] = {}
    for entry in ent_reg.entities.values():
        if entry.domain not in domains:
            continue
        in_device = entry.device_id in esphome_device_ids
        in_keyword = any(keyword in entry.entity_id for keyword in ("deye", "sun12k", "esphome", "klatremis"))
        if not (in_device or in_keyword):
            continue
        state = hass.states.get(entry.entity_id)
        name = (
            (state.attributes.get("friendly_name") if state else None)
            or entry.name
            or entry.original_name
            or entry.entity_id
        )
        result[entry.entity_id] = f"{name} ({entry.entity_id})"
    return dict(sorted(result.items(), key=lambda item: item[1]))


def _get_entities_by_domain(hass: HomeAssistant, *domains: str) -> dict[str, str]:
    registry = er.async_get(hass)
    result: dict[str, str] = {}
    for entry in registry.entities.values():
        if entry.domain not in domains:
            continue
        state = hass.states.get(entry.entity_id)
        name = (
            (state.attributes.get("friendly_name") if state else None)
            or entry.name
            or entry.original_name
            or entry.entity_id
        )
        result[entry.entity_id] = f"{name} ({entry.entity_id})"
    for state in hass.states.async_all():
        domain = state.entity_id.split(".")[0]
        if domain not in domains or state.entity_id in result:
            continue
        name = state.attributes.get("friendly_name") or state.entity_id
        result[state.entity_id] = f"{name} ({state.entity_id})"
    return dict(sorted(result.items(), key=lambda item: item[1]))


def _get_sensors_by_device_class(hass: HomeAssistant, *device_classes: str) -> dict[str, str]:
    power_units = {"W", "kW", "VA", "kVA"}
    battery_units = {"%"}
    registry = er.async_get(hass)
    result: dict[str, str] = {}
    for entry in registry.entities.values():
        if entry.domain != "sensor":
            continue
        state = hass.states.get(entry.entity_id)
        if state is None:
            continue
        dc = state.attributes.get("device_class") or entry.device_class or entry.original_device_class
        unit = state.attributes.get("unit_of_measurement", "")
        matched = dc in device_classes
        if not matched:
            if "power" in device_classes and unit in power_units:
                matched = True
            elif "battery" in device_classes and unit in battery_units:
                matched = True
        if matched:
            name = state.attributes.get("friendly_name") or entry.entity_id
            result[entry.entity_id] = f"{name} ({entry.entity_id})"
    return dict(sorted(result.items(), key=lambda item: item[1]))


def _get_spot_price_sensors(hass: HomeAssistant) -> dict[str, str]:
    registry = er.async_get(hass)
    result: dict[str, str] = {}
    for entry in registry.entities.values():
        if entry.domain != "sensor":
            continue
        state = hass.states.get(entry.entity_id)
        if state is None:
            continue
        dc = state.attributes.get("device_class") or entry.device_class or entry.original_device_class
        if dc != "monetary":
            continue
        unit = str(state.attributes.get("unit_of_measurement", ""))
        if not unit.endswith("/kWh"):
            continue
        if "raw_today" not in state.attributes:
            continue
        attribution = str(state.attributes.get("attribution", "")).lower()
        haystack = " ".join(
            part
            for part in (
                entry.entity_id,
                state.attributes.get("friendly_name"),
                entry.name,
                entry.original_name,
            )
            if part
        ).lower()
        if "energi data service" not in attribution and "energi_data_service" not in haystack:
            continue
        name = state.attributes.get("friendly_name") or entry.entity_id
        result[entry.entity_id] = f"{name} ({entry.entity_id})"
    return result


def _get_forecast_sensors(hass: HomeAssistant) -> dict[str, str]:
    registry = er.async_get(hass)
    result: dict[str, str] = {}
    for entry in registry.entities.values():
        if entry.domain != "sensor":
            continue
        state = hass.states.get(entry.entity_id)
        if state is None:
            continue
        dc = state.attributes.get("device_class") or entry.device_class or entry.original_device_class
        name = state.attributes.get("friendly_name") or entry.entity_id
        if dc == "energy" or "production" in entry.entity_id or "production" in name.lower():
            result[entry.entity_id] = f"{name} ({entry.entity_id})"
    return dict(sorted(result.items(), key=lambda item: item[1]))


def _float_state(hass: HomeAssistant, entity_id: str | None, default: float) -> float:
    """Read a numeric entity state safely."""
    if not entity_id:
        return default
    state = hass.states.get(entity_id)
    if state is None:
        return default
    try:
        return float(state.state)
    except (TypeError, ValueError):
        return default


def _guess_deye_control_entities(hass: HomeAssistant) -> dict[str, str | None]:
    registry = er.async_get(hass)
    by_domain: dict[str, list[str]] = {}
    for entry in registry.entities.values():
        by_domain.setdefault(entry.domain, []).append(entry.entity_id)

    result: dict[str, str | None] = {}
    for conf_key, (domain, suffixes) in _KLATREMIS_CONTROL_SUFFIXES.items():
        candidates = by_domain.get(domain, [])
        result[conf_key] = next(
            (entity_id for suffix in suffixes for entity_id in candidates if entity_id.endswith(suffix)),
            None,
        )
    return result


_EASEE_CHARGER_STATES = {"disconnected", "awaiting_start", "charging", "ready_to_charge", "completed", "error"}


async def _detect_easee_entities(hass: HomeAssistant) -> tuple[str | None, str | None, str | None]:
    registry = er.async_get(hass)
    dev_reg = dr.async_get(hass)
    status_entity: str | None = None
    power_entity: str | None = None
    charger_id: str | None = None

    easee_device_ids: set[str] = {
        device.id
        for device in dev_reg.devices.values()
        if (device.manufacturer or "").lower() == "easee"
        or "easee" in (device.model or "").lower()
        or "easee" in (device.name or "").lower()
    }

    for entry in registry.entities.values():
        if entry.domain != "sensor":
            continue
        if not (entry.device_id in easee_device_ids or "easee" in entry.entity_id):
            continue
        state = hass.states.get(entry.entity_id)
        if state is None:
            continue
        if status_entity is None and state.state in _EASEE_CHARGER_STATES:
            status_entity = entry.entity_id
            charger_id = entry.device_id
        if power_entity is None:
            unit = state.attributes.get("unit_of_measurement", "")
            if unit in {"W", "kW"} and entry.entity_id.endswith("_power"):
                power_entity = entry.entity_id
    return status_entity, power_entity, charger_id


async def _detect_kia_entities(hass: HomeAssistant) -> tuple[str | None, str | None, str | None, str | None]:
    registry = er.async_get(hass)
    soc_entity: str | None = None
    plugged_in_entity: str | None = None
    target_soc_entity: str | None = None
    range_entity: str | None = None

    for entry in registry.entities.values():
        eid = entry.entity_id.lower()
        if soc_entity is None and entry.domain == "sensor" and ("ev_battery_level" in eid or "battery_level" in eid):
            if not any(skip in eid for skip in ("12v", "twelve")):
                soc_entity = entry.entity_id
        if plugged_in_entity is None and entry.domain == "binary_sensor":
            if any(brand in eid for brand in ("kia", "hyundai", "niro")) and any(
                keyword in eid for keyword in ("plugged_in", "ev_battery_plug", "charging", "plug")
            ):
                plugged_in_entity = entry.entity_id
        if target_soc_entity is None and entry.domain in {"sensor", "number"}:
            if any(brand in eid for brand in ("kia", "hyundai", "niro")) and any(
                keyword in eid for keyword in ("charge_limit", "target_soc", "charging_limit")
            ):
                target_soc_entity = entry.entity_id
        if range_entity is None and entry.domain == "sensor":
            if any(keyword in eid for keyword in ("driving_range", "ev_driving_range")):
                range_entity = entry.entity_id
    return soc_entity, plugged_in_entity, target_soc_entity, range_entity


class SolarFriendV2ConfigFlow(ConfigFlow, domain=DOMAIN):
    """Handle the SolarFriend V2 config flow."""

    VERSION = 1

    @staticmethod
    def async_get_options_flow(config_entry):
        return SolarFriendV2OptionsFlow(config_entry)

    def __init__(self) -> None:
        self._data: dict[str, Any] = {}

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if self._async_current_entries():
            return self.async_abort(reason="single_instance_allowed")
        if user_input is not None:
            self._data[CONF_EV_CHARGING_ENABLED] = bool(user_input.get(CONF_EV_CHARGING_ENABLED, False))
            await self.async_set_unique_id(DOMAIN)
            self._abort_if_unique_id_configured()
            return await self.async_step_name()
        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema({vol.Optional(CONF_EV_CHARGING_ENABLED, default=False): bool}),
        )

    async def async_step_name(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if user_input is not None:
            self._data[CONF_NAME] = user_input[CONF_NAME]
            return await self.async_step_inverter_type()
        return self.async_show_form(
            step_id="name",
            data_schema=vol.Schema({vol.Required(CONF_NAME, default=DEFAULT_NAME): cv.string}),
        )

    async def async_step_inverter_type(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if user_input is not None:
            self._data[CONF_INVERTER_TYPE] = user_input[CONF_INVERTER_TYPE]
            return await self.async_step_power_sensors()
        return self.async_show_form(
            step_id="inverter_type",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_INVERTER_TYPE, default="deye_klatremis"): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": "deye_klatremis", "label": "Deye via ESPHome (klatremis)"},
                                {"value": "deye", "label": "Deye manual mapping"},
                                {"value": "none", "label": "No controllable inverter yet"},
                            ],
                            mode=SelectSelectorMode.LIST,
                        )
                    )
                }
            ),
        )

    async def async_step_power_sensors(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if self._data.get(CONF_INVERTER_TYPE) == "deye_klatremis":
            sensor_choices = await self.hass.async_add_executor_job(_get_deye_device_sensors, self.hass)
            guesses = _guess_deye_sensors(self.hass)
        else:
            sensor_choices = await self.hass.async_add_executor_job(_get_sensors_by_device_class, self.hass, "power", "battery")
            guesses = {}

        if not sensor_choices:
            return self.async_show_form(
                step_id="power_sensors",
                data_schema=vol.Schema({}),
                errors={"base": "no_matching_entities"},
            )

        if user_input is not None:
            self._data.update(user_input)
            return await self.async_step_battery_economics()

        def _req(key: str) -> vol.Required:
            guess = guesses.get(key)
            return vol.Required(key, default=guess) if guess in sensor_choices else vol.Required(key)

        none_plus = {"": "None", **sensor_choices}
        schema = vol.Schema(
            {
                _req(CONF_PV_POWER_SENSOR): vol.In(sensor_choices),
                vol.Optional(
                    CONF_PV2_POWER_SENSOR,
                    default=guesses.get(CONF_PV2_POWER_SENSOR) if guesses.get(CONF_PV2_POWER_SENSOR) in sensor_choices else "",
                ): vol.In(none_plus),
                _req(CONF_GRID_POWER_SENSOR): vol.In(sensor_choices),
                _req(CONF_BATTERY_SOC_SENSOR): vol.In(sensor_choices),
                _req(CONF_BATTERY_POWER_SENSOR): vol.In(sensor_choices),
                _req(CONF_LOAD_POWER_SENSOR): vol.In(sensor_choices),
                vol.Optional(CONF_LOAD_IS_TOTAL, default=True): bool,
            }
        )
        return self.async_show_form(step_id="power_sensors", data_schema=schema)

    async def async_step_battery_economics(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            if user_input[CONF_BATTERY_MIN_SOC] >= user_input[CONF_BATTERY_MAX_SOC]:
                errors[CONF_BATTERY_MIN_SOC] = "min_soc_above_max"
            else:
                self._data.update(user_input)
                return await self.async_step_price_sensor()
        schema = vol.Schema(
            {
                vol.Required(CONF_BATTERY_CAPACITY, default=10.0): NumberSelector(
                    NumberSelectorConfig(min=1, max=100, step=0.5, mode=NumberSelectorMode.BOX)
                ),
                vol.Required(CONF_BATTERY_MIN_SOC, default=10): NumberSelector(
                    NumberSelectorConfig(min=0, max=50, step=5, mode=NumberSelectorMode.SLIDER)
                ),
                vol.Required(CONF_BATTERY_MAX_SOC, default=90): NumberSelector(
                    NumberSelectorConfig(min=50, max=100, step=5, mode=NumberSelectorMode.SLIDER)
                ),
                vol.Required(CONF_CHARGE_RATE_KW, default=6.0): NumberSelector(
                    NumberSelectorConfig(min=0.5, max=20.0, step=0.5, mode=NumberSelectorMode.BOX)
                ),
                vol.Required(CONF_BATTERY_COST_PER_KWH, default=0.30): NumberSelector(
                    NumberSelectorConfig(min=0.0, max=2.0, step=0.05, mode=NumberSelectorMode.BOX, unit_of_measurement="kr/kWh")
                ),
                vol.Required(CONF_MIN_CHARGE_SAVING, default=0.20): NumberSelector(
                    NumberSelectorConfig(min=0.05, max=1.0, step=0.05, mode=NumberSelectorMode.SLIDER, unit_of_measurement="kr/kWh")
                ),
                vol.Required(CONF_CHEAP_GRID_THRESHOLD, default=DEFAULT_CHEAP_GRID_THRESHOLD): NumberSelector(
                    NumberSelectorConfig(min=0.0, max=1.0, step=0.05, mode=NumberSelectorMode.SLIDER, unit_of_measurement="kr/kWh")
                ),
            }
        )
        return self.async_show_form(step_id="battery_economics", data_schema=schema, errors=errors)

    async def async_step_price_sensor(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        price_sensors = await self.hass.async_add_executor_job(_get_spot_price_sensors, self.hass)
        if not price_sensors:
            price_sensors = await self.hass.async_add_executor_job(_get_sensors_by_device_class, self.hass, "monetary")

        if not price_sensors:
            return self.async_show_form(
                step_id="price_sensor",
                data_schema=vol.Schema({}),
                errors={"base": "no_matching_entities"},
            )

        if user_input is not None:
            self._data.update(user_input)
            return await self.async_step_forecast_type()

        buy_default = next(iter(price_sensors), None)
        sell_default = buy_default
        schema = vol.Schema(
            {
                vol.Required(CONF_BUY_PRICE_SENSOR, default=buy_default): vol.In(price_sensors),
                vol.Required(CONF_SELL_PRICE_SENSOR, default=sell_default): vol.In(price_sensors),
            }
        )
        return self.async_show_form(step_id="price_sensor", data_schema=schema)

    async def async_step_forecast_type(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if user_input is not None:
            self._data[CONF_FORECAST_TYPE] = user_input[CONF_FORECAST_TYPE]
            if user_input[CONF_FORECAST_TYPE] == "solcast":
                self._data[CONF_FORECAST_SENSOR] = SOLCAST_SENSOR
                return await self.async_step_environment()
            return await self.async_step_forecast_sensor()

        solcast_present = self.hass.states.get(SOLCAST_SENSOR) is not None
        default_type = "solcast" if solcast_present else "forecast_solar"
        schema = vol.Schema(
            {
                vol.Required(CONF_FORECAST_TYPE, default=default_type): SelectSelector(
                    SelectSelectorConfig(
                        options=[
                            {"value": "solcast", "label": "Solcast PV Forecast"},
                            {"value": "forecast_solar", "label": "Forecast.Solar / generic sensor"},
                        ],
                        mode=SelectSelectorMode.LIST,
                    )
                )
            }
        )
        return self.async_show_form(step_id="forecast_type", data_schema=schema)

    async def async_step_forecast_sensor(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        forecast_sensors = await self.hass.async_add_executor_job(_get_forecast_sensors, self.hass)
        if not forecast_sensors:
            return self.async_show_form(
                step_id="forecast_sensor",
                data_schema=vol.Schema({}),
                errors={"base": "no_matching_entities"},
            )
        default_forecast = FORECAST_DEFAULT if FORECAST_DEFAULT in forecast_sensors else next(iter(forecast_sensors), None)
        if user_input is not None:
            self._data.update(user_input)
            return await self.async_step_environment()
        schema = vol.Schema({vol.Required(CONF_FORECAST_SENSOR, default=default_forecast): vol.In(forecast_sensors)})
        return self.async_show_form(step_id="forecast_sensor", data_schema=schema)

    async def async_step_environment(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        sensors = await self.hass.async_add_executor_job(_get_entities_by_domain, self.hass, "sensor")
        none_plus = {"": "None", **sensors}
        if user_input is not None:
            self._data.update({key: value for key, value in user_input.items() if value})
            if self._data.get(CONF_INVERTER_TYPE) in {"deye", "deye_klatremis"}:
                return await self.async_step_deye_control()
            return await self.async_step_ev_options()
        schema = vol.Schema(
            {
                vol.Optional(CONF_OUTDOOR_TEMP_ENTITY, default=""): vol.In(none_plus),
                vol.Optional(CONF_INDOOR_TEMP_ENTITY, default=""): vol.In(none_plus),
            }
        )
        return self.async_show_form(step_id="environment", data_schema=schema)

    async def async_step_deye_control(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if self._data.get(CONF_INVERTER_TYPE) == "deye_klatremis":
            deye_entities = await self.hass.async_add_executor_job(_get_deye_device_entities, self.hass, "switch", "number", "select")
            switch_entities = {key: value for key, value in deye_entities.items() if key.startswith("switch.")}
            number_entities = {key: value for key, value in deye_entities.items() if key.startswith("number.")}
            select_entities = {key: value for key, value in deye_entities.items() if key.startswith("select.")}
        else:
            switch_entities = await self.hass.async_add_executor_job(_get_entities_by_domain, self.hass, "switch")
            number_entities = await self.hass.async_add_executor_job(_get_entities_by_domain, self.hass, "number")
            select_entities = await self.hass.async_add_executor_job(_get_entities_by_domain, self.hass, "select")
        guesses = _guess_deye_control_entities(self.hass)
        all_switch_entities = switch_entities or await self.hass.async_add_executor_job(_get_entities_by_domain, self.hass, "switch")

        if user_input is not None:
            self._data.update({key: value for key, value in user_input.items() if value != ""})
            return await self.async_step_ev_options()

        priority_entities = {eid: label for eid, label in select_entities.items() if eid.endswith("_energy_priority")} or select_entities
        limit_entities = {eid: label for eid, label in select_entities.items() if eid.endswith("_limit_control_mode")} or select_entities

        def _switch_key(conf_key: str) -> vol.Optional:
            guess = guesses.get(conf_key)
            return vol.Optional(conf_key, default=guess) if guess in switch_entities else vol.Optional(conf_key)

        def _number_key(conf_key: str) -> vol.Optional:
            guess = guesses.get(conf_key)
            return vol.Optional(conf_key, default=guess) if guess in number_entities else vol.Optional(conf_key)

        def _select_key(conf_key: str, options: dict[str, str]) -> vol.Optional:
            guess = guesses.get(conf_key)
            return vol.Optional(conf_key, default=guess) if guess in options else vol.Optional(conf_key)

        default_discharge_current = _float_state(
            self.hass,
            guesses.get(CONF_DEYE_MAX_BATTERY_DISCHARGE_CURRENT),
            0.0,
        )

        schema = vol.Schema(
            {
                _switch_key(CONF_DEYE_GRID_CHARGE_SWITCH): vol.In(switch_entities),
                _switch_key(CONF_DEYE_TIME_OF_USE_SWITCH): vol.In(switch_entities),
                _switch_key(CONF_DEYE_TIME_POINT_1_ENABLE): vol.In(switch_entities),
                _number_key(CONF_DEYE_TIME_POINT_1_START): vol.In(number_entities),
                _number_key(CONF_DEYE_TIME_POINT_1_CAPACITY): vol.In(number_entities),
                _number_key(CONF_DEYE_GRID_CHARGE_CURRENT): vol.In(number_entities),
                _number_key(CONF_DEYE_MAX_BATTERY_DISCHARGE_CURRENT): vol.In(number_entities),
                vol.Optional(CONF_DEYE_DEFAULT_BATTERY_DISCHARGE_CURRENT, default=default_discharge_current): NumberSelector(
                    NumberSelectorConfig(min=0, max=300, step=1, mode=NumberSelectorMode.BOX, unit_of_measurement="A")
                ),
                _select_key(CONF_DEYE_ENERGY_PRIORITY, priority_entities): vol.In(priority_entities),
                _select_key(CONF_DEYE_LIMIT_CONTROL_MODE, limit_entities): vol.In(limit_entities),
                vol.Optional(CONF_SOLAR_SELL_ENTITY): vol.In(all_switch_entities),
            }
        )
        return self.async_show_form(step_id="deye_control", data_schema=schema)

    async def async_step_ev_options(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if not self._data.get(CONF_EV_CHARGING_ENABLED):
            return await self.async_step_finish()
        if user_input is not None:
            self._data[CONF_EV_CHARGER_TYPE] = user_input[CONF_EV_CHARGER_TYPE]
            return await self.async_step_ev_charger_entities()
        schema = vol.Schema(
            {
                vol.Required(CONF_EV_CHARGER_TYPE, default="easee"): vol.In(
                    {"easee": "Easee", "manual": "Manual charger"}
                )
            }
        )
        return self.async_show_form(step_id="ev_options", data_schema=schema)

    async def async_step_ev_charger_entities(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        charger_type = self._data.get(CONF_EV_CHARGER_TYPE, "manual")
        if user_input is not None:
            self._data.update({key: value for key, value in user_input.items() if value})
            return await self.async_step_vehicle_type()

        if charger_type == "easee":
            detected_status, detected_power, detected_charger_id = await _detect_easee_entities(self.hass)
            schema = vol.Schema(
                {
                    (vol.Required(CONF_EV_CHARGER_STATUS_ENTITY, default=detected_status) if detected_status else vol.Required(CONF_EV_CHARGER_STATUS_ENTITY)): EntitySelector(EntitySelectorConfig(domain="sensor")),
                    (vol.Optional(CONF_EV_CHARGER_POWER_ENTITY, default=detected_power) if detected_power else vol.Optional(CONF_EV_CHARGER_POWER_ENTITY)): EntitySelector(EntitySelectorConfig(domain="sensor")),
                    (vol.Optional(CONF_EV_CHARGER_ID, default=detected_charger_id) if detected_charger_id else vol.Optional(CONF_EV_CHARGER_ID)): cv.string,
                    vol.Optional(CONF_EV_MAX_CHARGE_KW, default=DEFAULT_EV_MAX_CHARGE_KW): vol.Coerce(float),
                }
            )
        else:
            schema = vol.Schema(
                {
                    vol.Required(CONF_EV_CHARGER_STATUS_ENTITY): EntitySelector(EntitySelectorConfig()),
                    vol.Optional(CONF_EV_CHARGER_POWER_ENTITY): EntitySelector(EntitySelectorConfig()),
                    vol.Optional(CONF_EV_CHARGER_PAUSE_SWITCH): EntitySelector(EntitySelectorConfig(domain="switch")),
                    vol.Optional(CONF_EV_MAX_CHARGE_KW, default=DEFAULT_EV_MAX_CHARGE_KW): vol.Coerce(float),
                }
            )
        return self.async_show_form(step_id="ev_charger_entities", data_schema=schema)

    async def async_step_vehicle_type(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if user_input is not None:
            self._data[CONF_VEHICLE_TYPE] = user_input[CONF_VEHICLE_TYPE]
            if user_input[CONF_VEHICLE_TYPE] == "none":
                return await self.async_step_finish()
            return await self.async_step_vehicle_entities()
        schema = vol.Schema(
            {
                vol.Required(CONF_VEHICLE_TYPE, default="none"): vol.In(
                    {"kia_hyundai": "Kia / Hyundai", "manual": "Manual vehicle", "none": "No vehicle integration"}
                )
            }
        )
        return self.async_show_form(step_id="vehicle_type", data_schema=schema)

    async def async_step_vehicle_entities(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        vehicle_type = self._data.get(CONF_VEHICLE_TYPE, "manual")
        if user_input is not None:
            self._data.update({key: value for key, value in user_input.items() if value})
            return await self.async_step_finish()

        if vehicle_type == "kia_hyundai":
            detected_soc, detected_plugged_in, detected_target_soc, detected_range = await _detect_kia_entities(self.hass)
        else:
            detected_soc, detected_plugged_in, detected_target_soc, detected_range = (None, None, None, None)

        schema = vol.Schema(
            {
                (vol.Required(CONF_VEHICLE_SOC_ENTITY, default=detected_soc) if detected_soc else vol.Required(CONF_VEHICLE_SOC_ENTITY)): EntitySelector(EntitySelectorConfig(domain="sensor")),
                (vol.Optional(CONF_VEHICLE_PLUGGED_IN_ENTITY, default=detected_plugged_in) if detected_plugged_in else vol.Optional(CONF_VEHICLE_PLUGGED_IN_ENTITY)): EntitySelector(EntitySelectorConfig(domain="binary_sensor")),
                (vol.Optional(CONF_VEHICLE_TARGET_SOC_ENTITY, default=detected_target_soc) if detected_target_soc else vol.Optional(CONF_VEHICLE_TARGET_SOC_ENTITY)): EntitySelector(EntitySelectorConfig(domain=["sensor", "number"])),
                (vol.Optional(CONF_VEHICLE_RANGE_ENTITY, default=detected_range) if detected_range else vol.Optional(CONF_VEHICLE_RANGE_ENTITY)): EntitySelector(EntitySelectorConfig(domain="sensor")),
                vol.Required(CONF_VEHICLE_BATTERY_CAPACITY, default=77.0): vol.All(vol.Coerce(float), vol.Range(min=10, max=200)),
            }
        )
        return self.async_show_form(step_id="vehicle_entities", data_schema=schema)

    async def async_step_finish(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        self._data.setdefault(CONF_CHEAP_GRID_THRESHOLD, DEFAULT_CHEAP_GRID_THRESHOLD)
        self._data.setdefault("control_enabled", False)
        self._data.setdefault("battery_sell_enabled", True)
        self._data.setdefault("ev_solar_only_grid_buffer_enabled", True)
        self._data.setdefault("advanced_consumption_model_enabled", False)
        self._data.setdefault("shadow_log_enabled", False)
        self._data.setdefault("ev_charge_mode", "solar_only")
        return self.async_create_entry(title=self._data[CONF_NAME], data=self._data)


class SolarFriendV2OptionsFlow(OptionsFlow):
    """Edit the most important V2 settings after setup."""

    def __init__(self, config_entry) -> None:
        self._config_entry = config_entry
        self._updates: dict[str, Any] = {}

    def _current(self, key: str, default: Any) -> Any:
        if key in self._updates:
            return self._updates[key]
        if key in self._config_entry.options:
            return self._config_entry.options[key]
        return self._config_entry.data.get(key, default)

    async def async_step_init(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if user_input is not None:
            self._updates.update(user_input)
            return await self.async_step_battery()

        schema = vol.Schema(
            {
                vol.Required(CONF_EV_CHARGING_ENABLED, default=bool(self._current(CONF_EV_CHARGING_ENABLED, False))): bool,
                vol.Required("control_enabled", default=bool(self._current("control_enabled", False))): bool,
                vol.Required("battery_sell_enabled", default=bool(self._current("battery_sell_enabled", True))): bool,
                vol.Required(
                    "advanced_consumption_model_enabled",
                    default=bool(self._current("advanced_consumption_model_enabled", False)),
                ): bool,
                vol.Required(
                    "ev_solar_only_grid_buffer_enabled",
                    default=bool(self._current("ev_solar_only_grid_buffer_enabled", True)),
                ): bool,
                vol.Required("shadow_log_enabled", default=bool(self._current("shadow_log_enabled", False))): bool,
            }
        )
        return self.async_show_form(step_id="init", data_schema=schema)

    async def async_step_battery(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            if user_input[CONF_BATTERY_MIN_SOC] >= user_input[CONF_BATTERY_MAX_SOC]:
                errors[CONF_BATTERY_MIN_SOC] = "min_soc_above_max"
            else:
                self._updates.update(user_input)
                return await self.async_step_ev()

        schema = vol.Schema(
            {
                vol.Required(CONF_BATTERY_MIN_SOC, default=float(self._current(CONF_BATTERY_MIN_SOC, 10.0))): NumberSelector(
                    NumberSelectorConfig(min=0, max=50, step=5, mode=NumberSelectorMode.SLIDER)
                ),
                vol.Required(CONF_BATTERY_MAX_SOC, default=float(self._current(CONF_BATTERY_MAX_SOC, 90.0))): NumberSelector(
                    NumberSelectorConfig(min=50, max=100, step=5, mode=NumberSelectorMode.SLIDER)
                ),
                vol.Required(CONF_CHARGE_RATE_KW, default=float(self._current(CONF_CHARGE_RATE_KW, 6.0))): NumberSelector(
                    NumberSelectorConfig(min=0.5, max=20.0, step=0.5, mode=NumberSelectorMode.BOX)
                ),
                vol.Required(
                    CONF_BATTERY_COST_PER_KWH,
                    default=float(self._current(CONF_BATTERY_COST_PER_KWH, 0.30)),
                ): NumberSelector(
                    NumberSelectorConfig(min=0.0, max=2.0, step=0.05, mode=NumberSelectorMode.BOX, unit_of_measurement="kr/kWh")
                ),
                vol.Required(
                    CONF_MIN_CHARGE_SAVING,
                    default=float(self._current(CONF_MIN_CHARGE_SAVING, 0.20)),
                ): NumberSelector(
                    NumberSelectorConfig(min=0.05, max=1.0, step=0.05, mode=NumberSelectorMode.SLIDER, unit_of_measurement="kr/kWh")
                ),
                vol.Required(
                    CONF_CHEAP_GRID_THRESHOLD,
                    default=float(self._current(CONF_CHEAP_GRID_THRESHOLD, DEFAULT_CHEAP_GRID_THRESHOLD)),
                ): NumberSelector(
                    NumberSelectorConfig(min=0.0, max=1.0, step=0.05, mode=NumberSelectorMode.SLIDER, unit_of_measurement="kr/kWh")
                ),
            }
        )
        return self.async_show_form(step_id="battery", data_schema=schema, errors=errors)

    async def async_step_ev(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if not self._current(CONF_EV_CHARGING_ENABLED, False):
            return await self.async_step_finish()

        if user_input is not None:
            self._updates.update(user_input)
            return await self.async_step_finish()

        schema = vol.Schema(
            {
                vol.Required(
                    "ev_charge_mode",
                    default=str(self._current("ev_charge_mode", "solar_only")),
                ): SelectSelector(
                    SelectSelectorConfig(
                        options=[
                            {"value": "solar_only", "label": "Solar only"},
                            {"value": "hybrid", "label": "Hybrid"},
                            {"value": "grid_only", "label": "Grid only"},
                        ],
                        mode=SelectSelectorMode.LIST,
                    )
                ),
                vol.Required(
                    CONF_EV_MAX_CHARGE_KW,
                    default=float(self._current(CONF_EV_MAX_CHARGE_KW, DEFAULT_EV_MAX_CHARGE_KW)),
                ): NumberSelector(
                    NumberSelectorConfig(min=1.4, max=22.0, step=0.1, mode=NumberSelectorMode.BOX)
                ),
                vol.Optional(
                    CONF_VEHICLE_BATTERY_CAPACITY,
                    default=float(self._current(CONF_VEHICLE_BATTERY_CAPACITY, 77.0)),
                ): NumberSelector(
                    NumberSelectorConfig(min=10.0, max=200.0, step=0.5, mode=NumberSelectorMode.BOX)
                ),
            }
        )
        return self.async_show_form(step_id="ev", data_schema=schema)

    async def async_step_finish(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        return self.async_create_entry(title="", data=dict(self._updates))
