"""SolarFriend V2 integration entrypoints."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .const import DOMAIN

if TYPE_CHECKING:
    from homeassistant.config_entries import ConfigEntry
    from homeassistant.core import HomeAssistant


def _platforms() -> list[Any]:
    from homeassistant.const import Platform

    button_platform = getattr(Platform, "BUTTON", "button")
    return [
        Platform.SENSOR,
        Platform.BINARY_SENSOR,
        Platform.NUMBER,
        Platform.SWITCH,
        Platform.SELECT,
        button_platform,
    ]


async def async_setup_entry(hass: "HomeAssistant", entry: "ConfigEntry") -> bool:
    from .coordinator import SolarFriendCoordinator

    coordinator = SolarFriendCoordinator(hass, entry)
    await coordinator.async_startup()
    await coordinator.async_config_entry_first_refresh()
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator
    await hass.config_entries.async_forward_entry_setups(entry, _platforms())
    return True


async def async_unload_entry(hass: "HomeAssistant", entry: "ConfigEntry") -> bool:
    coordinator = hass.data.get(DOMAIN, {}).get(entry.entry_id)
    if coordinator is not None:
        coordinator.unregister_listeners()
        await coordinator.async_persist_state()

    unloaded = await hass.config_entries.async_unload_platforms(entry, _platforms())
    if unloaded:
        hass.data[DOMAIN].pop(entry.entry_id, None)
    return unloaded
