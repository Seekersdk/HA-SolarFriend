"""Forecast adapter — normalises Solcast / Forecast.Solar data to ForecastSlot list.

Lag: ingest
Afhænger af: core/types, core/time_utils
Må IKKE importere: homeassistant (kun typer) — al HA state-læsning sker i coordinator

Centrale funktioner:
  normalize_solcast():        konverter Solcast detailedForecast-attribut til ForecastSlot-liste
  normalize_forecast_solar(): konverter Forecast.Solar current_hour / next_hour til ForecastSlot-liste
  forecast_kwh_for_period():  summer kWh for en given tidsperiode fra en ForecastSlot-liste

Vigtige invarianter:
  - parse_utc_or_aware() bruges til alle timestamps (Solcast er UTC, Forecast.Solar er lokal)
  - Solcast-slots er 30-min intervaller: kw * interval_hours = kWh
  - ForecastSlot.kwh er altid ≥ 0 og ≤ _MAX_SLOT_KWH
  - Slots sorteres altid på start-tidspunkt
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from ..core.time_utils import parse_utc_or_aware
from ..core.types import ForecastSlot

_LOGGER = logging.getLogger(__name__)

_MAX_SLOT_KWH = 100.0  # 200 kW kontinuert — langt over enhver boligsolaranlæg


def _clamp_kwh(kwh: float, label: str = "") -> float:
    """Clamp kWh to [0, _MAX_SLOT_KWH]."""
    if kwh < 0:
        return 0.0
    if kwh > _MAX_SLOT_KWH:
        _LOGGER.warning(
            "ForecastAdapter: slot %s %.1f kWh afskåret til %.1f kWh",
            label, kwh, _MAX_SLOT_KWH,
        )
        return _MAX_SLOT_KWH
    return kwh


def normalize_solcast(
    detailed_forecast: list[dict[str, Any]],
) -> list[ForecastSlot]:
    """Normalise a Solcast detailedForecast attribute list to ForecastSlots.

    Solcast sends 30-minute slots with fields:
      period_start: ISO datetime (typically UTC or aware)
      period_end:   ISO datetime (optional; used to derive interval if present)
      pv_estimate:  kW (average over interval)  → kWh = kw * interval_hours

    Returns a sorted list of ForecastSlots.
    """
    slots: list[ForecastSlot] = []

    for entry in detailed_forecast:
        ps_raw = entry.get("period_start")
        if ps_raw is None:
            continue
        try:
            start = parse_utc_or_aware(ps_raw)
        except (ValueError, TypeError):
            continue

        # Derive interval from period_end if available; default 30 minutes
        interval_hours = 0.5
        pe_raw = entry.get("period_end")
        if pe_raw is not None:
            try:
                end_dt = parse_utc_or_aware(pe_raw)
                derived = (end_dt - start).total_seconds() / 3600.0
                if derived > 0:
                    interval_hours = derived
            except (ValueError, TypeError):
                pass

        end = start + timedelta(hours=interval_hours)

        kw = float(entry.get("pv_estimate", 0.0))
        kwh = _clamp_kwh(kw * interval_hours, str(start))

        slots.append(ForecastSlot(start=start, end=end, kwh=round(kwh, 4)))

    slots.sort(key=lambda s: s.start)
    return slots


def normalize_forecast_solar(
    hourly_entries: list[dict[str, Any]],
) -> list[ForecastSlot]:
    """Normalise a Forecast.Solar-style entry list to ForecastSlots.

    Entries may contain:
      period_start: ISO datetime
      pv_estimate_kwh: direct kWh value (already accumulated over interval)
      interval_hours: interval duration (default 1.0 h)

    Returns a sorted list of ForecastSlots.
    """
    slots: list[ForecastSlot] = []

    for entry in hourly_entries:
        ps_raw = entry.get("period_start")
        if ps_raw is None:
            continue
        try:
            start = parse_utc_or_aware(ps_raw)
        except (ValueError, TypeError):
            continue

        interval_hours = float(entry.get("interval_hours", 1.0) or 1.0)
        if interval_hours <= 0:
            interval_hours = 1.0
        end = start + timedelta(hours=interval_hours)

        kwh = float(entry.get("pv_estimate_kwh", 0.0))
        kwh = _clamp_kwh(kwh, str(start))

        slots.append(ForecastSlot(start=start, end=end, kwh=round(kwh, 4)))

    slots.sort(key=lambda s: s.start)
    return slots


def forecast_kwh_for_period(
    slots: list[ForecastSlot],
    from_dt: datetime,
    to_dt: datetime,
) -> float:
    """Sum kWh for all slots whose period_start falls within [from_dt, to_dt).

    Both from_dt and to_dt must be timezone-aware (from time_utils).
    """
    return round(
        sum(s.kwh for s in slots if from_dt <= s.start < to_dt),
        4,
    )
