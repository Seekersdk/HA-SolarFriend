"""Helpers for merging charger and vehicle EV state."""
from __future__ import annotations

from dataclasses import replace

from ..core.types import ChargerState, EVState


def normalize_vehicle_state(
    vehicle_state: EVState | None,
    charger_state: ChargerState | None,
    *,
    target_soc_override: float | None = None,
) -> EVState | None:
    """Merge charger-connected fallback into vehicle state.

    Vehicle telematics can lag behind charger connection state. If the charger is
    physically connected, prefer that as a fallback for `plugged_in`, but do not
    invent a vehicle state when none exists.
    """
    if vehicle_state is None:
        return None
    normalized = vehicle_state
    if charger_state is not None and charger_state.connected and not normalized.plugged_in:
        normalized = replace(normalized, plugged_in=True)
    if target_soc_override is not None:
        normalized = replace(normalized, target_soc_pct=float(target_soc_override))
    return normalized
