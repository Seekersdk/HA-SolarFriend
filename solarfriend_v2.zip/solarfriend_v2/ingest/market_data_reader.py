"""Read normalized price and forecast data from Home Assistant state."""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant

from ..config import entry_value
from ..core.types import PriceSlot
from .forecast_adapter import normalize_forecast_solar, normalize_solcast
from .price_adapter import normalize_price_data

_SOLCAST_TODAY = "sensor.solcast_pv_forecast_forecast_today"
_SOLCAST_TOMORROW = "sensor.solcast_pv_forecast_forecast_tomorrow"


def read_price_slots(hass: HomeAssistant, config_entry: Any, now: datetime):
    buy_state = hass.states.get(
        entry_value(config_entry, "buy_price_sensor") or entry_value(config_entry, "price_sensor")
    )
    sell_entity = entry_value(config_entry, "sell_price_sensor")
    sell_state = hass.states.get(sell_entity) if sell_entity else None
    raw_today, raw_tomorrow = _raw_price_entries(buy_state)
    sell_today, sell_tomorrow = _raw_price_entries(sell_state)
    return normalize_price_data(
        raw_today,
        raw_tomorrow,
        now,
        sell_today=sell_today,
        sell_tomorrow=sell_tomorrow,
    )


def read_sell_price_slots(hass: HomeAssistant, config_entry: Any, now: datetime):
    sell_entity = entry_value(config_entry, "sell_price_sensor")
    sell_state = hass.states.get(sell_entity) if sell_entity else None
    sell_today, sell_tomorrow = _raw_price_entries(sell_state)
    sell_slots = normalize_price_data(sell_today, sell_tomorrow, now)
    return [
        PriceSlot(
            start=slot.start,
            end=slot.end,
            price_dkk=slot.price_dkk,
            sell_price_dkk=slot.price_dkk,
        )
        for slot in sell_slots
    ]


def read_forecast_slots(hass: HomeAssistant, config_entry: Any, now: datetime):
    forecast_type = entry_value(config_entry, "forecast_type", "solcast")
    if forecast_type == "solcast":
        entries: list[dict[str, Any]] = []
        for entity_id in (_SOLCAST_TODAY, _SOLCAST_TOMORROW):
            state = hass.states.get(entity_id)
            detailed = state.attributes.get("detailedForecast", []) if state is not None else []
            if isinstance(detailed, list):
                entries.extend(detailed)
        return normalize_solcast(entries)

    forecast_entity = entry_value(config_entry, "forecast_sensor")
    state = hass.states.get(forecast_entity) if forecast_entity else None
    if state is None:
        return []

    detailed = state.attributes.get("detailedForecast")
    if isinstance(detailed, list):
        return normalize_solcast(detailed)

    hourly_candidates = (
        state.attributes.get("hourly_forecast")
        or state.attributes.get("forecast")
        or state.attributes.get("hourly")
        or []
    )
    if isinstance(hourly_candidates, list) and hourly_candidates:
        normalized = []
        for entry in hourly_candidates:
            if not isinstance(entry, dict):
                continue
            normalized.append(
                {
                    "period_start": entry.get("period_start") or entry.get("start"),
                    "pv_estimate_kwh": (
                        entry.get("pv_estimate_kwh")
                        if entry.get("pv_estimate_kwh") is not None
                        else entry.get("value")
                    ),
                    "interval_hours": entry.get("interval_hours", 1.0),
                }
            )
        return normalize_forecast_solar(normalized)

    current_hour = now.replace(minute=0, second=0, microsecond=0)
    fallback_entries = []
    for offset, entity_id in enumerate(("sensor.energy_current_hour", "sensor.energy_next_hour")):
        sensor_state = hass.states.get(entity_id)
        if sensor_state is None:
            continue
        try:
            kwh = float(sensor_state.state)
        except (TypeError, ValueError):
            continue
        fallback_entries.append(
            {
                "period_start": (current_hour + timedelta(hours=offset)).isoformat(),
                "pv_estimate_kwh": kwh,
                "interval_hours": 1.0,
            }
        )
    return normalize_forecast_solar(fallback_entries)


def current_solar_geometry(hass: HomeAssistant) -> tuple[float | None, float | None]:
    sun_state = hass.states.get("sun.sun")
    if sun_state is None:
        return (None, None)
    try:
        return (
            float(sun_state.attributes.get("elevation")),
            float(sun_state.attributes.get("azimuth")),
        )
    except (TypeError, ValueError):
        return (None, None)


def read_sunset_datetime(hass: HomeAssistant, now: datetime) -> datetime | None:
    sun_state = hass.states.get("sun.sun")
    if sun_state is None:
        return None
    raw_next_setting = sun_state.attributes.get("next_setting")
    if raw_next_setting is None:
        return None
    try:
        next_setting = datetime.fromisoformat(str(raw_next_setting))
    except ValueError:
        return None
    if next_setting.tzinfo is None:
        return None
    state = str(sun_state.state)
    if state == "below_horizon" and next_setting.date() > now.date():
        return next_setting - timedelta(days=1)
    return next_setting


def read_cloud_coverage_pct(hass: HomeAssistant, config_entry: Any) -> float | None:
    weather_entity = entry_value(config_entry, "weather_entity")
    if not weather_entity:
        return None
    state = hass.states.get(weather_entity)
    if state is None:
        return None
    try:
        return float(state.attributes.get("cloud_coverage"))
    except (TypeError, ValueError):
        return None


def has_usable_state(hass: HomeAssistant, entity_id: str | None) -> bool:
    if not entity_id:
        return False
    state = hass.states.get(entity_id)
    if state is None or state.state in ("unknown", "unavailable", ""):
        return False
    return True


def _raw_price_entries(state) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    if state is None:
        return [], []
    raw_today = state.attributes.get("raw_today", []) or []
    raw_tomorrow = state.attributes.get("raw_tomorrow", []) or []
    return (
        raw_today if isinstance(raw_today, list) else [],
        raw_tomorrow if isinstance(raw_tomorrow, list) else [],
    )
