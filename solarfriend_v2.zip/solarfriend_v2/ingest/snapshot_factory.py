"""Build immutable planning snapshots from coordinator state."""
from __future__ import annotations

from datetime import datetime, time, timedelta
from typing import Any

from ..config import entry_value
from ..core.types import ChargerState, EVState, PowerReading
from ..planning.base import FlexLoad
from ..planning.world_snapshot import BatterySnapshot, ConsumptionProfileSnapshot, WorldSnapshot


def build_battery_snapshot(*, tracker: Any, config_entry: Any, read_float_state) -> BatterySnapshot:
    tracker_state = tracker.state
    return BatterySnapshot(
        soc_pct=read_float_state(entry_value(config_entry, "battery_soc_sensor"), 0.0),
        solar_kwh=tracker_state.solar_kwh,
        grid_kwh=tracker_state.grid_kwh,
        weighted_cost_dkk=tracker.weighted_cost,
        capacity_kwh=float(entry_value(config_entry, "battery_capacity_kwh", 10.0)),
        min_soc_pct=float(entry_value(config_entry, "battery_min_soc", 10.0)),
        max_soc_pct=float(entry_value(config_entry, "battery_max_soc", 90.0)),
        charge_rate_kw=float(entry_value(config_entry, "charge_rate_kw", 6.0)),
    )


def build_consumption_snapshot(consumption_model: Any) -> ConsumptionProfileSnapshot:
    simple = consumption_model.simple
    return ConsumptionProfileSnapshot(
        hourly_weekday_w=[simple.get_predicted_w(hour, False) for hour in range(24)],
        hourly_weekend_w=[simple.get_predicted_w(hour, True) for hour in range(24)],
        confidence="MATURE" if simple.days_collected >= 7 else "LEARNING",
        days_collected=simple.days_collected,
    )


def build_ev_departure(now: datetime, departure_time: datetime | time | str | None) -> datetime | None:
    if departure_time is None:
        return None
    if isinstance(departure_time, str):
        departure_time = time.fromisoformat(departure_time)
    if isinstance(departure_time, datetime):
        return departure_time if departure_time > now else departure_time + timedelta(days=1)
    departure_dt = datetime.combine(now.date(), departure_time, tzinfo=now.tzinfo)
    if departure_dt <= now:
        departure_dt += timedelta(days=1)
    return departure_dt


def build_world_snapshot(
    *,
    now: datetime,
    power: PowerReading,
    battery: BatterySnapshot,
    prices,
    sell_prices,
    forecast,
    consumption: ConsumptionProfileSnapshot,
    ev: EVState | None,
    charger: ChargerState | None,
    flex_loads: list[FlexLoad],
    ev_departure: datetime | None,
    sunset_datetime: datetime | None,
    ev_mode: str,
    ev_max_charge_kw: float,
    ev_min_range_km: float,
    cloud_coverage_pct: float | None,
    solar_elevation_deg: float | None,
    solar_azimuth_deg: float | None,
    config_entry: Any,
    battery_sell_enabled: bool,
    ev_charging_enabled: bool,
) -> WorldSnapshot:
    return WorldSnapshot(
        now=now,
        power=power,
        battery=battery,
        prices=prices,
        sell_prices=sell_prices,
        forecast=forecast,
        consumption=consumption,
        ev=ev,
        charger=charger,
        flex_loads=list(flex_loads),
        ev_departure=ev_departure,
        sunset_datetime=sunset_datetime,
        ev_mode=ev_mode,
        ev_max_charge_kw=ev_max_charge_kw,
        ev_min_range_km=ev_min_range_km,
        cloud_coverage_pct=cloud_coverage_pct,
        solar_elevation_deg=solar_elevation_deg,
        solar_azimuth_deg=solar_azimuth_deg,
        min_charge_saving_dkk=float(entry_value(config_entry, "min_charge_saving", 0.20)),
        battery_cost_per_kwh_dkk=float(entry_value(config_entry, "battery_cost_per_kwh", 0.30)),
        cheap_grid_threshold_dkk=float(entry_value(config_entry, "cheap_grid_threshold", 0.10)),
        battery_sell_enabled=battery_sell_enabled,
        ev_charging_enabled=ev_charging_enabled,
    )
