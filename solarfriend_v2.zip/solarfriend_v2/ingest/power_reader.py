"""Power reader — reads live power sensors from HA and returns a PowerReading.

Lag: ingest
Afhænger af: core/types, core/time_utils, homeassistant.core
Dette er det ENESTE sted der læser HA live state for effektmålinger.

Signkonventioner (normaliseres her — planners og learning-lag antager disse):
  pv_w      > 0 altid   (solproduktion)
  battery_w > 0 = afladning, < 0 = opladning
  grid_w    > 0 = import fra net, < 0 = eksport til net
  load_w    > 0 altid   (hus-forbrug, ikke inkl. EV)
  ev_w      > 0 altid   (EV-forbrug, 0 hvis ikke tilgængeligt)

Vigtige invarianter:
  - pv2_power_sensor summeres med pv_power_sensor til samlet pv_w
  - Hvis load_sensor er total site load (inkl. EV), trækkes ev_w fra
  - Manglende sensor → 0.0 med debug-log (systemet kører videre)
  - config-nøgler afspejler v1 config_entry.data nøgler
"""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.core import HomeAssistant

from ..core.time_utils import now_local
from ..core.types import PowerReading

_LOGGER = logging.getLogger(__name__)

# Config keys — must match config_flow.py / v1 config_entry.data keys
_KEY_PV        = "pv_power_sensor"
_KEY_PV2       = "pv2_power_sensor"
_KEY_GRID      = "grid_power_sensor"
_KEY_BATTERY   = "battery_power_sensor"
_KEY_LOAD      = "load_power_sensor"
_KEY_LOAD_IS_TOTAL = "load_sensor_is_total_load"


def _read_float(hass: HomeAssistant, entity_id: str | None) -> float | None:
    """Return float state or None if unavailable."""
    if not entity_id:
        return None
    state = hass.states.get(entity_id)
    if state is None or state.state in ("unavailable", "unknown", ""):
        return None
    try:
        return float(state.state)
    except (ValueError, TypeError):
        return None


def _load_sensor_is_total(config: dict[str, Any]) -> bool:
    """True when the configured load sensor reports whole-site load (incl. EV)."""
    if config.get(_KEY_LOAD_IS_TOTAL):
        return True
    entity_id = str(config.get(_KEY_LOAD, "")).lower()
    return any(token in entity_id for token in ("load_totalpower", "totalpower", "total_load"))


async def read_power(hass: HomeAssistant, config: dict[str, Any]) -> PowerReading:
    """Read all live power sensors and return a normalised PowerReading.

    Missing sensors default to 0.0. Call from the coordinator tick after
    EV state has been fetched so ev_w is accurate.

    Args:
        hass:   Home Assistant instance.
        config: dict with sensor entity_id values (matches config_entry.data).

    Returns:
        PowerReading with normalised sign conventions.
    """
    pv1_w  = _read_float(hass, config.get(_KEY_PV))  or 0.0
    pv2_w  = _read_float(hass, config.get(_KEY_PV2)) or 0.0
    grid_w = _read_float(hass, config.get(_KEY_GRID)) or 0.0
    bat_w  = _read_float(hass, config.get(_KEY_BATTERY)) or 0.0
    load_w = _read_float(hass, config.get(_KEY_LOAD)) or 0.0

    pv_w = abs(pv1_w) + abs(pv2_w)  # PV is always positive

    # EV power is not read here — it comes from EVRuntime after charger state sync.
    # Coordinator passes ev_w in when it calls observe() on learning modules.
    ev_w = 0.0

    # When load sensor is total site load, subtract EV to get house-only load.
    # At this point ev_w = 0.0, so house load = total load. EVRuntime corrects
    # this by passing ev_power_w to observe() after charger state is known.
    if _load_sensor_is_total(config):
        house_load_w = max(0.0, load_w - ev_w)
    else:
        house_load_w = max(0.0, load_w)

    if not config.get(_KEY_PV):
        _LOGGER.debug("PowerReader: ingen pv_power_sensor konfigureret")
    if not config.get(_KEY_GRID):
        _LOGGER.debug("PowerReader: ingen grid_power_sensor konfigureret")

    return PowerReading(
        pv_w=pv_w,
        grid_w=grid_w,       # sign from inverter — planners use the convention above
        battery_w=bat_w,     # sign from inverter
        load_w=house_load_w,
        ev_w=ev_w,
        timestamp=now_local(),
    )
