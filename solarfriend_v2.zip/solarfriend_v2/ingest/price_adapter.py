"""Price adapter — normalises raw HA price sensor data to PriceSlot list.

Lag: ingest
Afhænger af: core/types, core/time_utils
Må IKKE importere: homeassistant (kun typer) — al HA state-læsning sker i coordinator

Centrale funktioner:
  normalize_price_data():  konverter raw_today + raw_tomorrow til sorteret PriceSlot-liste
  current_price():         find prisen for en given datetime ud fra en PriceSlot-liste

Understøttede input-formater:
  - {"hour": 14, "price": 1.23}            (integer-hour — legacy Nordpool/EDS format)
  - {"start": "2026-04-01T14:00:00+02:00", "price": 1.23}  (ISO aware — moderne format)
  - {"start": "2026-04-01T14:00:00", "price": 1.23}         (ISO naive — behandles som lokal tid)

Vigtige invarianter:
  - V1-fejl #1 rettet: current_price() bruger datetime-sammenligning, IKKE integer hour-matching
  - raw_today og raw_tomorrow processeres separat så int-hour datoer ikke kolliderer
  - naive ISO timestamps antages at være lokal tid (Nordpool konvention) via parse_local_or_aware
  - Priser uden for [-10, 50] DKK/kWh springes over med advarsel
  - now-parameteren er altid aware local datetime (fra time_utils.now_local())
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Any

from ..core.time_utils import parse_local_or_aware
from ..core.types import PriceSlot

_LOGGER = logging.getLogger(__name__)

_PRICE_MIN_DKK = -10.0
_PRICE_MAX_DKK = 50.0


def _parse_start(
    raw_dt: Any,
    now: datetime,
    *,
    date_hint: date | None = None,
) -> datetime | None:
    """Parse one entry's start field to an aware local datetime.

    Handles:
      - int       → hour of day; forced to date_hint if given, else today or tomorrow
      - str/datetime → ISO; naive treated as local time; date_hint ignored
    Returns None if the value cannot be parsed.
    """
    if isinstance(raw_dt, int):
        hour = raw_dt % 24
        if date_hint is not None:
            # Force int-hour to the specified date — avoids collision between today/tomorrow
            return now.replace(
                year=date_hint.year, month=date_hint.month, day=date_hint.day,
                hour=hour, minute=0, second=0, microsecond=0,
            )
        # No date hint: use today unless the hour is already past (> 1h ago)
        candidate = now.replace(hour=hour, minute=0, second=0, microsecond=0)
        if candidate < now - timedelta(hours=1):
            candidate += timedelta(days=1)
        return candidate

    if isinstance(raw_dt, (str, datetime)):
        try:
            return parse_local_or_aware(raw_dt).replace(minute=0, second=0, microsecond=0)
        except (ValueError, TypeError):
            return None

    return None


def _parse_entries(
    entries: list[dict[str, Any]],
    now: datetime,
    *,
    date_hint: date | None = None,
) -> dict[datetime, float]:
    """Parse a raw entry list into {start: price} with proper aware datetimes.

    date_hint: when set, forces int-hour entries onto this specific date.
    """
    result: dict[datetime, float] = {}

    for entry in entries:
        raw_price = entry.get("price") if entry.get("price") is not None else entry.get("value")
        if raw_price is None:
            continue
        try:
            price = float(raw_price)
        except (TypeError, ValueError):
            continue

        if not (_PRICE_MIN_DKK <= price <= _PRICE_MAX_DKK):
            _LOGGER.warning(
                "PriceAdapter: pris %.4f DKK/kWh er uden for gyldigt interval [%.1f, %.1f] — springes over",
                price, _PRICE_MIN_DKK, _PRICE_MAX_DKK,
            )
            continue

        raw_dt = entry.get("start") if entry.get("start") is not None else entry.get("hour")
        start = _parse_start(raw_dt, now, date_hint=date_hint)
        if start is None:
            continue

        result[start] = price

    return result


def normalize_price_data(
    raw_today: list[dict[str, Any]],
    raw_tomorrow: list[dict[str, Any]],
    now: datetime,
    *,
    sell_today: list[dict[str, Any]] | None = None,
    sell_tomorrow: list[dict[str, Any]] | None = None,
) -> list[PriceSlot]:
    """Parse raw_today + raw_tomorrow into a sorted list of PriceSlots.

    raw_today and raw_tomorrow are processed separately so that int-hour
    format entries for today and tomorrow get the correct dates assigned.

    Args:
        raw_today:     list of price entries for today (int-hour or ISO format)
        raw_tomorrow:  list of price entries for tomorrow
        now:           current aware local datetime (from time_utils.now_local())
        sell_today:    optional sell-price entries for today (same format)
        sell_tomorrow: optional sell-price entries for tomorrow

    Returns:
        Sorted list of PriceSlots, one per hour. Slots without sell price get 0.0.
    """
    today_date = now.date()
    tomorrow_date = today_date + timedelta(days=1)

    buy_map: dict[datetime, float] = {}
    buy_map.update(_parse_entries(raw_today or [], now, date_hint=today_date))
    buy_map.update(_parse_entries(raw_tomorrow or [], now, date_hint=tomorrow_date))

    sell_map: dict[datetime, float] = {}
    if sell_today or sell_tomorrow:
        sell_map.update(_parse_entries(sell_today or [], now, date_hint=today_date))
        sell_map.update(_parse_entries(sell_tomorrow or [], now, date_hint=tomorrow_date))

    slots: list[PriceSlot] = []
    for start, price in buy_map.items():
        end = start + timedelta(hours=1)
        sell_price = sell_map.get(start, 0.0)
        slots.append(PriceSlot(start=start, end=end, price_dkk=price, sell_price_dkk=sell_price))

    slots.sort(key=lambda s: s.start)
    return slots


def current_price(slots: list[PriceSlot], now: datetime) -> float | None:
    """Return the buy price for the hour containing now.

    V1-fejl #1 rettet: bruger datetime-sammenligning, ikke integer hour-matching.
    Returns None if no matching slot is found.
    """
    for slot in slots:
        if slot.start <= now < slot.end:
            return slot.price_dkk
    return None


def current_sell_price(slots: list[PriceSlot], now: datetime) -> float | None:
    """Return the sell price for the hour containing now.

    Returns None if no matching slot is found.
    """
    for slot in slots:
        if slot.start <= now < slot.end:
            return slot.sell_price_dkk
    return None
