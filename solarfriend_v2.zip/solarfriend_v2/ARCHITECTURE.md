# SolarFriend V2 — Architecture

## Layer diagram

```
┌─────────────────────────────────────────────────────┐
│  HA PLATFORM  sensor.py / switch.py / config_flow   │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│  ORCHESTRATION  coordinator.py  (~300 lines)         │
└───┬──────────┬─────────┬──────────┬─────────────────┘
    │          │         │          │
┌───▼───┐ ┌───▼──┐ ┌────▼───┐ ┌───▼────┐
│INGEST │ │LEARN │ │PLANNING│ │CONTROL │
│       │ │      │ │        │ │        │
│price  │ │cons. │ │battery │ │deye    │
│fcast  │ │solar │ │ev      │ │easee   │
│power  │ │fcorr │ │flex    │ │kia     │
└───┬───┘ └──┬───┘ └────┬───┘ └───┬────┘
    │         │          │         │
┌───▼─────────▼──────────▼─────────▼────┐
│  CORE  types.py / time_utils.py       │
│  No HA imports. Fully unit-testable.  │
└───────────────────────────────────────┘
```

## Data flow per tick

```
1. ingest/     → WorldSnapshot (normalized, typed, aware datetimes)
2. learning/   → observe(WorldSnapshot.power)  [side-effect: model update]
3. planning/   → BatteryPlan, EVPlan, FlexPlan  [pure functions]
4. decision/   → Decision  [arbitration between plans]
5. runtime/    → apply Decision to controllers  [stateful: hysteresis, anti-flap]
6. presentation/ → sensor attributes  [pure mapping]
```

## Datetime contract

All datetimes inside the system are **timezone-aware local time**.
Normalization happens in `ingest/` via `core/time_utils.py`.
Planners and learning modules never parse raw timestamps.

## Adding a new inverter

1. Implement `control/inverter_interface.py:InverterController`
2. Register in `coordinator.py:async_setup()`
3. Add config flow option in `config_flow.py`

## Adding a new EV charger

1. Implement `control/charger_interface.py:ChargerController`
2. Register in `coordinator.py:async_setup()`

## Adding a new learning model

1. Implement `learning/base.py:LearningModule`
2. Register in `coordinator.py:_setup_learning()`
3. Add relevant fields to `planning/world_snapshot.py:WorldSnapshot` if planners need it
4. Add checkpoint key in `runtime/checkpoint.py`

## Adding a new planner

1. Implement `planning/base.py:Planner`
2. Wire into `coordinator.py:_async_update_data()`
3. Add to `decision/engine.py:decide()` if it conflicts with other plans
