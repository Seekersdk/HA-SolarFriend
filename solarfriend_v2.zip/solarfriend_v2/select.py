"""SolarFriend V2 select platform."""
from __future__ import annotations

from datetime import time
from typing import Any

from homeassistant.components.select import SelectEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.restore_state import RestoreEntity

from .config import entry_value, update_entry_options
from .const import DOMAIN

EV_CHARGE_MODES = ["solar_only", "hybrid", "grid_only"]
DEPARTURE_OPTIONS = [f"{h:02d}:{m:02d}" for h in range(24) for m in (0, 30)]
DEFAULT_DEPARTURE = "07:30"


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [
            SolarFriendV2EVModeSelect(coordinator),
            SolarFriendV2EVDepartureSelect(coordinator),
        ]
    )


class _BaseSelect(RestoreEntity, SelectEntity):
    _attr_has_entity_name = True

    def __init__(self, coordinator: Any, name: str, unique_suffix: str) -> None:
        self._coordinator = coordinator
        self._attr_unique_id = f"{coordinator.config_entry.entry_id}_{unique_suffix}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, coordinator.config_entry.entry_id)},
            name=entry_value(coordinator.config_entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )
        self._attr_name = name

    async def _notify(self, reason: str) -> None:
        callback = getattr(self._coordinator, "async_on_runtime_setting_changed", None)
        if callable(callback):
            await callback(reason=reason)


class SolarFriendV2EVModeSelect(_BaseSelect):
    _attr_icon = "mdi:solar-power"
    _attr_options = EV_CHARGE_MODES

    def __init__(self, coordinator: Any) -> None:
        super().__init__(coordinator, "EV Charge Mode", "ev_charge_mode")
        self._current_option = str(entry_value(coordinator.config_entry, "ev_charge_mode", getattr(coordinator, "ev_charge_mode", "solar_only")))

    @property
    def current_option(self) -> str:
        return self._current_option

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        last_state = await self.async_get_last_state()
        if last_state is not None and last_state.state in EV_CHARGE_MODES:
            self._current_option = last_state.state
        self._coordinator.ev_charge_mode = self._current_option

    async def async_select_option(self, option: str) -> None:
        if option not in EV_CHARGE_MODES:
            return
        self._current_option = option
        self._coordinator.ev_charge_mode = option
        update_entry_options(self.hass, self._coordinator.config_entry, ev_charge_mode=option)
        self.async_write_ha_state()
        await self._notify("select-ev_charge_mode-updated")


class SolarFriendV2EVDepartureSelect(_BaseSelect):
    _attr_icon = "mdi:car-clock"
    _attr_options = DEPARTURE_OPTIONS

    def __init__(self, coordinator: Any) -> None:
        super().__init__(coordinator, "EV Departure Time", "ev_departure_time")
        self._current_option = DEFAULT_DEPARTURE

    @property
    def current_option(self) -> str:
        return self._current_option

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        last_state = await self.async_get_last_state()
        if last_state is not None and last_state.state in DEPARTURE_OPTIONS:
            self._current_option = last_state.state
        self._coordinator.ev_departure_time = self._parse(self._current_option)

    async def async_select_option(self, option: str) -> None:
        if option not in DEPARTURE_OPTIONS:
            return
        self._current_option = option
        self._coordinator.ev_departure_time = self._parse(option)
        self.async_write_ha_state()
        await self._notify("select-ev_departure_time-updated")

    @staticmethod
    def _parse(value: str) -> time:
        h, m = value.split(":")
        return time(int(h), int(m))
