"""Compact monthly evaluation helpers for model quality via HA Store."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store


STORAGE_VERSION = 1
STORAGE_KEY = "solarfriend_v2.model_evaluation"


@dataclass(frozen=True)
class EvaluationRow:
    period_start: str
    actual_kwh: float
    models: dict[str, float]


@dataclass
class EvaluationSummary:
    period_month: str = ""
    rows: int = 0
    best_model: str = "n/a"
    mae_by_model: dict[str, float] = field(default_factory=dict)
    mape_by_model: dict[str, float] = field(default_factory=dict)
    bias_by_model: dict[str, float] = field(default_factory=dict)


class ModelEvaluation:
    def __init__(self, hass: HomeAssistant) -> None:
        self._store = Store(hass, version=STORAGE_VERSION, key=STORAGE_KEY)

    async def append(self, row: EvaluationRow) -> None:
        payload = await self._store.async_load() or {}
        rows = list(payload.get("rows", []))
        rows = [
            existing
            for existing in rows
            if not (
                isinstance(existing, dict)
                and str(existing.get("period_start", "")) == row.period_start
            )
        ]
        rows.append(
            {
                "period_start": row.period_start,
                "actual_kwh": row.actual_kwh,
                "models": row.models,
            }
        )
        await self._store.async_save({"rows": rows})

    async def summarize_month(self, month_key: str) -> EvaluationSummary:
        payload = await self._store.async_load() or {}
        return self.summarize_rows(payload.get("rows", []), month_key)

    @staticmethod
    def summarize_rows(rows_payload: list[dict[str, Any]], month_key: str) -> EvaluationSummary:
        abs_errors: dict[str, float] = {}
        pct_errors: dict[str, float] = {}
        bias_totals: dict[str, float] = {}
        counts: dict[str, int] = {}
        rows = 0

        for payload in rows_payload:
            if not isinstance(payload, dict):
                continue
            period_start = str(payload.get("period_start", ""))
            if not period_start.startswith(month_key):
                continue
            try:
                actual_kwh = float(payload.get("actual_kwh"))
            except (TypeError, ValueError):
                continue
            if actual_kwh <= 0:
                continue
            rows += 1
            for model_name, predicted in dict(payload.get("models", {})).items():
                try:
                    predicted_kwh = float(predicted)
                except (TypeError, ValueError):
                    continue
                abs_error = abs(predicted_kwh - actual_kwh)
                pct_error = abs_error / actual_kwh * 100.0
                bias = predicted_kwh - actual_kwh
                abs_errors[model_name] = abs_errors.get(model_name, 0.0) + abs_error
                pct_errors[model_name] = pct_errors.get(model_name, 0.0) + pct_error
                bias_totals[model_name] = bias_totals.get(model_name, 0.0) + bias
                counts[model_name] = counts.get(model_name, 0) + 1

        mae_by_model = {
            name: round(abs_errors[name] / counts[name], 4)
            for name in counts
            if counts[name] > 0
        }
        mape_by_model = {
            name: round(pct_errors[name] / counts[name], 2)
            for name in counts
            if counts[name] > 0
        }
        bias_by_model = {
            name: round(bias_totals[name] / counts[name], 4)
            for name in counts
            if counts[name] > 0
        }
        best_model = min(mae_by_model, key=mae_by_model.get) if mae_by_model else "n/a"
        return EvaluationSummary(
            period_month=month_key,
            rows=rows,
            best_model=best_model,
            mae_by_model=mae_by_model,
            mape_by_model=mape_by_model,
            bias_by_model=bias_by_model,
        )

    @staticmethod
    def month_key(value: datetime) -> str:
        return value.strftime("%Y-%m")
