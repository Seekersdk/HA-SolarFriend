"""Decision change logging with heartbeat and retention via HA Store."""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store


STORAGE_VERSION = 1
STORAGE_KEY = "solarfriend_v2.decision_log"


@dataclass(frozen=True)
class DecisionLogEntry:
    timestamp: str
    battery_strategy: str | None
    battery_reason: str | None
    ev_should_charge: bool | None
    ev_mode: str | None
    ev_reason: str | None
    flex_statuses: list[str]
    decision_summary: str


class DecisionLogger:
    def __init__(
        self,
        hass: HomeAssistant,
        *,
        heartbeat_interval: timedelta = timedelta(minutes=10),
        retention_days: int = 7,
    ) -> None:
        self._store = Store(hass, version=STORAGE_VERSION, key=STORAGE_KEY)
        self._heartbeat_interval = heartbeat_interval
        self._retention_days = retention_days
        self._last_signature: str | None = None
        self._last_logged_at: datetime | None = None
        self._loaded = False

    def should_log(self, entry: DecisionLogEntry, now: datetime) -> bool:
        signature = self._signature(entry)
        if self._last_signature != signature:
            return True
        if self._last_logged_at is None:
            return True
        return (now - self._last_logged_at) >= self._heartbeat_interval

    async def append(self, entry: DecisionLogEntry, now: datetime) -> bool:
        await self._ensure_loaded()
        if not self.should_log(entry, now):
            return False

        cutoff = now - timedelta(days=self._retention_days)
        payload = await self._store.async_load() or {}
        stored_entries = list(payload.get("entries", []))
        entries = [
            existing
            for existing in stored_entries
            if self._timestamp(existing) is not None and self._timestamp(existing) >= cutoff
        ]
        entries.append(entry.__dict__)

        self._last_signature = self._signature(entry)
        self._last_logged_at = now
        await self._store.async_save(
            {
                "entries": entries,
                "last_signature": self._last_signature,
                "last_logged_at": now.isoformat(),
            }
        )
        return True

    async def read_entries(self) -> list[dict[str, Any]]:
        await self._ensure_loaded()
        payload = await self._store.async_load() or {}
        entries = payload.get("entries", [])
        return [dict(entry) for entry in entries if isinstance(entry, dict)]

    async def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        payload = await self._store.async_load() or {}
        if isinstance(payload, dict):
            last_signature = payload.get("last_signature")
            self._last_signature = str(last_signature) if last_signature else None
            last_logged_at = payload.get("last_logged_at")
            if last_logged_at:
                try:
                    self._last_logged_at = datetime.fromisoformat(str(last_logged_at))
                except ValueError:
                    self._last_logged_at = None
        self._loaded = True

    @staticmethod
    def _signature(entry: DecisionLogEntry) -> str:
        return json.dumps(
            {
                "battery_strategy": entry.battery_strategy,
                "battery_reason": entry.battery_reason,
                "ev_should_charge": entry.ev_should_charge,
                "ev_mode": entry.ev_mode,
                "ev_reason": entry.ev_reason,
                "flex_statuses": entry.flex_statuses,
                "decision_summary": entry.decision_summary,
            },
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        )

    @staticmethod
    def _timestamp(payload: dict[str, Any]) -> datetime | None:
        try:
            return datetime.fromisoformat(str(payload.get("timestamp")))
        except (TypeError, ValueError):
            return None

    @staticmethod
    def from_parts(
        *,
        now: datetime,
        battery_plan: Any | None = None,
        ev_plan: Any | None = None,
        flex_plan: Any | None = None,
        decision_summary: str = "",
    ) -> DecisionLogEntry:
        flex_statuses: list[str] = []
        if flex_plan is not None:
            flex_statuses = [decision.status for decision in getattr(flex_plan, "decisions", [])]
        return DecisionLogEntry(
            timestamp=now.isoformat(),
            battery_strategy=getattr(battery_plan, "strategy", None),
            battery_reason=getattr(battery_plan, "reason", None),
            ev_should_charge=getattr(ev_plan, "should_charge", None),
            ev_mode=getattr(ev_plan, "mode", None),
            ev_reason=getattr(ev_plan, "reason", None),
            flex_statuses=flex_statuses,
            decision_summary=decision_summary,
        )
