"""Decision engine - thin priority layer on top of planners and allocation.

Lag: decision
Afhaenger af: planning/base.py, planning/energy_allocator.py, planning/world_snapshot.py
Maa IKKE importere: homeassistant, control/, runtime/

Centrale klasser:
  DecisionEngine: decide() modtager planner-outputs og returnerer en samlet beslutning
  Decision: den endelige beslutning der sendes videre til runtime

Vigtige invarianter:
  - Ingen oekonomiske beregninger i denne fil
  - Decision engine maa kun nedgradere konflikter; aldrig opfinde nye planer
  - Export har altid laveste prioritet
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass

from ..planning.base import BatteryPlan, EVPlan, FlexPlan
from ..planning.energy_allocator import EnergyAllocator
from ..planning.world_snapshot import WorldSnapshot


@dataclass
class Decision:
    battery_plan: BatteryPlan
    ev_plan: EVPlan
    flex_plan: FlexPlan
    reason: str


class DecisionEngine:
    """Apply fixed priority rules to planner outputs."""

    def __init__(self, allocator: EnergyAllocator | None = None) -> None:
        self._allocator = allocator or EnergyAllocator()

    def decide(
        self,
        snapshot: WorldSnapshot,
        battery_plan: BatteryPlan,
        ev_plan: EVPlan,
        flex_plan: FlexPlan,
    ) -> Decision:
        battery = battery_plan
        ev = ev_plan
        notes: list[str] = []

        allocation = self._allocator.allocate(snapshot, battery_plan, ev_plan, flex_plan)
        if allocation.has_conflicts:
            notes.append(allocation.reason)

        if allocation.battery_export_blocked and battery.strategy == "SELL_BATTERY":
            battery = _with_strategy(
                battery,
                "SAVE_SOLAR" if snapshot.power.pv_w > snapshot.power.load_w else "IDLE",
                "Lokal anvendelse har prioritet over eksport",
            )
            notes.append("SELL_BATTERY nedgraderet")

        if allocation.battery_should_wait_for_ev_solar and battery.strategy == "SAVE_SOLAR":
            battery = _with_strategy(
                battery,
                "IDLE",
                "Mobil EV faar aktuel sol; husbatteri kan vente til senere solslot",
            )
            notes.append("Husbatteri venter paa senere sol")

        if allocation.battery_should_wait_for_flex and battery.strategy in {"SAVE_SOLAR", "SELL_BATTERY"}:
            battery = _with_strategy(
                battery,
                "IDLE",
                "Flex GO_NOW bruger lokal energi nu; husbatteriets lokale brug flyttes",
            )
            notes.append("Husbatteri viger for flex")

        if allocation.ev_should_pause_for_battery and ev.should_charge:
            if battery.strategy in {"USE_BATTERY", "SELL_BATTERY"}:
                battery = _with_strategy(
                    battery,
                    "IDLE",
                    "EV deadline-opladning har prioritet; husbatteriet maa ikke drive EV",
                )
                notes.append("Husbatteri sat paa pause for EV")
        if allocation.ev_should_pause_for_flex and ev.should_charge:
            ev = _ev_idle(ev, "EV sat paa pause af prioriteringsregel")
            notes.append("EV sat paa pause")

        if battery.strategy == "ANTI_EXPORT":
            notes.append("ANTI_EXPORT pass-through")

        if not notes:
            notes.append("Ingen konflikter - planer pass-through")

        return Decision(
            battery_plan=battery,
            ev_plan=ev,
            flex_plan=flex_plan,
            reason="; ".join(notes),
        )


def _with_strategy(plan: BatteryPlan, strategy: str, reason: str) -> BatteryPlan:
    return dataclasses.replace(plan, strategy=strategy, reason=reason)


def _ev_idle(plan: EVPlan, reason: str) -> EVPlan:
    return dataclasses.replace(
        plan,
        should_charge=False,
        target_power_w=0.0,
        phases=0,
        reason=reason,
    )
