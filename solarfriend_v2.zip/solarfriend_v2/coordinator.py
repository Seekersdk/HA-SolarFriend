"""SolarFriend V2 coordinator - thin orchestration layer, max ~300 lines.

This file may import every V2 layer, but it must not contain domain logic.
Decision-making belongs in planning/, decision/, control/, and runtime/.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta
import logging
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator

from .config import entry_value, merged_entry_config
from .core.time_utils import now_local, parse_local_or_aware, set_timezone
from .control.charger_interface import ChargerController
from .control.inverter_interface import InverterController
from .control.vehicle_interface import VehicleController
from .decision.engine import Decision, DecisionEngine
from .ingest.ev_state_adapter import normalize_vehicle_state
from .ingest.market_data_reader import (
    current_solar_geometry,
    read_cloud_coverage_pct,
    read_forecast_slots,
    read_price_slots,
    read_sell_price_slots,
    read_sunset_datetime,
)
from .ingest.power_reader import read_power
from .ingest.snapshot_factory import (
    build_battery_snapshot,
    build_consumption_snapshot,
    build_ev_departure,
    build_world_snapshot,
)
from .learning.consumption_model import ConsumptionModel, FeatureConfig
from .learning.consumption_observation_buffer import ConsumptionObservationBuffer
from .learning.forecast_pipeline import SolarForecastPipeline
from .learning.solar_profile import SolarProfile
from .observability.decision_logger import DecisionLogger
from .observability.model_evaluation import EvaluationRow, EvaluationSummary, ModelEvaluation
from .planning.battery_planner import BatteryPlanner
from .planning.base import FlexLoad
from .planning.ev_planner import EVPlanner
from .planning.flex_planner import FlexPlanner
from .planning.world_snapshot import BatterySnapshot, ConsumptionProfileSnapshot, WorldSnapshot
from .presentation.models import PresentationState
from .runtime.battery_runtime import BatteryRuntime
from .runtime.battery_tracker import BatteryTracker
from .runtime.checkpoint import Checkpoint
from .runtime.ev_runtime import EVRuntime
from .runtime.flex_runtime import FlexRuntime
from .runtime.flex_queue_store import deserialize_flex_loads, serialize_flex_loads
from .runtime.models import RuntimeApplyResult
from .runtime.readiness_gate import required_input_issues
from .runtime.state_serializer import (
    restore_battery_runtime_state,
    restore_ev_runtime_state,
    serialize_battery_runtime_state,
    serialize_ev_runtime_state,
)

_LOGGER = logging.getLogger(__name__)

UPDATE_INTERVAL = timedelta(seconds=30)


class SolarFriendCoordinator(DataUpdateCoordinator[PresentationState]):
    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        super().__init__(hass, _LOGGER, name="solarfriend_v2", update_interval=UPDATE_INTERVAL)
        self.config_entry = entry
        self._checkpoint = Checkpoint(hass)
        self.presentation_state: PresentationState | None = None

        # Runtime settings mirrored by HA entities later in phase 10.
        self.ev_charge_mode = entry_value(entry, "ev_charge_mode", "solar_only")
        self.ev_departure_time = None
        self.ev_target_soc_override: float | None = (
            float(entry_value(entry, "ev_target_soc_override", 80.0))
            if entry_value(entry, "ev_target_soc_override", 80.0) is not None
            else None
        )
        self.ev_min_range_km: float = float(entry_value(entry, "ev_min_range_km", 0.0) or 0.0)
        self.ev_charging_allowed: bool = True
        self.ev_solar_only_grid_buffer_enabled: bool = bool(
            entry_value(entry, "ev_solar_only_grid_buffer_enabled", True)
        )
        self.control_enabled: bool = bool(entry_value(entry, "control_enabled", False))
        self.battery_sell_enabled: bool = bool(entry_value(entry, "battery_sell_enabled", True))
        self.advanced_consumption_model_enabled: bool = bool(
            entry_value(entry, "advanced_consumption_model_enabled", False)
        )

        self._consumption = ConsumptionModel(FeatureConfig())
        self._consumption_observations = ConsumptionObservationBuffer(retention_days=14, bucket_minutes=10)
        self._solar_profile = SolarProfile()
        self._forecast_pipeline = SolarForecastPipeline(self._solar_profile)
        self._battery_tracker = BatteryTracker(float(entry_value(entry, "battery_cost_per_kwh", 0.30)))
        self._battery_planner = BatteryPlanner()
        self._ev_planner = EVPlanner()
        self._flex_planner = FlexPlanner()
        self._decision_engine = DecisionEngine()
        self._flex_loads: list[FlexLoad] = []

        self._inverter: InverterController | None = None
        self._charger: ChargerController | None = None
        self._vehicle: VehicleController | None = None
        self._battery_runtime: BatteryRuntime | None = None
        self._ev_runtime: EVRuntime | None = None
        self._flex_runtime: FlexRuntime | None = None
        self._decision_logger: DecisionLogger | None = None
        self._model_evaluation: ModelEvaluation | None = None
        self._model_evaluation_summary: EvaluationSummary | None = None
        self._last_flex_clear_date = None

    async def async_startup(self) -> None:
        set_timezone(self.hass.config.time_zone)
        await self.async_setup()
        await self._async_restore_state()

    async def async_setup(self) -> None:
        """Load checkpoints and wire up controllers."""
        self._inverter = InverterController.from_config(self.hass, self.config_entry)
        self._charger = ChargerController.from_config(self.hass, self.config_entry)
        self._vehicle = VehicleController.from_config(self.hass, self.config_entry)
        self._battery_runtime = BatteryRuntime(self._inverter)
        self._ev_runtime = EVRuntime(self._charger, self._vehicle)
        self._flex_runtime = FlexRuntime(self.hass)
        self._decision_logger = DecisionLogger(self.hass)
        self._model_evaluation = ModelEvaluation(self.hass)
        self._consumption.advanced_enabled = self.advanced_consumption_model_enabled
        self._battery_tracker.battery_cost_per_kwh = float(entry_value(self.config_entry, "battery_cost_per_kwh", 0.30))

    async def async_on_runtime_setting_changed(self, *, reason: str) -> None:
        _LOGGER.debug("Runtime setting changed: %s", reason)
        self._consumption.advanced_enabled = self.advanced_consumption_model_enabled
        await self.async_request_refresh()

    async def async_force_populate_load_model(self, *, days: int = 14) -> int:
        _LOGGER.info(
            "Populate load model requested for %s days, but full HA history wiring is not implemented yet",
            days,
        )
        return 0

    async def async_reset_advanced_consumption_model(self) -> int:
        self._consumption.reset_advanced_model()
        replayed = self._consumption.replay_advanced_observations(
            [
                {
                    "timestamp": sample.timestamp,
                    "household_load_w": sample.household_load_w,
                    "outdoor_temp_c": sample.outdoor_temp_c,
                    "indoor_temp_c": sample.indoor_temp_c,
                }
                for sample in self._consumption_observations.observations()
            ]
        )
        await self.async_persist_state()
        _LOGGER.info("Reset advanced consumption model and replayed %s buffered observations", replayed)
        return replayed

    async def async_reset_battery_tracker(self) -> int:
        self._battery_tracker.reset_state()
        await self.async_persist_state()
        _LOGGER.info("Reset battery tracker state")
        return 1

    async def async_persist_state(self) -> None:
        await self._checkpoint.save("consumption_simple", self._consumption.simple.get_state())
        await self._checkpoint.save("consumption_advanced", self._consumption.advanced.get_state())
        await self._checkpoint.save("consumption_observations", self._consumption_observations.get_state())
        await self._checkpoint.save("solar_profile", self._solar_profile.get_state())
        await self._checkpoint.save("flex_queue", serialize_flex_loads(self._flex_loads))
        await self._checkpoint.save("battery_runtime", serialize_battery_runtime_state(self._battery_runtime))
        await self._checkpoint.save("ev_runtime", serialize_ev_runtime_state(self._ev_runtime))
        await self._checkpoint.save("battery_tracker", self._battery_tracker.get_state())

    def unregister_listeners(self) -> None:
        return None

    async def _async_update_data(self) -> PresentationState:
        """Read ingest state, run planners/decision/runtime, and build presentation state."""
        if self._battery_runtime is None or self._ev_runtime is None:
            await self.async_setup()

        now = now_local()
        charger_state, vehicle_state = await self._sync_ev_state()
        power = await read_power(self.hass, merged_entry_config(self.config_entry))
        power = self._normalize_ev_power(power, charger_state)
        sunset_datetime = read_sunset_datetime(self.hass, now)
        await self._maybe_clear_flex_queue_at_sunset(now, sunset_datetime)

        self._consumption.advanced_enabled = self.advanced_consumption_model_enabled
        self._observe_consumption(power, now)
        prediction = self._consumption.build_prediction_snapshot(
            now.hour,
            now.weekday() >= 5,
            self._consumption_context(now),
        )
        forecast = read_forecast_slots(self.hass, self.config_entry, now)
        solar_elevation_deg, solar_azimuth_deg = current_solar_geometry(self.hass)
        cloud_coverage_pct = read_cloud_coverage_pct(self.hass, self.config_entry)
        self._forecast_pipeline.observe_current_slot(
            reading=power,
            now=now,
            forecast=forecast,
            solar_elevation_deg=solar_elevation_deg,
            solar_azimuth_deg=solar_azimuth_deg,
            cloud_coverage_pct=cloud_coverage_pct,
        )
        forecast = self._forecast_pipeline.correct_forecast(
            forecast,
            latitude=getattr(self.hass.config, "latitude", None),
            longitude=getattr(self.hass.config, "longitude", None),
        )

        normalized_vehicle_state = normalize_vehicle_state(
            vehicle_state,
            charger_state,
            target_soc_override=self.ev_target_soc_override,
        )
        snapshot = build_world_snapshot(
            now=now,
            power=power,
            battery=build_battery_snapshot(
                tracker=self._battery_tracker,
                config_entry=self.config_entry,
                read_float_state=self._read_float_state,
            ),
            prices=read_price_slots(self.hass, self.config_entry, now),
            sell_prices=read_sell_price_slots(self.hass, self.config_entry, now),
            forecast=forecast,
            consumption=build_consumption_snapshot(self._consumption),
            ev=normalized_vehicle_state,
            charger=self._normalize_charger_state(charger_state),
            flex_loads=self._flex_loads,
            ev_departure=build_ev_departure(now, self.ev_departure_time),
            sunset_datetime=sunset_datetime,
            ev_mode=self.ev_charge_mode,
            ev_max_charge_kw=float(entry_value(self.config_entry, "ev_max_charge_kw", 11.0)),
            ev_min_range_km=float(self.ev_min_range_km or 0.0),
            cloud_coverage_pct=cloud_coverage_pct,
            solar_elevation_deg=solar_elevation_deg,
            solar_azimuth_deg=solar_azimuth_deg,
            config_entry=self.config_entry,
            battery_sell_enabled=self.battery_sell_enabled,
            ev_charging_enabled=self.ev_charging_allowed,
        )
        track2_current_factor = None
        track2_current_confidence = None
        if solar_elevation_deg is not None and solar_azimuth_deg is not None:
            (
                track2_current_factor,
                track2_current_confidence,
            ) = self._solar_profile.get_factor_with_confidence(
                solar_elevation_deg,
                solar_azimuth_deg,
            )

        battery_plan = self._battery_planner.plan(snapshot)
        ev_plan = self._ev_planner.plan(snapshot)
        flex_plan = self._flex_planner.plan(snapshot)
        if self._flex_runtime is not None:
            flex_plan = (await self._flex_runtime.sanitize(flex_plan, now)).plan
        decision = self._decision_engine.decide(snapshot, battery_plan, ev_plan, flex_plan)
        input_issues = await required_input_issues(
            self.hass,
            self.config_entry,
            snapshot,
            control_enabled=self.control_enabled,
            inverter=self._inverter,
            charger=self._charger,
            vehicle=self._vehicle,
        )

        if self.control_enabled and input_issues:
            gate_reason = f"Startup gate: missing inputs ({', '.join(input_issues)})"
            battery_result = RuntimeApplyResult(applied=False, changed=False, reason=gate_reason)
            ev_result = RuntimeApplyResult(applied=False, changed=False, reason=gate_reason)
        elif self.control_enabled:
            battery_result = await self._battery_runtime.apply(decision.battery_plan, snapshot)
            ev_result = await self._ev_runtime.apply(decision.ev_plan, snapshot)
        else:
            battery_result = RuntimeApplyResult(
                applied=False,
                changed=False,
                reason=f"Control disabled: would apply {decision.battery_plan.strategy}",
            )
            ev_target = "start" if decision.ev_plan.should_charge else "pause"
            ev_result = RuntimeApplyResult(
                applied=False,
                changed=False,
                reason=f"Control disabled: would {ev_target} EV ({decision.ev_plan.mode})",
            )
        self._battery_tracker.update(
            now=now,
            pv_w=power.pv_w,
            load_w=power.load_w,
            battery_w=power.battery_w,
            battery_soc_pct=snapshot.battery.soc_pct,
            battery_capacity_kwh=snapshot.battery.capacity_kwh,
            battery_min_soc_pct=snapshot.battery.min_soc_pct,
            current_price_dkk=snapshot.prices[0].price_dkk if snapshot.prices else 0.0,
            sell_price_dkk=snapshot.sell_prices[0].sell_price_dkk if snapshot.sell_prices else 0.0,
            active_strategy=decision.battery_plan.strategy,
            load_is_trustworthy=decision.battery_plan.strategy != "SELL_BATTERY",
        )
        needs_replan = self._battery_runtime.should_replan(snapshot) if self.control_enabled else False
        runtime_health = self._runtime_health(snapshot, battery_result, ev_result, needs_replan, input_issues)

        state = PresentationState(
            decision=decision,
            snapshot=snapshot,
            consumption_prediction=prediction,
            solar_profile_snapshot=self._solar_profile.build_snapshot(),
            track2_current_factor=track2_current_factor,
            track2_current_confidence=track2_current_confidence,
            battery_tracker_state=self._battery_tracker.state,
            battery_runtime_result=battery_result,
            ev_runtime_result=ev_result,
            runtime_health=runtime_health,
            last_successful_update=now,
            realized_savings_today=self._realized_savings_today(),
            realized_savings_total=self._realized_savings_total(),
            model_evaluation_summary=self._model_evaluation_summary,
        )
        self.presentation_state = state
        await self._append_decision_log(now, battery_plan, ev_plan, flex_plan, decision.reason)
        await self._append_model_evaluation(now, state)
        await self.async_persist_state()
        return state

    async def _async_restore_state(self) -> None:
        simple_state = await self._checkpoint.load("consumption_simple")
        if simple_state:
            self._consumption.simple.set_state(simple_state)

        advanced_state = await self._checkpoint.load("consumption_advanced")
        if advanced_state:
            self._consumption.advanced.set_state(advanced_state)

        observation_state = await self._checkpoint.load("consumption_observations")
        if observation_state:
            self._consumption_observations.set_state(observation_state)

        solar_profile_state = await self._checkpoint.load("solar_profile")
        if solar_profile_state:
            self._solar_profile.set_state(solar_profile_state)

        flex_state = await self._checkpoint.load("flex_queue")
        self._flex_loads = deserialize_flex_loads(flex_state or {})

        battery_runtime_state = await self._checkpoint.load("battery_runtime")
        if battery_runtime_state:
            restore_battery_runtime_state(self._battery_runtime, battery_runtime_state)

        ev_runtime_state = await self._checkpoint.load("ev_runtime")
        if ev_runtime_state:
            restore_ev_runtime_state(self._ev_runtime, ev_runtime_state)

        battery_tracker_state = await self._checkpoint.load("battery_tracker")
        if battery_tracker_state:
            self._battery_tracker.set_state(battery_tracker_state)

    async def _sync_ev_state(self):
        charger_state, vehicle_state = await self._ev_runtime.sync_state()
        if not self._charger.is_configured:
            charger_state = None
        if not self._vehicle.is_configured:
            vehicle_state = None
        return charger_state, vehicle_state

    def _normalize_ev_power(self, power, charger_state):
        ev_w = charger_state.power_w if charger_state is not None and charger_state.charging else 0.0
        load_w = power.load_w
        if entry_value(self.config_entry, "load_sensor_is_total_load", False):
            load_w = max(0.0, load_w - ev_w)
        return replace(power, load_w=load_w, ev_w=ev_w, timestamp=power.timestamp or now_local())

    def _observe_consumption(self, power, now: datetime) -> None:
        context = self._consumption_context(now)
        self._consumption.observe(power, context)
        self._consumption_observations.observe(power, context)

    def _consumption_context(self, now: datetime) -> dict[str, Any]:
        return {
            "timestamp": now,
            "hour": now.hour,
            "weekday": now.weekday(),
            "is_weekend": now.weekday() >= 5,
            "outdoor_temp_c": self._read_float_state(entry_value(self.config_entry, "outdoor_temp_entity")),
            "indoor_temp_c": self._read_float_state(entry_value(self.config_entry, "indoor_temp_entity")),
        }

    def _normalize_charger_state(self, charger_state):
        return charger_state

    def _runtime_health(
        self,
        snapshot: WorldSnapshot,
        battery_result,
        ev_result,
        needs_replan: bool,
        input_issues: list[str],
    ) -> str:
        if input_issues:
            return "missing_inputs"
        if not snapshot.prices or not snapshot.forecast:
            return "degraded"
        if needs_replan:
            return "replan_requested"
        if "cooldown" in battery_result.reason.lower() or "cooldown" in ev_result.reason.lower():
            return "stable_cooldown"
        return "ok"

    def _realized_savings_today(self) -> float | None:
        tracker = self._battery_tracker.state
        return round(
            tracker.today_solar_direct_saved_dkk
            + tracker.today_optimizer_saved_dkk
            + tracker.today_battery_sell_saved_dkk,
            4,
        )

    def _realized_savings_total(self) -> float | None:
        tracker = self._battery_tracker.state
        return round(
            tracker.total_solar_direct_saved_dkk
            + tracker.total_optimizer_saved_dkk
            + tracker.total_battery_sell_saved_dkk
            + tracker.today_solar_direct_saved_dkk
            + tracker.today_optimizer_saved_dkk
            + tracker.today_battery_sell_saved_dkk,
            4,
        )

    def _read_float_state(self, entity_id: str | None, default: float = 0.0) -> float:
        if not entity_id:
            return default
        state = self.hass.states.get(entity_id)
        if state is None or state.state in ("unknown", "unavailable", ""):
            return default
        try:
            return float(state.state)
        except (TypeError, ValueError):
            return default

    async def _maybe_clear_flex_queue_at_sunset(
        self,
        now: datetime,
        sunset_datetime: datetime | None,
    ) -> None:
        if not self._flex_loads or sunset_datetime is None:
            return
        sunset_date = sunset_datetime.date()
        if now < sunset_datetime:
            return
        if self._last_flex_clear_date == sunset_date:
            return
        self._flex_loads = []
        self._last_flex_clear_date = sunset_date
        await self._checkpoint.delete("flex_queue")
        _LOGGER.info("Cleared pending flex queue at sunset: %s", sunset_datetime.isoformat())

    async def _append_decision_log(
        self,
        now: datetime,
        battery_plan,
        ev_plan,
        flex_plan,
        decision_summary: str,
    ) -> None:
        if not entry_value(self.config_entry, "shadow_log_enabled", False):
            return
        if self._decision_logger is None:
            return
        try:
            entry = DecisionLogger.from_parts(
                now=now,
                battery_plan=battery_plan,
                ev_plan=ev_plan,
                flex_plan=flex_plan,
                decision_summary=decision_summary,
            )
            await self._decision_logger.append(entry, now)
        except Exception as exc:  # noqa: BLE001
            _LOGGER.debug("Decision log append failed: %s", exc)

    async def _append_model_evaluation(
        self,
        now: datetime,
        state: PresentationState,
    ) -> None:
        if self._model_evaluation is None or state.solar_profile_snapshot is None:
            return
        try:
            for row in state.solar_profile_snapshot.comparison_today:
                period_start = parse_local_or_aware(str(row.get("period_start", "")))
                actual_kwh = self._coerce_float(row.get("faktisk_kwh"))
                solcast_kwh = self._coerce_float(row.get("solcast_kwh"))
                track2_kwh = self._coerce_float(row.get("beregnet_kwh"))
                empirical_kwh = self._coerce_float(row.get("empirisk_kwh"))
                if (
                    period_start is None
                    or period_start > now
                    or actual_kwh is None
                    or solcast_kwh is None
                    or actual_kwh <= 0
                    or solcast_kwh <= 0
                ):
                    continue
                models: dict[str, float] = {"solcast": solcast_kwh}
                if empirical_kwh is not None:
                    models["empirisk"] = empirical_kwh
                if track2_kwh is not None:
                    models[f"track2_{state.solar_profile_snapshot.active_resolution_key}"] = track2_kwh
                await self._model_evaluation.append(
                    EvaluationRow(
                        period_start=period_start.isoformat(),
                        actual_kwh=actual_kwh,
                        models=models,
                    )
                )
            self._model_evaluation_summary = await self._model_evaluation.summarize_month(
                ModelEvaluation.month_key(now)
            )
        except Exception as exc:  # noqa: BLE001
            _LOGGER.debug("Model evaluation update failed: %s", exc)

    @staticmethod
    def _coerce_float(value: Any) -> float | None:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
