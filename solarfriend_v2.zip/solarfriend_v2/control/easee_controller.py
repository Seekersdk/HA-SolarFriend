"""Easee charger controller."""
from __future__ import annotations

from typing import Any

from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

from ..config import entry_value
from ..core.types import ChargerState
from .charger_interface import ChargerController

VOLTAGE = 235.0
MIN_AMPS = 6.0
MAX_AMPS = 16.0

EASEE_STATUS_MAP = {
    "disconnected": "disconnected",
    "awaiting_start": "connected",
    "ready_to_charge": "connected",
    "charging": "charging",
    "completed": "connected",
    "error": "error",
}


class EaseeController(ChargerController):
    def __init__(self, hass: Any, config_entry: Any) -> None:
        self._hass = hass
        self._status_entity = entry_value(config_entry, "ev_charger_status_entity")
        self._power_entity = entry_value(config_entry, "ev_charger_power_entity")
        self._charger_id = entry_value(config_entry, "ev_charger_id")
        self._resolved_device_id: str | None = None

    @property
    def is_configured(self) -> bool:
        return bool(self._status_entity or self._charger_id)

    def _service_device_id(self) -> str | None:
        if self._resolved_device_id:
            return self._resolved_device_id

        entity_registry = er.async_get(self._hass)
        if self._status_entity:
            entry = entity_registry.async_get(self._status_entity)
            if entry and entry.device_id:
                self._resolved_device_id = entry.device_id
                return self._resolved_device_id

        if not self._charger_id:
            return None

        device_registry = dr.async_get(self._hass)
        if device_registry.async_get(self._charger_id) is not None:
            self._resolved_device_id = self._charger_id
            return self._resolved_device_id
        return None

    async def set_power(self, watts: int, phases: int) -> None:
        device_id = self._service_device_id()
        if not device_id:
            return
        if phases == 3:
            amps = max(MIN_AMPS, min(MAX_AMPS, round(watts / 3 / VOLTAGE, 1)))
            data = {
                "device_id": device_id,
                "current_p1": amps,
                "current_p2": amps,
                "current_p3": amps,
            }
        else:
            amps = max(MIN_AMPS, min(MAX_AMPS, round(watts / VOLTAGE, 1)))
            data = {
                "device_id": device_id,
                "current_p1": amps,
                "current_p2": 0,
                "current_p3": 0,
            }
        await self._hass.services.async_call(
            "easee",
            "set_circuit_dynamic_limit",
            data,
            blocking=True,
        )

    async def pause(self) -> None:
        device_id = self._service_device_id()
        if not device_id:
            return
        await self._hass.services.async_call(
            "easee",
            "action_command",
            {"device_id": device_id, "action_command": "pause"},
            blocking=True,
        )

    async def resume(self) -> None:
        device_id = self._service_device_id()
        if not device_id:
            return
        await self._hass.services.async_call(
            "easee",
            "action_command",
            {"device_id": device_id, "action_command": "resume"},
            blocking=True,
        )

    async def get_state(self) -> ChargerState:
        status_state = self._hass.states.get(self._status_entity) if self._status_entity else None
        power_state = self._hass.states.get(self._power_entity) if self._power_entity else None

        if status_state is None or status_state.state in ("unknown", "unavailable"):
            return ChargerState(connected=False, charging=False, power_w=0.0, phases=0)

        power_w = 0.0
        try:
            if power_state is not None:
                value = float(power_state.state)
                unit = str(power_state.attributes.get("unit_of_measurement", "")).lower()
                power_w = value * 1000.0 if unit == "kw" else value
        except (ValueError, TypeError):
            power_w = 0.0

        normalized = EASEE_STATUS_MAP.get(status_state.state, "error")
        connected = normalized in {"connected", "charging"}
        charging = normalized == "charging" or power_w > 50
        phases = 3 if power_w >= 4000 else (1 if charging else 0)
        return ChargerState(
            connected=connected,
            charging=charging,
            power_w=power_w,
            phases=phases,
        )
