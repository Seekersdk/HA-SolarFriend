# Control Validation

Denne guide er til den første manuelle validering mod rigtig hardware.

## Mål

Bekræft at V2-strategierne betyder det samme i praksis, som de gør i planning/decision/control.

## Før Start

- Brug en test-entry i Home Assistant.
- Sørg for at alle relevante entities opdaterer stabilt.
- Start med `shadow_log_enabled=true`.
- Hav developer tools åbne for states og service calls.

## Deye

Kontroller disse strategier én ad gangen:

- `SAVE_SOLAR`
  - batteriet må ikke aflade til huset
  - discharge current skal være `0A` eller tilsvarende disable
  - PV må stadig kunne lade batteriet ved ægte overskud

- `USE_BATTERY`
  - discharge skal være tilladt
  - solar sell skal være `off`
  - huset må kunne forsynes af batteriet ved restunderskud

- `SELL_BATTERY`
  - discharge skal være tilladt
  - solar sell skal være `on`
  - eksport må være mulig

- `CHARGE_GRID` / `CHARGE_NIGHT`
  - grid charge skal være tilladt
  - solar sell skal være `off`
  - target SOC skal matche planen

- `ANTI_EXPORT`
  - eksport skal være blokeret
  - verificer at inverteren ikke fortsætter med at sælge på default-adfærd

- `IDLE`
  - verificer hvad inverteren faktisk gør
  - hvis default-adfærd giver skjult discharge, er `IDLE` semantisk forkert og skal strammes

## EV Charger

Kontroller disse scenarier:

- `solar_only`
  - opladning starter først når runtime-hysterese siger ja
  - små PV-sving må ikke give flapping
  - grid buffer må give mere smooth power-regulering

- `hybrid`
  - EV må gerne fortsætte mod deadline
  - flex `GO_NOW` skal stadig kunne pause eller nedprioritere EV, hvis det er besluttet

- `grid_only`
  - EV må kunne oplade uden kamp om lokal sol
  - lokal energiprioritet må ikke utilsigtet blokere ren grid-ladning

## Prioritetschecks

Bekræft mindst disse konflikter i praksis:

- `flex GO_NOW` over EV `solar_only`
- `flex GO_NOW` over flytbar husbatteri-brug
- `SELL_BATTERY` taber mod lokal anvendelse
- `SAVE_SOLAR` betyder ingen discharge

## Hvad Der Skal Logges

For hver test:

- ønsket strategi fra planner/decision
- faktisk anvendt runtime-strategi
- konkrete service calls eller payloads
- observeret inverter-/lader-adfærd
- om resultatet matcher semantikken

## Exit-Kriterier

Valideringen er god nok når:

- alle kernestrategier giver forventet hardware-adfærd
- ingen strategi afhænger af “heldig” vendor-default
- EV runtime er stabil under små live-sving
- mindst én hel dagscyklus ser rigtig ud: morgen, solmidte, aften
