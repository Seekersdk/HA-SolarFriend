# Control Semantics

This layer defines what the shared battery strategies mean on real hardware.
Planning decides *which* strategy is active. Control decides *how* that strategy
is translated to vendor-specific commands.

## Battery Strategies

| Strategy | Meaning in control |
|----------|--------------------|
| `SAVE_SOLAR` | Battery must not discharge to the house. Direct solar covers local load first. Only real surplus solar may charge the battery. |
| `IDLE` | Neutral/default inverter state. Restore normal discharge limit and disable explicit charge/export forcing. |
| `USE_BATTERY` | Battery may discharge for local consumption. Export remains disabled. |
| `SELL_BATTERY` | Battery may discharge and export is explicitly enabled. |
| `CHARGE_GRID` | Charge now from grid until `target_soc_pct`. |
| `CHARGE_NIGHT` | Charge from grid in the next cheap window until `target_soc_pct`. |
| `ANTI_EXPORT` | Export must be disabled. This is not the same as `SAVE_SOLAR`. |
| `NEGATIVE_IMPORT` | Battery discharge is blocked so the house can import from grid. |

## Vendor Rule

Each inverter gets its own file and maps the shared semantics to its own
entities, services, and payload shape. `control/` must never make economic or
strategic decisions.
