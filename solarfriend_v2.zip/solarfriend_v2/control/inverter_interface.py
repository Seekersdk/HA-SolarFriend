"""Abstract inverter controller interface.

Lag: control
Afhaenger af: planning/base.py
Maa IKKE importere: learning/, decision/, runtime/

Centrale klasser:
  InverterController: abstract base for all inverter vendors
  NullInverterController: no-op fallback when no inverter is configured

Tilfoej ny inverter:
  1. Opret fx control/victron_controller.py
  2. Implementer InverterController
  3. Registrer typen i from_config()

Vigtige invarianter:
  - apply_plan() skal vaere idempotent paa fuldt payload
  - control-laget maa kun oversaette planer til hardware
  - SAVE_SOLAR skal kunne mappes til "ingen afladning"
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..config import entry_value
from ..planning.base import BatteryPlan


class InverterController(ABC):
    @property
    def is_configured(self) -> bool:
        return True

    @abstractmethod
    async def apply_plan(self, plan: BatteryPlan) -> None:
        """Translate a BatteryPlan into inverter commands."""
        ...

    @abstractmethod
    async def is_available(self) -> bool:
        ...

    @classmethod
    def from_config(cls, hass: Any, config_entry: Any) -> "InverterController":
        from .deye_controller import DeyeController

        inverter_type = entry_value(config_entry, "inverter_type", "none")
        if inverter_type in {"deye", "deye_klatremis"}:
            return DeyeController(hass, config_entry)
        return NullInverterController()


class NullInverterController(InverterController):
    @property
    def is_configured(self) -> bool:
        return False

    async def apply_plan(self, plan: BatteryPlan) -> None:
        return None

    async def is_available(self) -> bool:
        return False
