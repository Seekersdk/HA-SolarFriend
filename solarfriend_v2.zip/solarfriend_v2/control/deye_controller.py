"""Deye inverter controller.

Maps BatteryPlan strategies to concrete Home Assistant service calls.
No planning, arbitration, or hysteresis belongs here.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from ..config import entry_value
from ..planning.base import BatteryPlan
from .inverter_interface import InverterController


@dataclass(frozen=True)
class _Payload:
    solar_sell: bool
    grid_charge: bool
    time_of_use: bool
    time_point_enable: bool
    time_point_start: int | None
    time_point_capacity: float | None
    charge_current: float | None
    max_discharge_current: float | None
    energy_priority: str | None
    limit_control_mode: str | None


class DeyeController(InverterController):
    _REQUIRED_ENTITY_FIELDS = (
        "_grid_charge",
        "_time_of_use",
        "_tp1_enable",
        "_energy_priority",
        "_limit_control_mode",
    )

    def __init__(self, hass: Any, config_entry: Any) -> None:
        self.hass = hass
        self._grid_charge = entry_value(config_entry, "deye_grid_charge_switch")
        self._time_of_use = entry_value(config_entry, "deye_time_of_use_switch")
        self._tp1_enable = entry_value(config_entry, "deye_time_point_1_enable")
        self._tp1_start = entry_value(config_entry, "deye_time_point_1_start")
        self._tp1_capacity = entry_value(config_entry, "deye_time_point_1_capacity")
        self._charge_current = entry_value(config_entry, "deye_grid_charge_current")
        self._max_battery_discharge_current = entry_value(config_entry, "deye_max_battery_discharge_current")
        self._default_battery_discharge_current = float(
            entry_value(config_entry, "deye_default_battery_discharge_current", 0.0)
        )
        self._energy_priority = entry_value(config_entry, "deye_energy_priority")
        self._limit_control_mode = entry_value(config_entry, "deye_limit_control_mode")
        self._solar_sell = entry_value(config_entry, "solar_sell_entity")
        self._battery_min_soc = float(entry_value(config_entry, "battery_min_soc", 10.0))

        self._last_payload: _Payload | None = None

    @property
    def is_configured(self) -> bool:
        return all(getattr(self, field) for field in self._REQUIRED_ENTITY_FIELDS)

    async def apply_plan(self, plan: BatteryPlan) -> None:
        payload = self._build_payload(plan)
        if payload == self._last_payload:
            return

        await self._apply_payload(payload)
        self._last_payload = payload

    async def is_available(self) -> bool:
        return self.is_configured

    def _build_payload(self, plan: BatteryPlan) -> _Payload:
        strategy = plan.strategy
        target_soc = float(int(plan.target_soc_pct)) if plan.target_soc_pct is not None else 80.0
        default_discharge = self._default_battery_discharge_current
        min_soc = float(int(self._battery_min_soc))

        if strategy == "SELL_BATTERY":
            sell_stop_soc = (
                float(int(plan.export_stop_soc_pct))
                if plan.export_stop_soc_pct is not None
                else min_soc
            )
            return _Payload(
                solar_sell=True,
                grid_charge=False,
                time_of_use=True,
                time_point_enable=True,
                time_point_start=self._current_hhmm(),
                time_point_capacity=sell_stop_soc,
                charge_current=None,
                max_discharge_current=default_discharge,
                energy_priority="Load first",
                limit_control_mode="Selling first",
            )

        if strategy == "USE_BATTERY":
            return _Payload(
                solar_sell=False,
                grid_charge=False,
                time_of_use=True,
                time_point_enable=True,
                time_point_start=self._current_hhmm(),
                time_point_capacity=min_soc,
                charge_current=None,
                max_discharge_current=default_discharge,
                energy_priority="Load first",
                limit_control_mode="Zero export to CT",
            )

        if strategy in {"CHARGE_GRID", "CHARGE_NIGHT"}:
            start = self._current_hhmm()
            if strategy == "CHARGE_NIGHT":
                start = self._hhmm_or_none(plan.next_cheap_window)
            return _Payload(
                solar_sell=False,
                grid_charge=True,
                time_of_use=True,
                time_point_enable=True,
                time_point_start=start,
                time_point_capacity=target_soc,
                charge_current=25.0,
                max_discharge_current=default_discharge,
                energy_priority="Battery first",
                limit_control_mode="Zero export to CT",
            )

        if strategy == "NEGATIVE_IMPORT":
            return _Payload(
                solar_sell=False,
                grid_charge=False,
                time_of_use=False,
                time_point_enable=False,
                time_point_start=None,
                time_point_capacity=None,
                charge_current=None,
                max_discharge_current=0.0,
                energy_priority="Load first",
                limit_control_mode="Zero export to load",
            )

        if strategy == "SAVE_SOLAR":
            return _Payload(
                solar_sell=False,
                grid_charge=False,
                time_of_use=False,
                time_point_enable=False,
                time_point_start=None,
                time_point_capacity=None,
                charge_current=None,
                max_discharge_current=0.0,
                energy_priority="Load first",
                limit_control_mode="Zero export to CT",
            )

        if strategy in {"ANTI_EXPORT", "IDLE"}:
            return _Payload(
                solar_sell=False,
                grid_charge=False,
                time_of_use=False,
                time_point_enable=False,
                time_point_start=None,
                time_point_capacity=None,
                charge_current=None,
                max_discharge_current=default_discharge,
                energy_priority="Load first",
                limit_control_mode="Zero export to CT",
            )

        return _Payload(
            solar_sell=False,
            grid_charge=False,
            time_of_use=False,
            time_point_enable=False,
            time_point_start=None,
            time_point_capacity=None,
            charge_current=None,
            max_discharge_current=default_discharge,
            energy_priority="Load first",
            limit_control_mode="Zero export to CT",
        )

    async def _apply_payload(self, payload: _Payload) -> None:
        await self._set_switch(self._solar_sell, payload.solar_sell)
        await self._set_switch(self._grid_charge, payload.grid_charge)
        await self._set_switch(self._time_of_use, payload.time_of_use)
        await self._set_switch(self._tp1_enable, payload.time_point_enable)
        await self._set_number(self._tp1_start, payload.time_point_start)
        await self._set_number(self._tp1_capacity, payload.time_point_capacity)
        await self._set_number(self._charge_current, payload.charge_current)
        await self._set_number(
            self._max_battery_discharge_current,
            payload.max_discharge_current,
        )
        await self._set_select(self._energy_priority, payload.energy_priority)
        await self._set_select(self._limit_control_mode, payload.limit_control_mode)

    async def _set_switch(self, entity_id: str | None, enabled: bool) -> None:
        if not entity_id:
            return
        await self.hass.services.async_call(
            "switch",
            "turn_on" if enabled else "turn_off",
            {"entity_id": entity_id},
            blocking=True,
        )

    async def _set_number(self, entity_id: str | None, value: float | int | None) -> None:
        if not entity_id or value is None:
            return
        await self.hass.services.async_call(
            "number",
            "set_value",
            {"entity_id": entity_id, "value": float(value)},
            blocking=True,
        )

    async def _set_select(self, entity_id: str | None, option: str | None) -> None:
        if not entity_id or option is None:
            return
        await self.hass.services.async_call(
            "select",
            "select_option",
            {"entity_id": entity_id, "option": option},
            blocking=True,
        )

    @staticmethod
    def _current_hhmm() -> int:
        now = datetime.now()
        return now.hour * 100 + now.minute

    @staticmethod
    def _hhmm_or_none(value: datetime | None) -> int | None:
        if value is None:
            return None
        return value.hour * 100 + value.minute
