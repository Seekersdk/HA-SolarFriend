"""Abstract vehicle controller interface."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..config import entry_value
from ..core.types import EVState


class VehicleController(ABC):
    @property
    def is_configured(self) -> bool:
        return True

    @abstractmethod
    async def get_state(self) -> EVState:
        ...

    @classmethod
    def from_config(cls, hass: Any, config_entry: Any) -> "VehicleController":
        vehicle_type = entry_value(config_entry, "vehicle_type", "none")
        if vehicle_type == "kia_hyundai":
            from .kia_controller import KiaController

            return KiaController(hass, config_entry)
        if vehicle_type == "manual":
            return ManualVehicleController(hass, config_entry)
        return NullVehicleController()


class ManualVehicleController(VehicleController):
    def __init__(self, hass: Any, config_entry: Any) -> None:
        self._hass = hass
        self._soc_entity = entry_value(config_entry, "vehicle_soc_entity")
        self._plugged_in_entity = entry_value(config_entry, "vehicle_plugged_in_entity")
        self._target_soc_entity = entry_value(config_entry, "vehicle_target_soc_entity")
        self._range_entity = entry_value(config_entry, "vehicle_range_entity")
        self._battery_kwh = float(
            entry_value(
                config_entry,
                "vehicle_battery_capacity_kwh",
                entry_value(config_entry, "vehicle_battery_capacity", 0.0),
            )
            or 0.0
        )

    @property
    def is_configured(self) -> bool:
        return bool(self._soc_entity)

    async def get_state(self) -> EVState:
        return EVState(
            soc_pct=self._float_state(self._soc_entity, default=0.0),
            target_soc_pct=self._target_soc(),
            plugged_in=self._bool_state(self._plugged_in_entity, default=True),
            charging=False,
            range_km=self._float_state(self._range_entity, default=0.0),
            battery_kwh=self._battery_kwh,
        )

    def _float_state(self, entity_id: str | None, default: float) -> float:
        if not entity_id:
            return default
        state = self._hass.states.get(entity_id)
        try:
            return float(state.state) if state is not None else default
        except (ValueError, TypeError):
            return default

    def _bool_state(self, entity_id: str | None, default: bool) -> bool:
        if not entity_id:
            return default
        state = self._hass.states.get(entity_id)
        if state is None:
            return default
        return str(state.state).lower() in {"on", "true", "charging", "connected"}

    def _target_soc(self) -> float:
        value = self._float_state(self._target_soc_entity, default=80.0)
        return value if 0.0 <= value <= 100.0 else 80.0


class NullVehicleController(VehicleController):
    @property
    def is_configured(self) -> bool:
        return False

    async def get_state(self) -> EVState:
        return EVState(
            soc_pct=0.0,
            target_soc_pct=80.0,
            plugged_in=False,
            charging=False,
            range_km=0.0,
            battery_kwh=0.0,
        )
