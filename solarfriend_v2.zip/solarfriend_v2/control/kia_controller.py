"""Kia/Hyundai vehicle controller."""
from __future__ import annotations

from typing import Any

from ..config import entry_value
from ..core.types import EVState
from .vehicle_interface import VehicleController


class KiaController(VehicleController):
    """Read-only vehicle state from Kia/Hyundai integrations."""

    def __init__(self, hass: Any, config_entry: Any) -> None:
        self._hass = hass
        self._soc_entity = entry_value(config_entry, "vehicle_soc_entity")
        self._plugged_in_entity = entry_value(config_entry, "vehicle_plugged_in_entity")
        self._target_soc_entity = entry_value(config_entry, "vehicle_target_soc_entity")
        self._range_entity = entry_value(config_entry, "vehicle_range_entity")
        self._battery_kwh = float(
            entry_value(
                config_entry,
                "vehicle_battery_capacity_kwh",
                entry_value(config_entry, "vehicle_battery_capacity", 0.0),
            )
            or 0.0
        )

    @property
    def is_configured(self) -> bool:
        return bool(self._soc_entity)

    async def get_state(self) -> EVState:
        soc_entity = self._resolve_soc_entity()
        return EVState(
            soc_pct=self._float_state(soc_entity, default=0.0),
            target_soc_pct=self._target_soc(),
            plugged_in=self._bool_state(self._plugged_in_entity, default=False),
            charging=False,
            range_km=self._float_state(self._range_entity, default=0.0),
            battery_kwh=self._battery_kwh,
        )

    def _float_state(self, entity_id: str | None, default: float) -> float:
        if not entity_id:
            return default
        state = self._hass.states.get(entity_id)
        try:
            return float(state.state) if state is not None else default
        except (ValueError, TypeError):
            return default

    def _bool_state(self, entity_id: str | None, default: bool) -> bool:
        if not entity_id:
            return default
        state = self._hass.states.get(entity_id)
        if state is None:
            return default
        return str(state.state).lower() in {"on", "true"}

    def _target_soc(self) -> float:
        value = self._float_state(self._target_soc_entity, default=80.0)
        return value if 0.0 <= value <= 100.0 else 80.0

    def _resolve_soc_entity(self) -> str | None:
        configured = self._soc_entity
        configured_state = self._float_state(configured, default=-1.0)
        target_state = self._float_state(self._target_soc_entity, default=-2.0)

        if (
            configured
            and not self._looks_like_target_entity(configured)
            and configured_state >= 0.0
            and not (self._target_soc_entity and configured_state == target_state)
        ):
            return configured

        detected = self._detect_best_soc_entity()
        return detected or configured

    def _detect_best_soc_entity(self) -> str | None:
        states = getattr(self._hass, "states", None)
        async_all = getattr(states, "async_all", None)
        candidates = async_all() if callable(async_all) else getattr(states, "_mapping", {}).values()

        ranked: list[tuple[int, str]] = []
        for state in candidates:
            entity_id = getattr(state, "entity_id", None) or next(
                (
                    key
                    for key, value in getattr(states, "_mapping", {}).items()
                    if value is state
                ),
                None,
            )
            if not entity_id or not str(entity_id).startswith("sensor."):
                continue
            eid = str(entity_id).lower()
            if any(skip in eid for skip in ("12v", "twelve", "target_range_of_charge", "charge_limit", "target_soc", "charging_limit")):
                continue
            if "ev_battery_level" in eid:
                ranked.append((0, str(entity_id)))
            elif "battery_level" in eid and any(brand in eid for brand in ("kia", "hyundai", "niro")):
                ranked.append((1, str(entity_id)))

        if not ranked:
            return None
        ranked.sort(key=lambda item: (item[0], item[1]))
        return ranked[0][1]

    def _looks_like_target_entity(self, entity_id: str) -> bool:
        lowered = entity_id.lower()
        return any(
            token in lowered
            for token in ("target_range_of_charge", "charge_limit", "target_soc", "charging_limit")
        )
