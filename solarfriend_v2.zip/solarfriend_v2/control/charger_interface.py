"""Abstract EV charger controller interface."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..config import entry_value
from ..core.types import ChargerState


class ChargerController(ABC):
    @property
    def is_configured(self) -> bool:
        return True

    @abstractmethod
    async def set_power(self, watts: int, phases: int) -> None:
        """Set charging power. Runtime owns throttling and de-dupe."""
        ...

    @abstractmethod
    async def pause(self) -> None:
        ...

    @abstractmethod
    async def resume(self) -> None:
        ...

    @abstractmethod
    async def get_state(self) -> ChargerState:
        ...

    @classmethod
    def from_config(cls, hass: Any, config_entry: Any) -> "ChargerController":
        charger_type = entry_value(config_entry, "ev_charger_type", "none")
        if charger_type == "easee":
            from .easee_controller import EaseeController

            return EaseeController(hass, config_entry)
        if charger_type == "manual":
            return ManualChargerController(hass, config_entry)
        return NullChargerController()


class ManualChargerController(ChargerController):
    _STATUS_MAP = {
        "charging": "charging",
        "on": "charging",
        "true": "charging",
        "ready_to_charge": "connected",
        "awaiting_start": "connected",
        "connected": "connected",
        "available": "connected",
        "idle": "connected",
        "completed": "connected",
        "paused": "connected",
        "off": "disconnected",
        "false": "disconnected",
        "disconnected": "disconnected",
        "unplugged": "disconnected",
        "not_connected": "disconnected",
        "error": "error",
        "fault": "error",
    }

    def __init__(self, hass: Any, config_entry: Any) -> None:
        self._hass = hass
        self._status_entity = entry_value(config_entry, "ev_charger_status_entity")
        self._power_entity = entry_value(config_entry, "ev_charger_power_entity")
        self._pause_switch = entry_value(config_entry, "ev_charger_pause_switch")

    @property
    def is_configured(self) -> bool:
        return bool(self._status_entity)

    def _state(self, entity_id: str | None) -> Any:
        return self._hass.states.get(entity_id) if entity_id else None

    async def set_power(self, watts: int, phases: int) -> None:
        return None

    async def pause(self) -> None:
        if not self._pause_switch:
            return
        await self._hass.services.async_call(
            "switch",
            "turn_on",
            {"entity_id": self._pause_switch},
            blocking=True,
        )

    async def resume(self) -> None:
        if not self._pause_switch:
            return
        await self._hass.services.async_call(
            "switch",
            "turn_off",
            {"entity_id": self._pause_switch},
            blocking=True,
        )

    async def get_state(self) -> ChargerState:
        state = self._state(self._status_entity)
        if state is None or state.state in ("unknown", "unavailable", ""):
            return ChargerState(connected=False, charging=False, power_w=0.0, phases=0)

        power_w = await self._get_power_w()
        normalized = self._STATUS_MAP.get(str(state.state).lower(), "connected")
        connected = normalized in {"connected", "charging"}
        charging = normalized == "charging" or power_w > 50
        phases = 3 if power_w >= 4000 else (1 if charging else 0)
        return ChargerState(
            connected=connected,
            charging=charging,
            power_w=power_w,
            phases=phases,
        )

    async def _get_power_w(self) -> float:
        state = self._state(self._power_entity)
        if state is None:
            return 0.0
        try:
            value = float(state.state)
            unit = str(state.attributes.get("unit_of_measurement", "")).lower()
            return value * 1000.0 if unit == "kw" else value
        except (ValueError, TypeError):
            return 0.0


class NullChargerController(ChargerController):
    @property
    def is_configured(self) -> bool:
        return False

    async def set_power(self, watts: int, phases: int) -> None:
        return None

    async def pause(self) -> None:
        return None

    async def resume(self) -> None:
        return None

    async def get_state(self) -> ChargerState:
        return ChargerState(connected=False, charging=False, power_w=0.0, phases=0)
