"""SolarFriend V2 binary sensor platform."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from homeassistant.components.binary_sensor import BinarySensorEntity, BinarySensorEntityDescription
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .config import entry_value
from .const import DOMAIN
from .presentation.models import PresentationState


@dataclass(frozen=True)
class SolarFriendV2BinarySensorDescription(BinarySensorEntityDescription):
    value_fn: Callable[[PresentationState], bool] = lambda state: False


def _cheap_now(state: PresentationState) -> bool:
    prices = state.snapshot.prices
    if not prices:
        return False
    return prices[0].price_dkk <= state.snapshot.min_charge_saving_dkk


def _solar_surplus_now(state: PresentationState) -> bool:
    return state.snapshot.power.pv_w > state.snapshot.power.load_w


def _battery_can_export_now(state: PresentationState) -> bool:
    return state.decision.battery_plan.strategy == "SELL_BATTERY"


def _flex_go_now_active(state: PresentationState) -> bool:
    return any(item.status == "GO_NOW" for item in state.decision.flex_plan.decisions)


def _ev_charging_active(state: PresentationState) -> bool:
    charger = state.snapshot.charger
    return bool(charger and charger.charging)


def _runtime_stale(state: PresentationState) -> bool:
    return state.runtime_health != "ok"


BINARY_SENSOR_DESCRIPTIONS: tuple[SolarFriendV2BinarySensorDescription, ...] = (
    SolarFriendV2BinarySensorDescription(
        key="cheap_now",
        name="Cheap Now",
        icon="mdi:cash-minus",
        value_fn=_cheap_now,
    ),
    SolarFriendV2BinarySensorDescription(
        key="solar_surplus_now",
        name="Solar Surplus Now",
        icon="mdi:white-balance-sunny",
        value_fn=_solar_surplus_now,
    ),
    SolarFriendV2BinarySensorDescription(
        key="battery_can_export_now",
        name="Battery Can Export Now",
        icon="mdi:transmission-tower-export",
        value_fn=_battery_can_export_now,
    ),
    SolarFriendV2BinarySensorDescription(
        key="flex_go_now_active",
        name="Flex Go Now Active",
        icon="mdi:play-circle-outline",
        value_fn=_flex_go_now_active,
    ),
    SolarFriendV2BinarySensorDescription(
        key="ev_charging_active",
        name="EV Charging Active",
        icon="mdi:ev-station",
        value_fn=_ev_charging_active,
    ),
    SolarFriendV2BinarySensorDescription(
        key="runtime_stale",
        name="Runtime Stale",
        icon="mdi:alert-circle-outline",
        value_fn=_runtime_stale,
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [SolarFriendV2BinarySensor(coordinator, entry, description) for description in BINARY_SENSOR_DESCRIPTIONS]
    )


class SolarFriendV2BinarySensor(CoordinatorEntity, BinarySensorEntity):
    """A single SolarFriend V2 binary sensor backed by the coordinator."""

    entity_description: SolarFriendV2BinarySensorDescription
    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: Any,
        entry: ConfigEntry,
        description: SolarFriendV2BinarySensorDescription,
    ) -> None:
        super().__init__(coordinator)
        self.entity_description = description
        self._attr_unique_id = f"{entry.entry_id}_{description.key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry_value(entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )

    @property
    def is_on(self) -> bool | None:
        state = getattr(self.coordinator, "presentation_state", None)
        if not isinstance(state, PresentationState):
            return None
        return self.entity_description.value_fn(state)
