"""SolarFriend V2 switch platform."""
from __future__ import annotations

from typing import Any

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.restore_state import RestoreEntity

from .config import entry_value, update_entry_options
from .const import DOMAIN


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [
            SolarFriendV2ControlEnabledSwitch(coordinator, entry),
            SolarFriendV2EVChargingSwitch(coordinator),
            SolarFriendV2BatterySellSwitch(coordinator, entry),
            SolarFriendV2EVSolarOnlyGridBufferSwitch(coordinator, entry),
            SolarFriendV2AdvancedConsumptionModelSwitch(coordinator, entry),
            SolarFriendV2ShadowLogSwitch(coordinator, entry),
        ]
    )


class _BaseSwitch(RestoreEntity, SwitchEntity):
    _attr_has_entity_name = True

    def __init__(self, coordinator: Any, entry: ConfigEntry, name: str, unique_suffix: str, icon: str) -> None:
        self._coordinator = coordinator
        self._entry = entry
        self._attr_name = name
        self._attr_unique_id = f"{entry.entry_id}_{unique_suffix}"
        self._attr_icon = icon
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry_value(entry, "name", "SolarFriend V2"),
            manufacturer="SolarFriend",
            model="Solar Energy Manager V2",
        )
        self._is_on = False

    @property
    def is_on(self) -> bool:
        return self._is_on

    async def _notify(self, reason: str) -> None:
        callback = getattr(self._coordinator, "async_on_runtime_setting_changed", None)
        if callable(callback):
            await callback(reason=reason)


class SolarFriendV2EVChargingSwitch(_BaseSwitch):
    def __init__(self, coordinator: Any) -> None:
        super().__init__(coordinator, coordinator.config_entry, "EV Charging Enabled", "ev_charging_enabled", "mdi:ev-station")
        self._is_on = bool(getattr(coordinator, "ev_charging_allowed", True))

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._is_on = True
        self._coordinator.ev_charging_allowed = True
        self.async_write_ha_state()
        await self._notify("switch-ev_charging_enabled-updated")

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._is_on = False
        self._coordinator.ev_charging_allowed = False
        self.async_write_ha_state()
        await self._notify("switch-ev_charging_enabled-updated")


class SolarFriendV2ControlEnabledSwitch(_BaseSwitch):
    def __init__(self, coordinator: Any, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry, "Control Enabled", "control_enabled", "mdi:toggle-switch")
        self._is_on = bool(entry_value(entry, "control_enabled", False))

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._is_on = True
        self._coordinator.control_enabled = True
        update_entry_options(self.hass, self._entry, control_enabled=True)
        self.async_write_ha_state()
        await self._notify("switch-control_enabled-updated")

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._is_on = False
        self._coordinator.control_enabled = False
        update_entry_options(self.hass, self._entry, control_enabled=False)
        self.async_write_ha_state()
        await self._notify("switch-control_enabled-updated")


class SolarFriendV2BatterySellSwitch(_BaseSwitch):
    def __init__(self, coordinator: Any, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry, "Battery Sell Enabled", "battery_sell_enabled", "mdi:cash-sync")
        self._is_on = bool(entry_value(entry, "battery_sell_enabled", True))

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._is_on = True
        self._coordinator.battery_sell_enabled = True
        update_entry_options(self.hass, self._entry, battery_sell_enabled=True)
        self.async_write_ha_state()
        await self._notify("switch-battery_sell_enabled-updated")

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._is_on = False
        self._coordinator.battery_sell_enabled = False
        update_entry_options(self.hass, self._entry, battery_sell_enabled=False)
        self.async_write_ha_state()
        await self._notify("switch-battery_sell_enabled-updated")


class SolarFriendV2EVSolarOnlyGridBufferSwitch(_BaseSwitch):
    def __init__(self, coordinator: Any, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry, "EV Solar Only Grid Buffer", "ev_solar_only_grid_buffer_enabled", "mdi:transmission-tower-import")
        self._is_on = bool(entry_value(entry, "ev_solar_only_grid_buffer_enabled", True))

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._is_on = True
        self._coordinator.ev_solar_only_grid_buffer_enabled = True
        update_entry_options(self.hass, self._entry, ev_solar_only_grid_buffer_enabled=True)
        self.async_write_ha_state()
        await self._notify("switch-ev_solar_only_grid_buffer_enabled-updated")

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._is_on = False
        self._coordinator.ev_solar_only_grid_buffer_enabled = False
        update_entry_options(self.hass, self._entry, ev_solar_only_grid_buffer_enabled=False)
        self.async_write_ha_state()
        await self._notify("switch-ev_solar_only_grid_buffer_enabled-updated")


class SolarFriendV2AdvancedConsumptionModelSwitch(_BaseSwitch):
    def __init__(self, coordinator: Any, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry, "Use Advanced Consumption Model", "advanced_consumption_model_enabled", "mdi:chart-timeline-variant")
        self._is_on = bool(entry_value(entry, "advanced_consumption_model_enabled", False))

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._is_on = True
        self._coordinator.advanced_consumption_model_enabled = True
        update_entry_options(self.hass, self._entry, advanced_consumption_model_enabled=True)
        self.async_write_ha_state()
        await self._notify("switch-advanced_consumption_model_enabled-updated")

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._is_on = False
        self._coordinator.advanced_consumption_model_enabled = False
        update_entry_options(self.hass, self._entry, advanced_consumption_model_enabled=False)
        self.async_write_ha_state()
        await self._notify("switch-advanced_consumption_model_enabled-updated")


class SolarFriendV2ShadowLogSwitch(_BaseSwitch):
    def __init__(self, coordinator: Any, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry, "Shadow Log Enabled", "shadow_log_enabled", "mdi:file-chart")
        self._is_on = bool(entry_value(entry, "shadow_log_enabled", False))

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._is_on = True
        update_entry_options(self.hass, self._entry, shadow_log_enabled=True)
        self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._is_on = False
        update_entry_options(self.hass, self._entry, shadow_log_enabled=False)
        self.async_write_ha_state()
